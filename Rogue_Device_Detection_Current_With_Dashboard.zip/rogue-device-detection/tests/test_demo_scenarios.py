"""
Unit tests for the demonstration scenarios in demo_scenarios.py.
Verifies deterministic event generation, protocol attributes, and end-to-end execution
of Scenarios A, B, C, and D against an isolated test database.
"""

from datetime import datetime, timezone
from pathlib import Path
import pytest

from config import AppConfig, SensorConfig, DatabaseConfig, InventoryConfig
from app import NetworkMonitoringApp
from demo_scenarios import (
    generate_scenario_a_events,
    generate_scenario_b_events,
    generate_scenario_c_events,
    generate_scenario_d_events,
    run_scenario,
    SCENARIO_METADATA,
)


@pytest.fixture
def test_app(tmp_path):
    """Provide a isolated NetworkMonitoringApp configured with temporary storage."""
    db_file = tmp_path / "test_demo_app.db"
    cfg = AppConfig()
    cfg.database = DatabaseConfig(db_file=db_file)
    cfg.sensor = SensorConfig(simulation_mode=True)
    cfg.inventory = InventoryConfig(auto_sync_approved=False)
    app = NetworkMonitoringApp(cfg)
    return app


def test_scenario_a_event_generator():
    """Verify Scenario A event generation structure and attributes."""
    events = generate_scenario_a_events()
    assert len(events) >= 10  # 1 ARP + 9 port probes
    arp_ev = events[0]
    assert arp_ev.protocol == "ARP"
    assert arp_ev.scenario == "PORT_SCAN_ATTEMPT"
    assert arp_ev.is_synthetic is True

    tcp_probes = [e for e in events if e.protocol == "TCP"]
    assert len(tcp_probes) == 9
    ports = {e.dst_port for e in tcp_probes}
    assert 22 in ports
    assert 80 in ports
    assert 443 in ports
    for p in tcp_probes:
        assert p.tcp_flags == "SYN"
        assert p.src_ip == "192.168.1.199"
        assert p.dst_ip == "192.168.1.20"


def test_scenario_b_event_generator():
    """Verify Scenario B event generation structure and attributes."""
    events = generate_scenario_b_events()
    assert len(events) >= 46  # 1 DNS query + 45 burst packets
    burst_packets = [e for e in events if e.protocol == "TCP"]
    assert len(burst_packets) == 45
    assert burst_packets[0].packet_size >= 1000
    for e in burst_packets:
        assert e.src_ip == "192.168.1.210"
        assert e.dst_ip == "192.168.1.20"
        assert e.scenario == "DOS_LIKE_TRAFFIC_BURST"
        assert e.is_synthetic is True


def test_scenario_c_event_generator():
    """Verify Scenario C event generation structure and attributes."""
    events = generate_scenario_c_events()
    assert len(events) == 4  # 1 Gateway spoof + 3 Flapping packets
    gw_event = events[0]
    assert gw_event.src_mac == "DE:AD:BE:EF:00:01"
    assert gw_event.src_ip == "192.168.1.1"
    assert gw_event.scenario == "GATEWAY_ARP_SPOOF_ATTEMPT"

    flapping_events = events[1:]
    assert len(flapping_events) == 3
    for e in flapping_events:
        assert e.src_ip == "192.168.1.55"
        assert e.scenario == "RAPID_ARP_FLAPPING"


def test_scenario_d_event_generator():
    """Verify Scenario D event generation structure and attributes."""
    events = generate_scenario_d_events()
    assert len(events) == 2  # 1 Client request + 1 Rogue offer
    offer = events[1]
    assert offer.protocol == "DHCP"
    assert offer.dhcp_message_type == "OFFER"
    assert offer.dhcp_server_id == "192.168.1.254"
    assert offer.src_mac == "00:E0:4C:12:34:56"
    assert offer.scenario == "UNAPPROVED_DHCP_OFFER"


def test_run_scenario_a_execution(test_app):
    """Verify complete execution and alert triggering for Scenario A."""
    success = run_scenario("A", test_app, delay=0.0)
    assert success is True
    alerts = test_app.db.get_alerts()
    assert any(a.detection_type == "PORT_SCAN_SUSPECT" for a in alerts)


def test_run_scenario_b_execution(test_app):
    """Verify complete execution and alert triggering for Scenario B."""
    success = run_scenario("B", test_app, delay=0.0)
    assert success is True
    alerts = test_app.db.get_alerts()
    assert any(a.detection_type == "TRAFFIC_ANOMALY_DOS_BURST" for a in alerts)


def test_run_scenario_c_execution(test_app):
    """Verify complete execution and alert triggering for Scenario C."""
    success = run_scenario("C", test_app, delay=0.0)
    assert success is True
    alerts = test_app.db.get_alerts()
    assert any(a.detection_type == "GATEWAY_ARP_SPOOF_SUSPECT" for a in alerts)


def test_run_scenario_d_execution(test_app):
    """Verify complete execution and alert triggering for Scenario D."""
    success = run_scenario("D", test_app, delay=0.0)
    assert success is True
    alerts = test_app.db.get_alerts()
    assert any(a.detection_type == "ROGUE_DHCP_OFFER_UNAPPROVED" for a in alerts)
