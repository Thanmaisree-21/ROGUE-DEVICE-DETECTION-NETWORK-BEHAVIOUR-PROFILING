"""
Unit tests for the independent DosAnomalyDetector module.
Tests packet rate bursts, byte throughput floods, defensive wording, cooldowns, and non-detection cases.
"""

from datetime import datetime, timezone
import pytest

from detection.dos_detector import DosAnomalyDetector
from models.events import NetworkEvent
from models.alert import AlertSeverity
from database.db import DatabaseManager
from models.device import Device
from models.profile import DeviceBaseline


@pytest.fixture
def temp_db(tmp_path):
    db_file = tmp_path / "test_dos.db"
    mgr = DatabaseManager(db_path=db_file)
    mgr.init_db()
    return mgr


def test_dos_packet_rate_spike_detection():
    """Verify that a sudden burst of packets exceeding threshold triggers an alert."""
    detector = DosAnomalyDetector(packet_rate_threshold=10.0, window_seconds=5.0)
    now = datetime.now(timezone.utc)

    alerts = []
    # Feed 25 packets in a very short window (simulating 50+ pkts/s burst)
    for i in range(25):
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.210",
            dst_ip="192.168.1.20",
            protocol="TCP",
            src_port=50000 + i,
            dst_port=80,
            packet_size=100,
        )
        alerts.extend(detector.evaluate(ev, None))

    assert len(alerts) >= 1
    alert = alerts[0]
    assert alert.detection_type == "TRAFFIC_ANOMALY_DOS_BURST"
    assert alert.severity == AlertSeverity.HIGH.value
    assert alert.source_ip == "192.168.1.210"

    # Ethical / Defensive phrasing verification
    desc = alert.description.lower()
    assert "resembles" in desc or "abnormal" in desc
    assert "not confirmed" in desc or "not a confirmed attack" in desc or "intentional denial-of-service attack is not confirmed" in alert.description.lower()


def test_dos_single_target_concentration():
    """Verify that excessive requests concentrated on one specific target triggers an alert."""
    detector = DosAnomalyDetector(
        packet_rate_threshold=100.0,
        single_target_rate_threshold=5.0,
        window_seconds=5.0,
    )
    now = datetime.now(timezone.utc)

    alerts = []
    # 15 packets all targeting 192.168.1.50
    for i in range(15):
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.77",
            dst_ip="192.168.1.50",
            protocol="UDP",
            dst_port=53,
            packet_size=80,
        )
        alerts.extend(detector.evaluate(ev, None))

    assert len(alerts) >= 1
    assert "Target concentration" in " ".join(alerts[0].evidence["trigger_reasons"])
    assert alerts[0].evidence["target_ip"] == "192.168.1.50"


def test_dos_baseline_deviation_detection(temp_db):
    """Verify detecting traffic bursts that statistically deviate from the device's baseline."""
    now = datetime.now(timezone.utc)
    dev_id = "mac_00:AA:BB:CC:DD:EE"

    # Populate device and established baseline in DB (Mean: 2.0 pkts/s, StdDev: 0.5)
    temp_db.upsert_device(Device(device_id=dev_id, first_seen=now, last_seen=now, current_ip="192.168.1.40"))
    baseline = DeviceBaseline(
        device_id=dev_id,
        created_at=now,
        updated_at=now,
        sample_windows=6,
        mean_packet_rate=2.0,
        std_packet_rate=0.5,
    )
    temp_db.upsert_baseline(baseline)

    dev = temp_db.get_device_by_id(dev_id)
    detector = DosAnomalyDetector(
        db=temp_db,
        packet_rate_threshold=100.0,
        baseline_zscore_threshold=3.0,
        window_seconds=5.0,
    )

    alerts = []
    # Observed rate ~ 10 pkts/s (Z-score = (10 - 2) / 0.5 = 16 >> 3.0)
    for _ in range(12):
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.40",
            dst_ip="192.168.1.1",
            protocol="ICMP",
            packet_size=64,
        )
        alerts.extend(detector.evaluate(ev, dev))

    assert len(alerts) >= 1
    assert any("Z-score" in r for r in alerts[0].evidence["trigger_reasons"])


def test_dos_non_detection_normal_traffic():
    """Verify that steady, normal traffic well below thresholds does not trigger alerts."""
    detector = DosAnomalyDetector(packet_rate_threshold=20.0, window_seconds=5.0)
    now = datetime.now(timezone.utc)

    alerts = []
    # 3 packets in 5 seconds
    for _ in range(3):
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.10",
            dst_ip="192.168.1.1",
            protocol="TCP",
            dst_port=80,
            packet_size=120,
        )
        alerts.extend(detector.evaluate(ev, None))

    assert len(alerts) == 0


def test_dos_cooldown_deduplication():
    """Verify that multiple flood packets within cooldown window do not generate duplicate alerts."""
    detector = DosAnomalyDetector(packet_rate_threshold=5.0, window_seconds=5.0, cooldown_seconds=60.0)
    now = datetime.now(timezone.utc)

    # Trigger initial alert
    for _ in range(10):
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.210",
            dst_ip="192.168.1.20",
            protocol="TCP",
            dst_port=80,
            packet_size=100,
        )
        detector.evaluate(ev, None)

    # Next packet in same cooldown window
    ev_next = NetworkEvent(
        timestamp=now,
        src_ip="192.168.1.210",
        dst_ip="192.168.1.20",
        protocol="TCP",
        dst_port=80,
        packet_size=100,
    )
    alerts = detector.evaluate(ev_next, None)
    assert len(alerts) == 0
