"""
Unit tests verifying application resilience against malformed, incomplete, and unexpected events.
Ensures that unusual, truncated, or corrupted frames do not crash the sensor or detection modules.
"""

from datetime import datetime, timezone
import pytest

from database.db import DatabaseManager
from models.events import NetworkEvent
from detection.detection_engine import DetectionEngine
from detection.port_scan_detector import PortScanDetector
from detection.dos_detector import DosAnomalyDetector
from detection.arp_spoof_detector import ArpSpoofDetector
from detection.rogue_dhcp_detector import RogueDhcpDetector
from sensor.device_discovery import DeviceDiscoveryManager


@pytest.fixture
def test_env(tmp_path):
    db_file = tmp_path / "test_malformed.db"
    db = DatabaseManager(db_path=db_file)
    db.init_db()
    engine = DetectionEngine(db)
    discovery = DeviceDiscoveryManager(db)
    return db, engine, discovery


def test_malformed_events_handling(test_env):
    """Verify that corrupt or incomplete events do not trigger unhandled exceptions."""
    db, engine, discovery = test_env
    now = datetime.now(timezone.utc)

    # Collection of incomplete or boundary-case events
    problematic_events = [
        # Empty/None fields
        NetworkEvent(timestamp=now, src_mac=None, dst_mac=None, src_ip=None, dst_ip=None, protocol="OTHER"),
        # Broadcast source MAC (invalid sender)
        NetworkEvent(timestamp=now, src_mac="FF:FF:FF:FF:FF:FF", src_ip="192.168.1.1", protocol="ARP"),
        # Zero MAC and IP
        NetworkEvent(timestamp=now, src_mac="00:00:00:00:00:00", src_ip="0.0.0.0", protocol="IP"),
        # Huge packet size boundary
        NetworkEvent(timestamp=now, src_mac="00:11:22:33:44:55", src_ip="10.0.0.1", protocol="TCP", packet_size=99999999),
        # Negative port or out-of-range port
        NetworkEvent(timestamp=now, src_mac="00:11:22:33:44:55", src_ip="10.0.0.1", protocol="TCP", src_port=-1, dst_port=99999),
        # Corrupt info string
        NetworkEvent(timestamp=now, src_mac="00:11:22:33:44:55", src_ip="10.0.0.1", protocol="DHCP", info="\x00\xff\xfe\x01\x02"),
        # Missing DHCP options
        NetworkEvent(timestamp=now, src_mac="00:11:22:33:44:55", src_ip="10.0.0.1", protocol="DHCP", dhcp_message_type=None, dhcp_server_id=None),
    ]

    for ev in problematic_events:
        try:
            # 1. Device discovery processing
            dev, is_new, conflict = discovery.process_event(ev)
            # 2. Engine evaluation
            engine.process_event(ev, dev, {"ip_conflict": conflict})
            # 3. Database insert
            db.insert_event(ev)
        except Exception as e:
            pytest.fail(f"Processing malformed event raised unexpected exception: {e}")
