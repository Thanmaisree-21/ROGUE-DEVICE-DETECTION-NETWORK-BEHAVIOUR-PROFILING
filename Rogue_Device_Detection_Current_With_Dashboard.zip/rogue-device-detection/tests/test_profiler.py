"""
Unit tests for FeatureExtractor and BehaviorProfiler.
Tests window aggregation, baseline calculation, and anomaly detection.
"""

from datetime import datetime, timezone, timedelta
import pytest

from database.db import DatabaseManager
from models.events import NetworkEvent
from models.profile import TrafficWindowMetrics
from config import ProfilingConfig
from profiling.feature_extractor import FeatureExtractor
from profiling.behavior_profiler import BehaviorProfiler


@pytest.fixture
def profiler_fixture(tmp_path):
    """Fixture providing initialized DB and BehaviorProfiler."""
    db_file = tmp_path / "test_profiler.db"
    db = DatabaseManager(db_path=db_file)
    db.init_db()
    cfg = ProfilingConfig(min_samples_for_baseline=3, zscore_threshold=2.5)
    profiler = BehaviorProfiler(db, cfg)
    return profiler, db


def test_feature_extractor_metrics():
    """Verify calculating packet rates, byte rates, and port counts across a window."""
    t0 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    t1 = t0 + timedelta(seconds=10)

    events = [
        NetworkEvent(timestamp=t0, src_mac="AA:BB:CC:11:22:33", dst_ip="10.0.0.1", dst_port=80, protocol="TCP", packet_size=100, tcp_flags="SYN"),
        NetworkEvent(timestamp=t0, src_mac="AA:BB:CC:11:22:33", dst_ip="10.0.0.1", dst_port=80, protocol="TCP", packet_size=200, tcp_flags="ACK"),
        NetworkEvent(timestamp=t0, src_mac="AA:BB:CC:11:22:33", dst_ip="10.0.0.2", dst_port=53, protocol="UDP", packet_size=60),
    ]

    metrics = FeatureExtractor.extract_device_metrics("mac_AA:BB:CC:11:22:33", events, t0, t1)
    assert metrics.packet_count == 3
    assert metrics.byte_count == 360
    assert metrics.packet_rate == 0.3  # 3 pkts / 10s
    assert metrics.byte_rate == 36.0   # 360 bytes / 10s
    assert metrics.distinct_targets == 2
    assert metrics.distinct_ports == 2
    assert metrics.protocol_counts["TCP"] == 2
    assert metrics.protocol_counts["UDP"] == 1
    assert metrics.syn_packet_count == 1
    assert metrics.ack_packet_count == 1


def test_behavior_profiler_baseline_and_spike_anomaly(profiler_fixture):
    """Verify baseline establishment and statistical Z-score spike detection."""
    profiler, db = profiler_fixture
    dev_id = "mac_AA:BB:CC:11:22:33"

    t = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    from models.device import Device
    db.upsert_device(Device(device_id=dev_id, first_seen=t, last_seen=t))

    # Feed 3 normal baseline windows (e.g. around 10 pkts/s)
    normal_rates = [10.0, 11.0, 9.5]
    for r in normal_rates:
        m = TrafficWindowMetrics(
            device_id=dev_id,
            window_start=t,
            window_end=t + timedelta(seconds=10),
            packet_count=int(r * 10),
            packet_rate=r,
            byte_rate=r * 100,
        )
        anomalies = profiler.process_window(m)
        assert len(anomalies) == 0
        t += timedelta(seconds=10)

    # Check baseline in DB
    baseline = profiler.get_baseline(dev_id)
    assert baseline is not None
    assert baseline.sample_windows == 3
    assert 9.0 <= baseline.mean_packet_rate <= 11.0

    # Feed a massive spike (100.0 pkts/s)
    spike_metrics = TrafficWindowMetrics(
        device_id=dev_id,
        window_start=t,
        window_end=t + timedelta(seconds=10),
        packet_count=1000,
        packet_rate=100.0,
        byte_rate=10000.0,
    )
    spike_anomalies = profiler.process_window(spike_metrics)
    assert len(spike_anomalies) >= 1
    assert any(a["type"] == "TRAFFIC_VOLUME_SPIKE" for a in spike_anomalies)
