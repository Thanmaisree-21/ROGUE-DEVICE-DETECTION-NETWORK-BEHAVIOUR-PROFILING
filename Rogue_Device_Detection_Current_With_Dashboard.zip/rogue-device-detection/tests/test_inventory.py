"""
Unit tests for DeviceDiscoveryManager and inventory tracking.
Tests approved vs unrecognized status, dynamic IP changes, and IP conflict detection.
"""

from datetime import datetime, timezone
import pytest

from database.db import DatabaseManager
from models.device import ApprovedAsset, DeviceStatus
from models.events import NetworkEvent
from sensor.device_discovery import DeviceDiscoveryManager, normalize_mac


@pytest.fixture
def discovery_fixture(tmp_path):
    """Fixture providing initialized DB with approved assets and discovery manager."""
    db_file = tmp_path / "test_inventory.db"
    db = DatabaseManager(db_path=db_file)
    db.init_db()

    # Pre-populate approved asset
    approved = ApprovedAsset(
        mac_address="00:1A:2B:3C:4D:5E",
        device_name="Gateway-01",
        device_type="Gateway",
        assigned_ip="192.168.1.1",
    )
    db.add_approved_asset(approved)

    mgr = DeviceDiscoveryManager(db)
    return mgr, db


def test_approved_device_discovery(discovery_fixture):
    """Verify that a device in the approved asset list receives APPROVED status."""
    mgr, db = discovery_fixture
    now = datetime.now(timezone.utc)

    event = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.1",
        protocol="ARP",
        packet_size=42,
    )
    dev, is_new, conflict = mgr.process_event(event)

    assert dev is not None
    assert is_new is True
    assert dev.is_approved is True
    assert dev.approval_status == DeviceStatus.APPROVED.value
    assert dev.mac_address == "00:1A:2B:3C:4D:5E"
    assert dev.current_ip == "192.168.1.1"


def test_unrecognized_device_discovery(discovery_fixture):
    """Verify that an unknown MAC address is marked as UNRECOGNIZED."""
    mgr, db = discovery_fixture
    now = datetime.now(timezone.utc)

    event = NetworkEvent(
        timestamp=now,
        src_mac="AA:BB:CC:DD:EE:01",
        src_ip="192.168.1.150",
        protocol="DHCP",
        packet_size=300,
        info="Host=Unknown-Phone",
    )
    dev, is_new, conflict = mgr.process_event(event)

    assert dev is not None
    assert is_new is True
    assert dev.is_approved is False
    assert dev.approval_status == DeviceStatus.UNRECOGNIZED.value
    assert dev.hostname == "Unknown-Phone"


def test_dynamic_ip_address_change(discovery_fixture):
    """
    Verify that when an existing device changes IP address,
    its identity is maintained rather than creating a duplicate device record.
    """
    mgr, db = discovery_fixture
    now = datetime.now(timezone.utc)
    mac = "00:1A:2B:3C:4D:5E"

    # 1. Device seen with initial IP
    ev1 = NetworkEvent(
        timestamp=now,
        src_mac=mac,
        src_ip="192.168.1.1",
        protocol="IP",
        packet_size=100,
    )
    dev1, is_new1, _ = mgr.process_event(ev1)
    assert is_new1 is True
    orig_device_id = dev1.device_id

    # 2. Device observed with a new IP (e.g. DHCP lease changed to 192.168.1.101)
    ev2 = NetworkEvent(
        timestamp=now,
        src_mac=mac,
        src_ip="192.168.1.101",
        protocol="IP",
        packet_size=120,
    )
    dev2, is_new2, _ = mgr.process_event(ev2)

    # Must NOT be treated as a new device
    assert is_new2 is False
    assert dev2.device_id == orig_device_id
    assert dev2.current_ip == "192.168.1.101"
    # Preserves approved status
    assert dev2.is_approved is True
    # IP history includes both addresses
    assert "192.168.1.1" in dev2.ip_history
    assert "192.168.1.101" in dev2.ip_history


def test_ip_collision_detection(discovery_fixture):
    """Verify that multiple MAC addresses claiming the same IP are flagged as a conflict."""
    mgr, db = discovery_fixture
    now = datetime.now(timezone.utc)

    # Device A claims IP 192.168.1.200
    ev1 = NetworkEvent(
        timestamp=now,
        src_mac="11:22:33:44:55:66",
        src_ip="192.168.1.200",
        protocol="ARP",
        packet_size=42,
    )
    mgr.process_event(ev1)

    # Device B claims identical IP 192.168.1.200
    ev2 = NetworkEvent(
        timestamp=now,
        src_mac="AA:BB:CC:DD:EE:FF",
        src_ip="192.168.1.200",
        protocol="ARP",
        packet_size=42,
    )
    dev2, is_new2, conflict = mgr.process_event(ev2)

    assert conflict is not None
    assert "IP collision / possible ARP spoof" in conflict
    assert "192.168.1.200" in conflict
