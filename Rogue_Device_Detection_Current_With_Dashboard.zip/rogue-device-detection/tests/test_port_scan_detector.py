"""
Unit tests for the independent PortScanDetector module.
Tests vertical port scanning, horizontal host sweeping, thresholds, cooldowns, and non-detection cases.
"""

from datetime import datetime, timezone
import pytest

from detection.port_scan_detector import PortScanDetector
from config import PortScanDetectorConfig
from models.events import NetworkEvent
from models.alert import AlertSeverity


def test_vertical_port_scan_detection():
    """Verify that probing multiple distinct ports on a single host triggers an alert."""
    detector = PortScanDetector(ports_threshold=5, window_seconds=10.0)
    now = datetime.now(timezone.utc)

    alerts = []
    # Probe 5 different ports
    for port in [21, 22, 25, 80, 443]:
        ev = NetworkEvent(
            timestamp=now,
            src_mac="00:11:22:33:44:55",
            src_ip="192.168.1.199",
            dst_ip="192.168.1.20",
            protocol="TCP",
            src_port=50000 + port,
            dst_port=port,
            tcp_flags="SYN",
        )
        alerts.extend(detector.evaluate(ev, None))

    assert len(alerts) == 1
    alert = alerts[0]
    assert alert.detection_type == "PORT_SCAN_SUSPECT"
    assert alert.severity == AlertSeverity.HIGH.value
    assert alert.source_ip == "192.168.1.199"
    assert alert.target_ip == "192.168.1.20"
    assert alert.evidence["distinct_ports_count"] == 5


def test_horizontal_host_sweep_detection():
    """Verify that probing multiple target hosts on the same port triggers an alert."""
    detector = PortScanDetector(ports_threshold=20, target_hosts_threshold=4, window_seconds=10.0)
    now = datetime.now(timezone.utc)

    alerts = []
    # Sweep port 445 across 4 distinct hosts
    for i in range(1, 5):
        ev = NetworkEvent(
            timestamp=now,
            src_mac="00:11:22:33:44:55",
            src_ip="192.168.1.199",
            dst_ip=f"192.168.1.{i}",
            protocol="TCP",
            src_port=52000,
            dst_port=445,
            tcp_flags="SYN",
        )
        alerts.extend(detector.evaluate(ev, None))

    assert len(alerts) == 1
    assert alerts[0].detection_type == "PORT_SCAN_SUSPECT"
    assert alerts[0].evidence["distinct_targets_count"] == 4


def test_port_scan_non_detection_normal_traffic():
    """Verify that normal multi-packet communication to a single port does not trigger an alert."""
    detector = PortScanDetector(ports_threshold=5, window_seconds=10.0)
    now = datetime.now(timezone.utc)

    alerts = []
    # Normal web browsing: multiple requests to port 443 and 80
    for _ in range(8):
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.10",
            dst_ip="140.82.121.4",
            protocol="TCP",
            src_port=51000,
            dst_port=443,
            tcp_flags="ACK",
        )
        alerts.extend(detector.evaluate(ev, None))

    assert len(alerts) == 0


def test_port_scan_cooldown_deduplication():
    """Verify that consecutive probe packets within the cooldown window do not flood alerts."""
    detector = PortScanDetector(ports_threshold=3, window_seconds=10.0, cooldown_seconds=60.0)
    now = datetime.now(timezone.utc)

    # First 3 ports trigger an alert
    for p in [80, 81, 82]:
        ev = NetworkEvent(
            timestamp=now,
            src_ip="192.168.1.199",
            dst_ip="192.168.1.20",
            protocol="TCP",
            dst_port=p,
        )
        detector.evaluate(ev, None)

    # Fourth port immediately follows -> blocked by cooldown!
    ev4 = NetworkEvent(
        timestamp=now,
        src_ip="192.168.1.199",
        dst_ip="192.168.1.20",
        protocol="TCP",
        dst_port=83,
    )
    alerts = detector.evaluate(ev4, None)
    assert len(alerts) == 0

    # Reset cooldown -> alert triggers
    detector.reset_cooldown()
    alerts_after_reset = detector.evaluate(ev4, None)
    assert len(alerts_after_reset) == 1
