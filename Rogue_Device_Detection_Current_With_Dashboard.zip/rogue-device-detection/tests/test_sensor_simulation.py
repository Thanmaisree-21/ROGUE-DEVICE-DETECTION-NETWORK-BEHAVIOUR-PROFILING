"""
Unit tests for PacketSensor simulation and buffer management.
"""

from datetime import datetime, timezone
import time
from pathlib import Path
import pytest

from config import SensorConfig
from models.events import NetworkEvent
from sensor.packet_sensor import PacketSensor


def test_sensor_buffer_bounded():
    """Verify that the sensor buffer respects the max buffer size limit."""
    cfg = SensorConfig(buffer_size=5, simulation_mode=True)
    sensor = PacketSensor(cfg)

    now = datetime.now(timezone.utc)
    for i in range(10):
        ev = NetworkEvent(
            timestamp=now,
            src_mac=f"00:00:00:00:00:{i:02d}",
            src_ip=f"10.0.0.{i}",
            protocol="IP",
        )
        sensor.feed_event(ev)

    events = sensor.get_buffered_events()
    assert len(events) == 5
    # The oldest events were discarded, newest remain
    assert events[-1].src_ip == "10.0.0.9"


def test_sensor_simulation_playback():
    """Verify loading and replaying sample events from JSON without privileges."""
    sample_file = Path(__file__).resolve().parent.parent / "data" / "sample_events.json"
    cfg = SensorConfig(
        buffer_size=100,
        simulation_mode=True,
        sample_events_file=sample_file,
        simulation_packet_delay=0.001,  # Fast replay for test
    )
    sensor = PacketSensor(cfg)

    received_events = []
    sensor.register_callback(lambda ev: received_events.append(ev))

    sensor.start()

    # Wait for simulation to finish
    timeout = 5.0
    start_t = time.time()
    while sensor.is_running and (time.time() - start_t < timeout):
        time.sleep(0.05)

    assert len(received_events) > 0
    assert sensor.stats["packets_parsed"] == len(received_events)
    assert not sensor.is_running
