"""
Unit tests for the independent RogueDhcpDetector module.
Tests unapproved DHCP offers, client message discrimination, static-segment enforcement, and multi-server conflicts.
"""

from datetime import datetime, timezone
import pytest

from detection.rogue_dhcp_detector import RogueDhcpDetector
from models.events import NetworkEvent
from models.alert import AlertSeverity


def test_rogue_dhcp_unapproved_offer():
    """Verify that a DHCP OFFER from an unapproved server identifier triggers an alert."""
    detector = RogueDhcpDetector(
        approved_dhcp_servers=["192.168.1.1", "00:1A:2B:3C:4D:5E"],
    )
    now = datetime.now(timezone.utc)

    # Rogue server 192.168.1.254 issues an OFFER
    ev = NetworkEvent(
        timestamp=now,
        src_mac="00:E0:4C:12:34:56",
        src_ip="192.168.1.254",
        protocol="DHCP",
        dhcp_message_type="OFFER",
        dhcp_server_id="192.168.1.254",
        info="DHCP Offer: ServerID=192.168.1.254",
    )
    alerts = detector.evaluate(ev, None)

    assert len(alerts) >= 1
    alert = alerts[0]
    assert alert.detection_type == "ROGUE_DHCP_OFFER_UNAPPROVED"
    assert alert.source_ip == "192.168.1.254"
    assert alert.severity == AlertSeverity.HIGH.value


def test_approved_dhcp_offer_no_alert():
    """Verify that a DHCP OFFER from the authorized DHCP server triggers no alert."""
    detector = RogueDhcpDetector(
        approved_dhcp_servers=["192.168.1.1", "00:1A:2B:3C:4D:5E"],
    )
    now = datetime.now(timezone.utc)

    ev = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.1",
        protocol="DHCP",
        dhcp_message_type="OFFER",
        dhcp_server_id="192.168.1.1",
        info="DHCP Offer: ServerID=192.168.1.1",
    )
    alerts = detector.evaluate(ev, None)
    assert len(alerts) == 0


def test_client_dhcp_broadcasts_discriminated_no_alert():
    """Verify that client DISCOVER or REQUEST broadcasts are never falsely flagged as rogue server offers."""
    detector = RogueDhcpDetector(
        approved_dhcp_servers=["192.168.1.1"],
    )
    now = datetime.now(timezone.utc)

    # Client broadcasting DHCP Discover
    ev_disc = NetworkEvent(
        timestamp=now,
        src_mac="AA:BB:CC:DD:EE:01",
        src_ip="0.0.0.0",
        protocol="DHCP",
        dhcp_message_type="DISCOVER",
        info="DHCP Discover: Who has lease?",
    )
    # Client broadcasting DHCP Request
    ev_req = NetworkEvent(
        timestamp=now,
        src_mac="AA:BB:CC:DD:EE:01",
        src_ip="0.0.0.0",
        protocol="DHCP",
        dhcp_message_type="REQUEST",
        info="DHCP Request: Renew lease",
    )

    assert len(detector.evaluate(ev_disc, None)) == 0
    assert len(detector.evaluate(ev_req, None)) == 0


def test_static_only_segment_flags_any_dhcp():
    """Verify that when static addressing is enforced (allow_no_dhcp=True), any DHCP server is flagged."""
    detector = RogueDhcpDetector(
        allow_no_dhcp=True,
    )
    now = datetime.now(timezone.utc)

    ev = NetworkEvent(
        timestamp=now,
        src_mac="00:11:22:33:44:55",
        src_ip="192.168.1.1",
        protocol="DHCP",
        dhcp_message_type="OFFER",
        dhcp_server_id="192.168.1.1",
    )
    alerts = detector.evaluate(ev, None)
    assert len(alerts) == 1
    assert alerts[0].detection_type == "UNAUTHORIZED_DHCP_STATIC_SEGMENT"


def test_multiple_dhcp_servers_detected():
    """Verify detecting multiple competing DHCP servers operating in the same subnet."""
    detector = RogueDhcpDetector(
        approved_dhcp_servers=["192.168.1.1", "192.168.1.2"],
    )
    now = datetime.now(timezone.utc)

    # Server 1 issues offer
    ev1 = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.1",
        protocol="DHCP",
        dhcp_message_type="OFFER",
        dhcp_server_id="192.168.1.1",
    )
    detector.evaluate(ev1, None)

    # Server 2 issues offer (competing active server)
    ev2 = NetworkEvent(
        timestamp=now,
        src_mac="00:50:56:11:22:33",
        src_ip="192.168.1.2",
        protocol="DHCP",
        dhcp_message_type="OFFER",
        dhcp_server_id="192.168.1.2",
    )
    alerts = detector.evaluate(ev2, None)

    assert len(alerts) >= 1
    assert any(a.detection_type == "MULTIPLE_DHCP_SERVERS_DETECTED" for a in alerts)
