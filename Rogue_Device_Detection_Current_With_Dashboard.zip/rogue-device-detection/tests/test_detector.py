"""
Unit tests for detection modules and detection engine.
Verifies rogue device detection, alert fields, cooldown deduplication, and port scanning.
"""

from datetime import datetime, timezone
import pytest

from database.db import DatabaseManager
from models.device import Device, DeviceStatus
from models.events import NetworkEvent
from models.alert import AlertSeverity, AlertStatus
from detection.rogue_device_detector import RogueDeviceDetector, ArpConflictDetector, StreamingPortScanDetector
from detection.detection_engine import DetectionEngine


@pytest.fixture
def test_setup(tmp_path):
    """Fixture providing initialized db and detection engine."""
    db_file = tmp_path / "test_detector.db"
    db = DatabaseManager(db_path=db_file)
    db.init_db()
    engine = DetectionEngine(db)
    return db, engine


def test_rogue_detector_approved_device():
    """Verify that approved devices never trigger an UNAPPROVED_DEVICE alert."""
    detector = RogueDeviceDetector(cooldown_seconds=10.0)
    now = datetime.now(timezone.utc)

    approved_dev = Device(
        device_id="mac_00:1A:2B:3C:4D:5E",
        mac_address="00:1A:2B:3C:4D:5E",
        current_ip="192.168.1.1",
        first_seen=now,
        last_seen=now,
        is_approved=True,
        approval_status=DeviceStatus.APPROVED.value,
    )
    event = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.1",
        protocol="TCP",
        src_port=80,
        dst_port=50000,
    )

    alerts = detector.evaluate(event, approved_dev)
    assert len(alerts) == 0


def test_rogue_detector_unapproved_device_and_fields():
    """
    Verify that an unrecognized device triggers an alert with all required attributes:
    ID, detection type, source, timestamp, severity, evidence, status.
    """
    detector = RogueDeviceDetector(cooldown_seconds=10.0)
    now = datetime.now(timezone.utc)

    unrecognized_dev = Device(
        device_id="mac_B8:27:EB:11:22:33",
        mac_address="B8:27:EB:11:22:33",
        current_ip="192.168.1.199",
        first_seen=now,
        last_seen=now,
        is_approved=False,
        approval_status=DeviceStatus.UNRECOGNIZED.value,
        vendor="Raspberry Pi Foundation",
    )
    event = NetworkEvent(
        timestamp=now,
        src_mac="B8:27:EB:11:22:33",
        src_ip="192.168.1.199",
        protocol="ARP",
        info="ARP Probe",
    )

    alerts = detector.evaluate(event, unrecognized_dev)
    assert len(alerts) == 1
    alert = alerts[0]

    assert alert.alert_id is not None
    assert alert.detection_type == "UNAPPROVED_DEVICE"
    assert alert.source_mac == "B8:27:EB:11:22:33"
    assert alert.source_ip == "192.168.1.199"
    assert alert.severity == AlertSeverity.MEDIUM.value
    assert alert.status == AlertStatus.NEW.value
    assert alert.timestamp == now
    assert "evidence" in alert.to_dict()
    assert "classification_reason" in alert.evidence
    # Ensure defensive description notes it is unrecognized, not automatically malicious
    assert "not automatically malicious" in alert.description.lower()


def test_rogue_detector_cooldown_deduplication():
    """Verify that multiple events within cooldown window do not flood duplicate alerts."""
    detector = RogueDeviceDetector(cooldown_seconds=60.0)
    now = datetime.now(timezone.utc)

    dev = Device(
        device_id="mac_B8:27:EB:11:22:33",
        mac_address="B8:27:EB:11:22:33",
        current_ip="192.168.1.199",
        is_approved=False,
        approval_status=DeviceStatus.UNRECOGNIZED.value,
    )
    event1 = NetworkEvent(timestamp=now, src_mac="B8:27:EB:11:22:33", src_ip="192.168.1.199", protocol="UDP")
    event2 = NetworkEvent(timestamp=now, src_mac="B8:27:EB:11:22:33", src_ip="192.168.1.199", protocol="UDP")

    alerts1 = detector.evaluate(event1, dev)
    assert len(alerts1) == 1

    # Second event immediately follows
    alerts2 = detector.evaluate(event2, dev)
    assert len(alerts2) == 0  # Blocked by cooldown!

    # Reset cooldown
    detector.reset_cooldown()
    alerts3 = detector.evaluate(event2, dev)
    assert len(alerts3) == 1


def test_port_scan_detector():
    """Verify that scanning multiple ports in a short window triggers PORT_SCAN_SUSPECT."""
    detector = StreamingPortScanDetector(unique_ports_threshold=5, window_seconds=10.0)
    now = datetime.now(timezone.utc)

    ports = [21, 22, 23, 80, 443]
    alerts = []
    for p in ports:
        event = NetworkEvent(
            timestamp=now,
            src_mac="AA:BB:CC:DD:EE:FF",
            src_ip="192.168.1.199",
            dst_ip="192.168.1.20",
            protocol="TCP",
            src_port=50000 + p,
            dst_port=p,
            tcp_flags="SYN",
        )
        res = detector.evaluate(event, None)
        alerts.extend(res)

    assert len(alerts) == 1
    assert alerts[0].detection_type == "PORT_SCAN_SUSPECT"
    assert alerts[0].severity == AlertSeverity.HIGH.value
    assert len(alerts[0].evidence["probed_ports"]) == 5


def test_detection_engine_integration(test_setup):
    """Verify that detection engine processes event, triggers alert, and writes to database."""
    db, engine = test_setup
    now = datetime.now(timezone.utc)

    dev = Device(
        device_id="mac_AA:00:11:22:33:44",
        mac_address="AA:00:11:22:33:44",
        current_ip="192.168.1.77",
        is_approved=False,
        approval_status=DeviceStatus.UNRECOGNIZED.value,
    )
    event = NetworkEvent(
        timestamp=now,
        src_mac="AA:00:11:22:33:44",
        src_ip="192.168.1.77",
        protocol="ICMP",
    )

    alerts = engine.process_event(event, dev)
    assert len(alerts) == 1

    # Verify persisted in database
    db_alerts = db.get_alerts()
    assert len(db_alerts) == 1
    assert db_alerts[0].detection_type == "UNAPPROVED_DEVICE"
    assert db_alerts[0].source_mac == "AA:00:11:22:33:44"
