"""
Unit tests for the independent IsolationForestAnomalyDetector module.
Tests multivariate outlier detection, sample requirements, toggle enabling, and defensive phrasing.
"""

from datetime import datetime, timezone, timedelta
import pytest

from profiling.isolation_forest_detector import IsolationForestAnomalyDetector, SKLEARN_AVAILABLE
from models.profile import TrafficWindowMetrics


@pytest.mark.skipif(not SKLEARN_AVAILABLE, reason="scikit-learn is not installed")
def test_isolation_forest_outlier_detection():
    """Verify that an extreme multivariate outlier triggers an ISOLATION_FOREST_OUTLIER anomaly."""
    detector = IsolationForestAnomalyDetector(
        enabled=True,
        contamination=0.1,
        min_samples=6,
        random_state=42,
    )
    dev_id = "mac_AA:BB:CC:11:22:33"
    t = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

    # Feed 8 normal baseline windows (e.g. 5 pkts/s, 1-2 ports, 1 target, 0 SYN)
    for _ in range(8):
        m = TrafficWindowMetrics(
            device_id=dev_id,
            window_start=t,
            window_end=t + timedelta(seconds=10),
            packet_count=50,
            byte_count=5000,
            packet_rate=5.0,
            byte_rate=500.0,
            distinct_targets=1,
            distinct_ports=2,
            syn_packet_count=0,
            dns_query_count=2,
        )
        anomalies = detector.evaluate_window(m)
        assert len(anomalies) == 0
        t += timedelta(seconds=10)

    # Feed an extreme multivariate outlier (500 pkts/s, 50 ports, 20 targets, 100 SYNs)
    outlier_metrics = TrafficWindowMetrics(
        device_id=dev_id,
        window_start=t,
        window_end=t + timedelta(seconds=10),
        packet_count=5000,
        byte_count=500000,
        packet_rate=500.0,
        byte_rate=50000.0,
        distinct_targets=20,
        distinct_ports=50,
        syn_packet_count=100,
        dns_query_count=0,
    )
    outlier_anomalies = detector.evaluate_window(outlier_metrics)
    assert len(outlier_anomalies) >= 1
    anom = outlier_anomalies[0]
    assert anom["type"] == "ISOLATION_FOREST_OUTLIER"

    # Ethical / Defensive wording check
    assert "not a confirmed attack" in anom["reason"].lower() or "statistical anomaly" in anom["reason"].lower()


def test_isolation_forest_insufficient_samples():
    """Verify that the detector gracefully accumulates samples until min_samples without false alarms."""
    detector = IsolationForestAnomalyDetector(min_samples=10)
    dev_id = "mac_11:22:33:44:55:66"
    t = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

    # Feed only 3 samples
    for _ in range(3):
        m = TrafficWindowMetrics(
            device_id=dev_id,
            window_start=t,
            window_end=t + timedelta(seconds=10),
            packet_rate=10.0,
        )
        assert len(detector.evaluate_window(m)) == 0


def test_isolation_forest_disabled():
    """Verify that when disabled, evaluate_window always returns an empty list."""
    detector = IsolationForestAnomalyDetector(enabled=False)
    m = TrafficWindowMetrics(
        device_id="mac_11:22:33:44:55:66",
        window_start=datetime.now(timezone.utc),
        window_end=datetime.now(timezone.utc),
        packet_rate=999.0,
    )
    assert len(detector.evaluate_window(m)) == 0
