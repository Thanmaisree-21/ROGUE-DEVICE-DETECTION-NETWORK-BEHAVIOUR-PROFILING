"""
Unit tests for the Scapy ProtocolParser.
Tests Ethernet, ARP, IPv4, TCP, UDP, ICMP, DHCP parsing and payload omission.
"""

import pytest
from scapy.layers.l2 import Ether, ARP
from scapy.layers.inet import IP, TCP, UDP, ICMP
from scapy.layers.dhcp import DHCP, BOOTP

from sensor.protocol_parser import ProtocolParser, parse_tcp_flags


def test_parse_arp_packet():
    """Verify parsing an ARP Who-has packet."""
    pkt = Ether(src="00:11:22:33:44:55", dst="ff:ff:ff:ff:ff:ff") / ARP(
        op=1,
        hwsrc="00:11:22:33:44:55",
        psrc="192.168.1.50",
        hwdst="00:00:00:00:00:00",
        pdst="192.168.1.1",
    )
    event = ProtocolParser.parse(pkt)
    assert event is not None
    assert event.protocol == "ARP"
    assert event.src_mac == "00:11:22:33:44:55"
    assert event.src_ip == "192.168.1.50"
    assert event.dst_ip == "192.168.1.1"
    assert "Who-has" in (event.info or "")


def test_parse_tcp_syn_packet():
    """Verify parsing a TCP packet with SYN flag set."""
    pkt = (
        Ether(src="00:aa:bb:cc:dd:ee", dst="00:1a:2b:3c:4d:5e")
        / IP(src="192.168.1.100", dst="192.168.1.20")
        / TCP(sport=49152, dport=80, flags="S")
    )
    event = ProtocolParser.parse(pkt)
    assert event is not None
    assert event.protocol == "TCP"
    assert event.src_ip == "192.168.1.100"
    assert event.dst_ip == "192.168.1.20"
    assert event.src_port == 49152
    assert event.dst_port == 80
    assert event.tcp_flags == "SYN"


def test_parse_udp_dns_packet():
    """Verify parsing UDP packet."""
    pkt = (
        Ether(src="00:aa:bb:cc:dd:ee", dst="00:1a:2b:3c:4d:5e")
        / IP(src="192.168.1.100", dst="192.168.1.1")
        / UDP(sport=53000, dport=53)
    )
    event = ProtocolParser.parse(pkt)
    assert event is not None
    assert event.protocol == "UDP"
    assert event.src_port == 53000
    assert event.dst_port == 53


def test_parse_icmp_echo_packet():
    """Verify parsing ICMP Echo Request (Ping)."""
    pkt = (
        Ether(src="00:aa:bb:cc:dd:ee", dst="00:1a:2b:3c:4d:5e")
        / IP(src="192.168.1.100", dst="192.168.1.1")
        / ICMP(type=8, code=0)
    )
    event = ProtocolParser.parse(pkt)
    assert event is not None
    assert event.protocol == "ICMP"
    assert "Echo Request" in (event.info or "")


def test_parse_dhcp_packet_with_hostname():
    """Verify parsing DHCP options and extracting host name."""
    pkt = (
        Ether(src="3c:22:fb:11:22:33", dst="ff:ff:ff:ff:ff:ff")
        / IP(src="0.0.0.0", dst="255.255.255.255")
        / UDP(sport=68, dport=67)
        / BOOTP(chaddr=b"\x3c\x22\xfb\x11\x22\x33")
        / DHCP(options=[("message-type", 3), ("hostname", b"Alice-MacBook"), "end"])
    )
    event = ProtocolParser.parse(pkt)
    assert event is not None
    assert event.protocol == "DHCP"
    assert "Host=Alice-MacBook" in (event.info or "")


def test_no_payload_captured():
    """Verify that application payload is not stored in NetworkEvent attributes."""
    pkt = (
        Ether(src="00:aa:bb:cc:dd:ee", dst="00:1a:2b:3c:4d:5e")
        / IP(src="192.168.1.100", dst="192.168.1.20")
        / TCP(sport=50000, dport=80)
        / b"GET /admin/passwords.txt HTTP/1.1\r\nHost: server\r\n\r\n"
    )
    event = ProtocolParser.parse(pkt)
    assert event is not None
    # Ensure there is no payload attribute or raw payload string preserved
    assert not hasattr(event, "payload")
    assert "passwords.txt" not in (event.info or "")
