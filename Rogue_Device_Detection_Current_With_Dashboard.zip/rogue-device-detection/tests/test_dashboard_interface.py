"""
Unit tests for DashboardDataInterface.
Verifies unprivileged query capabilities, KPI aggregation, device inventory tables,
alert inspection, investigation audit tracking, timeseries queries, and JSON report export.
"""

from datetime import datetime, timezone
from pathlib import Path
import pytest

from database.db import DatabaseManager
from dashboard_interface import DashboardDataInterface
from models.device import Device, DeviceStatus, ApprovedAsset
from models.events import NetworkEvent
from models.alert import Alert, AlertStatus, AlertSeverity
from models.profile import TrafficWindowMetrics


@pytest.fixture
def populated_dashboard(tmp_path):
    """Provide a DashboardDataInterface wired to a populated temporary database."""
    db_file = tmp_path / "test_dashboard.db"
    db = DatabaseManager(db_path=db_file)
    db.init_db()

    now = datetime.now(timezone.utc)

    # 1. Approved asset
    asset = ApprovedAsset(
        mac_address="00:1A:2B:3C:4D:5E",
        device_name="Gateway-01",
        device_type="Gateway",
        assigned_ip="192.168.1.1",
        owner="NetAdmin",
    )
    db.add_approved_asset(asset)

    # 2. Devices
    d1 = Device(
        device_id="mac_00:1A:2B:3C:4D:5E",
        mac_address="00:1A:2B:3C:4D:5E",
        current_ip="192.168.1.1",
        is_approved=True,
        approval_status=DeviceStatus.APPROVED.value,
        vendor="Cisco",
        first_seen=now,
        last_seen=now,
        total_packets=10,
        total_bytes=1000,
    )
    db.upsert_device(d1)

    d2 = Device(
        device_id="mac_B8:27:EB:99:88:77",
        mac_address="B8:27:EB:99:88:77",
        current_ip="192.168.1.199",
        is_approved=False,
        approval_status=DeviceStatus.UNRECOGNIZED.value,
        vendor="Raspberry Pi",
        first_seen=now,
        last_seen=now,
        total_packets=100,
        total_bytes=8000,
    )
    db.upsert_device(d2)

    # 3. Risk scores
    db.upsert_device_risk_score(
        device_id="mac_00:1A:2B:3C:4D:5E",
        risk_score=0.0,
        severity="LOW",
        contributing_signals=[],
        updated_at=now,
    )
    db.upsert_device_risk_score(
        device_id="mac_B8:27:EB:99:88:77",
        risk_score=60.0,
        severity="HIGH",
        contributing_signals=[{"category": "PORT_SCAN", "title": "Port scan", "score_contribution": 35.0, "evidence": {}}],
        updated_at=now,
    )

    # 4. Alerts
    a1 = Alert(
        alert_id="alert-001",
        timestamp=now,
        detection_type="PORT_SCAN_SUSPECT",
        severity=AlertSeverity.HIGH.value,
        title="Port Scan Alert",
        description="Port scan detected",
        source_device_id="mac_B8:27:EB:99:88:77",
        source_ip="192.168.1.199",
        source_mac="B8:27:EB:99:88:77",
        evidence={"distinct_ports": 9},
        status=AlertStatus.NEW.value,
    )
    db.insert_alert(a1)

    a2 = Alert(
        alert_id="alert-002",
        timestamp=now,
        detection_type="GATEWAY_ARP_SPOOF_SUSPECT",
        severity=AlertSeverity.CRITICAL.value,
        title="Gateway Impersonation Alert",
        description="Gateway spoof detected",
        source_device_id="mac_B8:27:EB:99:88:77",
        source_ip="192.168.1.1",
        source_mac="DE:AD:BE:EF:00:01",
        evidence={"claimed_ip": "192.168.1.1"},
        status=AlertStatus.NEW.value,
    )
    db.insert_alert(a2)

    # 5. Events
    ev1 = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.1",
        dst_ip="192.168.1.255",
        ip_version=4,
        protocol="ARP",
        packet_size=42,
        info="ARP test",
    )
    db.insert_event(ev1)

    ev2 = NetworkEvent(
        timestamp=now,
        src_mac="B8:27:EB:99:88:77",
        dst_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.199",
        dst_ip="192.168.1.20",
        ip_version=4,
        protocol="TCP",
        src_port=50000,
        dst_port=80,
        packet_size=60,
        info="TCP test",
    )
    db.insert_event(ev2)

    # 6. Traffic aggregate
    metrics = TrafficWindowMetrics(
        device_id="mac_B8:27:EB:99:88:77",
        window_start=now,
        window_end=now,
        packet_count=50,
        byte_count=3000,
        packet_rate=5.0,
        byte_rate=300.0,
        distinct_targets=1,
        distinct_ports=8,
    )
    db.insert_traffic_aggregate(metrics)

    return DashboardDataInterface(db_path=db_file)


def test_get_system_overview(populated_dashboard):
    """Verify KPI counts and overview calculations."""
    ov = populated_dashboard.get_system_overview()
    assert ov["total_devices"] == 2
    assert ov["approved_devices"] == 1
    assert ov["unrecognized_devices"] == 1
    assert ov["total_alerts"] == 2
    assert ov["critical_alerts"] == 1
    assert ov["high_alerts"] == 1
    assert ov["new_alerts"] == 2
    assert ov["max_risk_score"] == 60.0
    assert ov["highest_risk_device"] == "mac_B8:27:EB:99:88:77"
    assert ov["database_size_kb"] > 0


def test_get_devices_table(populated_dashboard):
    """Verify tabular device records with joined risk scores."""
    devices = populated_dashboard.get_devices_table()
    assert len(devices) == 2

    dev_map = {d["device_id"]: d for d in devices}
    assert "mac_B8:27:EB:99:88:77" in dev_map
    assert dev_map["mac_B8:27:EB:99:88:77"]["risk_score"] == 60.0
    assert dev_map["mac_B8:27:EB:99:88:77"]["risk_severity"] == "HIGH"
    assert dev_map["mac_B8:27:EB:99:88:77"]["vendor"] == "Raspberry Pi"

    assert dev_map["mac_00:1A:2B:3C:4D:5E"]["is_approved"] is True
    assert dev_map["mac_00:1A:2B:3C:4D:5E"]["risk_score"] == 0.0


def test_get_device_detail(populated_dashboard):
    """Verify single device inspection with correlated alerts."""
    detail = populated_dashboard.get_device_detail("mac_B8:27:EB:99:88:77")
    assert detail is not None
    assert detail["device"]["mac_address"] == "B8:27:EB:99:88:77"
    assert detail["risk_evaluation"]["risk_score"] == 60.0
    assert len(detail["alerts"]) >= 1

    # Non-existent device returns None
    assert populated_dashboard.get_device_detail("non_existent") is None


def test_get_alerts_table_and_filtering(populated_dashboard):
    """Verify alert filtering by status and severity."""
    all_alerts = populated_dashboard.get_alerts_table()
    assert len(all_alerts) == 2

    crit_alerts = populated_dashboard.get_alerts_table(severity_filter="CRITICAL")
    assert len(crit_alerts) == 1
    assert crit_alerts[0]["detection_type"] == "GATEWAY_ARP_SPOOF_SUSPECT"

    high_alerts = populated_dashboard.get_alerts_table(severity_filter="HIGH")
    assert len(high_alerts) == 1
    assert high_alerts[0]["detection_type"] == "PORT_SCAN_SUSPECT"


def test_get_alert_detail_and_status_update(populated_dashboard):
    """Verify alert status transition and audit history recording."""
    detail = populated_dashboard.get_alert_detail("alert-001")
    assert detail is not None
    assert detail["alert"]["alert_id"] == "alert-001"
    assert detail["alert"]["status"] == "NEW"

    # Update status to ACKNOWLEDGED
    success = populated_dashboard.update_alert_status(
        alert_id="alert-001",
        new_status="ACKNOWLEDGED",
        analyst="Alice Lead",
        notes="Investigating suspicious scan from lab node",
    )
    assert success is True

    # Check updated detail and history
    updated = populated_dashboard.get_alert_detail("alert-001")
    assert updated["alert"]["status"] == "ACKNOWLEDGED"
    assert len(updated["history"]) == 2
    hist = updated["history"][-1]
    assert hist["previous_status"] == "NEW"
    assert hist["new_status"] == "ACKNOWLEDGED"
    assert hist["changed_by"] == "Alice Lead"
    assert "suspicious scan" in hist["comment"]


def test_get_traffic_timeseries(populated_dashboard):
    """Verify time series querying for throughput charts."""
    series = populated_dashboard.get_traffic_timeseries(device_id="mac_B8:27:EB:99:88:77")
    assert len(series) == 1
    point = series[0]
    assert point["packet_count"] == 50
    assert point["packet_rate"] == 5.0
    assert point["distinct_ports"] == 8


def test_protocol_and_risk_distribution(populated_dashboard):
    """Verify aggregated distribution queries."""
    proto_dist = populated_dashboard.get_protocol_distribution()
    assert proto_dist.get("ARP", 0) == 1
    assert proto_dist.get("TCP", 0) == 1

    risk_dist = populated_dashboard.get_risk_distribution()
    assert risk_dist["LOW"] == 1
    assert risk_dist["HIGH"] == 1
    assert risk_dist["CRITICAL"] == 0


def test_export_security_report(populated_dashboard):
    """Verify JSON exportable security report dictionary."""
    report = populated_dashboard.export_security_report()
    assert "generated_at" in report
    assert "overview" in report
    assert "devices" in report
    assert "recent_alerts" in report
    assert "risk_distribution" in report
    assert "protocol_distribution" in report
    assert len(report["devices"]) == 2
    assert len(report["recent_alerts"]) == 2
