"""
Unit tests for the independent ArpSpoofDetector module.
Tests gateway mapping integrity, rapid mapping flapping, conflicting IP-to-MAC claims, and cooldowns.
"""

from datetime import datetime, timezone
import pytest

from detection.arp_spoof_detector import ArpSpoofDetector
from models.events import NetworkEvent
from models.alert import AlertSeverity


def test_gateway_arp_spoof_critical_alert():
    """Verify that an unauthorized MAC claiming the configured default gateway IP triggers a CRITICAL alert."""
    detector = ArpSpoofDetector(
        expected_gateway_ip="192.168.1.1",
        expected_gateway_mac="00:1A:2B:3C:4D:5E",
        gateway_severity="CRITICAL",
    )
    now = datetime.now(timezone.utc)

    # Rogue device DE:AD:BE:EF:00:01 claims 192.168.1.1
    ev = NetworkEvent(
        timestamp=now,
        src_mac="DE:AD:BE:EF:00:01",
        src_ip="192.168.1.1",
        protocol="ARP",
        info="Gratuitous ARP: 192.168.1.1 is at DE:AD:BE:EF:00:01",
    )
    alerts = detector.evaluate(ev, None)

    assert len(alerts) == 1
    alert = alerts[0]
    assert alert.detection_type == "GATEWAY_ARP_SPOOF_SUSPECT"
    assert alert.severity == AlertSeverity.CRITICAL.value
    assert alert.source_ip == "192.168.1.1"
    assert alert.source_mac == "DE:AD:BE:EF:00:01"
    assert alert.evidence["expected_gateway_mac"] == "00:1A:2B:3C:4D:5E"


def test_legitimate_gateway_arp_no_alert():
    """Verify that legitimate ARP announcements from the authorized gateway MAC trigger no alerts."""
    detector = ArpSpoofDetector(
        expected_gateway_ip="192.168.1.1",
        expected_gateway_mac="00:1A:2B:3C:4D:5E",
    )
    now = datetime.now(timezone.utc)

    ev = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.1",
        protocol="ARP",
        info="ARP Is-at: 192.168.1.1 is at 00:1A:2B:3C:4D:5E",
    )
    alerts = detector.evaluate(ev, None)
    assert len(alerts) == 0


def test_rapid_arp_flapping_detection():
    """Verify that rapid MAC alternation claiming the same IP triggers RAPID_FLAPPING alert."""
    detector = ArpSpoofDetector(
        rapid_change_window_seconds=10.0,
        flap_count_threshold=2,
    )
    now = datetime.now(timezone.utc)
    ip = "192.168.1.55"

    # Observation 1: MAC A claims IP
    ev1 = NetworkEvent(timestamp=now, src_mac="11:22:33:44:55:66", src_ip=ip, protocol="ARP")
    detector.evaluate(ev1, None)

    # Observation 2: MAC B claims IP (transition 1)
    ev2 = NetworkEvent(timestamp=now, src_mac="AA:BB:CC:DD:EE:FF", src_ip=ip, protocol="ARP")
    detector.evaluate(ev2, None)

    # Observation 3: MAC A claims IP again (transition 2 -> rapid flapping!)
    ev3 = NetworkEvent(timestamp=now, src_mac="11:22:33:44:55:66", src_ip=ip, protocol="ARP")
    alerts = detector.evaluate(ev3, None)

    assert len(alerts) >= 1
    assert any(a.detection_type == "ARP_RAPID_FLAPPING_SUSPECT" for a in alerts)


def test_arp_spoof_cooldown_deduplication():
    """Verify that duplicate gateway spoof packets within cooldown do not flood alerts."""
    detector = ArpSpoofDetector(
        expected_gateway_ip="192.168.1.1",
        expected_gateway_mac="00:1A:2B:3C:4D:5E",
        cooldown_seconds=60.0,
    )
    now = datetime.now(timezone.utc)

    ev = NetworkEvent(
        timestamp=now,
        src_mac="DE:AD:BE:EF:00:01",
        src_ip="192.168.1.1",
        protocol="ARP",
    )
    alerts1 = detector.evaluate(ev, None)
    assert len(alerts1) == 1

    # Immediate second spoof packet
    alerts2 = detector.evaluate(ev, None)
    assert len(alerts2) == 0
