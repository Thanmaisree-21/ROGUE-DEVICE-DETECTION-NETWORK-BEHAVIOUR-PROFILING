"""
Unit tests for the SQLite DatabaseManager.
Verifies table creation, CRUD operations, transactions, and audit history.
"""

from datetime import datetime, timezone
import tempfile
from pathlib import Path
import pytest

from database.db import DatabaseManager
from models.device import Device, DeviceIPObservation, ApprovedAsset, DeviceStatus
from models.events import NetworkEvent
from models.alert import Alert, AlertStatus, AlertSeverity
from models.profile import TrafficWindowMetrics, DeviceBaseline


@pytest.fixture
def temp_db(tmp_path):
    """Fixture providing an initialized DatabaseManager using a temporary file."""
    db_file = tmp_path / "test_rogue.db"
    mgr = DatabaseManager(db_path=db_file)
    mgr.init_db()
    return mgr


def test_init_db(temp_db):
    """Verify that tables exist and foreign keys are enabled."""
    with temp_db.transaction() as conn:
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table';"
        ).fetchall()
        table_names = {t["name"] for t in tables}

    expected = {
        "approved_assets",
        "devices",
        "device_ip_history",
        "network_events",
        "traffic_aggregates",
        "device_baselines",
        "alerts",
        "alert_history",
    }
    assert expected.issubset(table_names)


def test_approved_asset_crud(temp_db):
    """Verify storing, retrieving, and updating approved network assets."""
    asset = ApprovedAsset(
        mac_address="00:11:22:33:44:55",
        device_name="Core-Switch",
        device_type="Switch",
        assigned_ip="10.0.0.1",
        owner="NetAdmin",
        description="Core distribution switch",
    )
    temp_db.add_approved_asset(asset)

    retrieved = temp_db.get_approved_asset("00:11:22:33:44:55")
    assert retrieved is not None
    assert retrieved.device_name == "Core-Switch"
    assert retrieved.mac_address == "00:11:22:33:44:55"

    all_assets = temp_db.get_all_approved_assets()
    assert len(all_assets) == 1


def test_device_upsert_and_query(temp_db):
    """Verify device registration, updating last seen, and traffic stats."""
    now = datetime.now(timezone.utc)
    dev = Device(
        device_id="mac_AA:BB:CC:DD:EE:FF",
        mac_address="AA:BB:CC:DD:EE:FF",
        current_ip="192.168.1.50",
        first_seen=now,
        last_seen=now,
        is_approved=True,
        approval_status=DeviceStatus.APPROVED.value,
        vendor="Apple",
        total_packets=5,
        total_bytes=500,
    )
    temp_db.upsert_device(dev)

    fetched = temp_db.get_device_by_mac("AA:BB:CC:DD:EE:FF")
    assert fetched is not None
    assert fetched.current_ip == "192.168.1.50"
    assert fetched.is_approved is True
    assert fetched.total_packets == 5

    # Update with additional packets
    dev.total_packets = 10
    dev.total_bytes = 1000
    temp_db.upsert_device(dev)

    updated = temp_db.get_device_by_id("mac_AA:BB:CC:DD:EE:FF")
    # Total packets adds up because upsert sums incoming delta
    assert updated.total_packets == 15


def test_device_ip_history(temp_db):
    """Verify tracking dynamic IP allocations for a device."""
    now = datetime.now(timezone.utc)
    dev_id = "mac_AA:BB:CC:11:22:33"

    dev = Device(
        device_id=dev_id,
        mac_address="AA:BB:CC:11:22:33",
        current_ip="192.168.1.10",
        first_seen=now,
        last_seen=now,
    )
    temp_db.upsert_device(dev)

    obs1 = DeviceIPObservation(device_id=dev_id, ip_address="192.168.1.10", observed_at=now, source="DHCP")
    obs2 = DeviceIPObservation(device_id=dev_id, ip_address="192.168.1.99", observed_at=now, source="ARP")

    temp_db.record_ip_observation(obs1)
    temp_db.record_ip_observation(obs2)

    sharing = temp_db.get_devices_sharing_ip("192.168.1.10")
    assert dev_id in sharing


def test_network_events_insert(temp_db):
    """Verify recording network event metadata without payloads."""
    now = datetime.now(timezone.utc)
    event = NetworkEvent(
        timestamp=now,
        src_mac="00:1A:2B:3C:4D:5E",
        dst_mac="00:50:56:A1:B2:C3",
        src_ip="192.168.1.1",
        dst_ip="192.168.1.10",
        protocol="TCP",
        src_port=443,
        dst_port=52341,
        packet_size=1500,
        tcp_flags="ACK",
        info="HTTPS Traffic",
    )
    row_id = temp_db.insert_event(event)
    assert row_id > 0

    recent = temp_db.get_recent_events(limit=10)
    assert len(recent) == 1
    assert recent[0].protocol == "TCP"
    assert recent[0].packet_size == 1500


def test_alerts_lifecycle_and_audit(temp_db):
    """Verify alert insertion, status updates, and investigation audit trail."""
    now = datetime.now(timezone.utc)
    alert = Alert(
        detection_type="UNAPPROVED_DEVICE",
        severity=AlertSeverity.MEDIUM.value,
        source_mac="DE:AD:BE:EF:00:99",
        source_ip="192.168.1.250",
        title="Unrecognized Device",
        description="Unknown device communicating on network",
        evidence={"observed_mac": "DE:AD:BE:EF:00:99"},
        status=AlertStatus.NEW.value,
        timestamp=now,
    )
    alert_id = temp_db.insert_alert(alert)
    assert alert_id == alert.alert_id

    # Retrieve alert
    fetched = temp_db.get_alert(alert_id)
    assert fetched is not None
    assert fetched.status == AlertStatus.NEW.value
    assert fetched.evidence["observed_mac"] == "DE:AD:BE:EF:00:99"

    # Update alert status with analyst investigation notes
    success = temp_db.update_alert_status(
        alert_id=alert_id,
        new_status=AlertStatus.ACKNOWLEDGED.value,
        analyst="Officer Charlie",
        notes="Reviewing DHCP lease tables.",
    )
    assert success is True

    updated = temp_db.get_alert(alert_id)
    assert updated.status == AlertStatus.ACKNOWLEDGED.value

    # Verify audit history log
    history = temp_db.get_alert_history(alert_id)
    assert len(history) == 2  # 1 initial + 1 update
    assert history[1].new_status == AlertStatus.ACKNOWLEDGED.value
    assert history[1].changed_by == "Officer Charlie"
