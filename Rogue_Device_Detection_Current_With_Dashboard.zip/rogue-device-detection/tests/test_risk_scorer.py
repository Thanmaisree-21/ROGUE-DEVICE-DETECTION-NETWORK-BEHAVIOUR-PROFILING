"""
Unit tests for the explainable RiskScorer module.
Tests scoring weights, anti-double-counting logic, severity mappings, and evidence breakdown.
"""

from datetime import datetime, timezone
import pytest

from profiling.risk_scorer import RiskScorer, RiskCategory
from config import RiskScoringConfig
from models.device import Device, DeviceStatus
from models.alert import Alert, AlertSeverity, AlertStatus


def test_approved_device_zero_risk():
    """Verify that an approved device with no security alerts receives a score of 0.0 (LOW)."""
    scorer = RiskScorer()
    now = datetime.now(timezone.utc)
    dev = Device(
        device_id="mac_00:1A:2B:3C:4D:5E",
        is_approved=True,
        approval_status=DeviceStatus.APPROVED.value,
        first_seen=now,
        last_seen=now,
    )

    report = scorer.evaluate_device_risk(dev, alerts=[])
    assert report.overall_score == 0.0
    assert report.severity == "LOW"
    assert len(report.signals) == 0


def test_unknown_device_base_risk():
    """Verify that an unapproved device with no alerts receives the expected base risk penalty."""
    scorer = RiskScorer()
    now = datetime.now(timezone.utc)
    dev = Device(
        device_id="mac_B8:27:EB:99:88:77",
        is_approved=False,
        approval_status=DeviceStatus.UNRECOGNIZED.value,
        first_seen=now,
        last_seen=now,
    )

    report = scorer.evaluate_device_risk(dev, alerts=[])
    assert report.overall_score == 25.0
    assert report.severity == "LOW"
    assert len(report.signals) == 1
    assert report.signals[0].category == RiskCategory.UNKNOWN_DEVICE.value


def test_composite_risk_aggregation():
    """Verify combining unknown status, port scanning, and ARP spoofing into an explainable score."""
    scorer = RiskScorer()
    now = datetime.now(timezone.utc)
    dev = Device(
        device_id="mac_B8:27:EB:99:88:77",
        is_approved=False,
        approval_status=DeviceStatus.UNRECOGNIZED.value,
    )
    alerts = [
        Alert(
            detection_type="PORT_SCAN_SUSPECT",
            severity=AlertSeverity.HIGH.value,
            title="Port Scan",
            evidence={"probed_ports_sample": [21, 22, 80]},
        ),
        Alert(
            detection_type="GATEWAY_ARP_SPOOF_SUSPECT",
            severity=AlertSeverity.CRITICAL.value,
            title="Gateway Spoof",
            evidence={"expected_gateway_mac": "00:1A:2B:3C:4D:5E"},
        ),
    ]

    report = scorer.evaluate_device_risk(dev, alerts)
    # 25 (unknown) + ~29.7 (port scan) + 60 (gateway arp) => capped at 100.0 max
    assert report.overall_score >= 80.0
    assert report.severity == "CRITICAL"
    assert len(report.signals) == 3
    assert "Contributing risk signals:" in report.explanation


def test_anti_double_counting_repeated_alerts():
    """Verify that 20 repeated port scan alerts do not blow up the score past the category cap."""
    cfg = RiskScoringConfig(port_scan_max_score=35.0)
    scorer = RiskScorer(cfg)
    dev = Device(
        device_id="mac_00:11:22:33:44:55",
        is_approved=True,
        approval_status=DeviceStatus.APPROVED.value,
    )

    # 15 repeated port scan alerts
    alerts = [
        Alert(
            detection_type="PORT_SCAN_SUSPECT",
            severity=AlertSeverity.HIGH.value,
            title=f"Port Scan #{i}",
        )
        for i in range(15)
    ]

    report = scorer.evaluate_device_risk(dev, alerts)
    # The port scan category must NOT exceed the category max score of 35.0!
    assert report.category_scores[RiskCategory.PORT_SCAN.value] <= 35.0
    assert report.overall_score <= 35.0
