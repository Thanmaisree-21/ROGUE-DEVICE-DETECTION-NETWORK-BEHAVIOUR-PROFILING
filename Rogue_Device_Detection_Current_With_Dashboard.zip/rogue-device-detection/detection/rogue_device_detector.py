"""
Rogue device and network anomaly detectors.
Identifies unrecognized devices not found in the approved assets baseline,
alongside companion detectors for ARP spoofing and port scanning.
"""

from datetime import datetime, timezone
import logging
from typing import Dict, List, Optional, Any, Set
from collections import defaultdict, deque

from models.alert import Alert, AlertSeverity, AlertStatus
from models.events import NetworkEvent
from models.device import Device, DeviceStatus
from detection.base_detector import BaseDetector

logger = logging.getLogger(__name__)


class RogueDeviceDetector(BaseDetector):
    """
    Detector that alerts when an observed device is not present in the approved inventory.
    Emphasizes that unrecognized devices are not automatically malicious.
    """

    def __init__(
        self,
        cooldown_seconds: float = 60.0,
        severity: str = AlertSeverity.MEDIUM.value,
        enabled: bool = True,
    ):
        super().__init__(
            name="RogueDeviceDetector",
            description="Identifies unauthorized or unrecognized devices communicating on the network.",
            enabled=enabled,
            cooldown_seconds=cooldown_seconds,
        )
        self.severity = severity

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate if the transmitting device is unapproved / unrecognized.
        """
        if not self.enabled or not device:
            return []

        # If the device is approved, no alert is needed
        if device.is_approved or device.approval_status == DeviceStatus.APPROVED.value:
            return []

        # Deduplication key based on device ID and detection type
        key = f"unapproved_device_{device.device_id}"
        event_epoch = event.timestamp.timestamp() if event.timestamp else None

        if self.is_in_cooldown(key, event_epoch):
            return []

        self.record_cooldown(key, event_epoch)

        mac_display = device.mac_address or "Unknown MAC"
        ip_display = device.current_ip or event.src_ip or "Unknown IP"
        vendor_display = device.vendor or "Unknown Vendor"

        title = f"Unrecognized Device Observed: {mac_display}"
        description = (
            f"Device with MAC '{mac_display}' and IP '{ip_display}' ({vendor_display}) was observed "
            f"transmitting traffic using {event.protocol}. This device is not listed in the approved-device "
            f"inventory. Note: Unrecognized devices require asset verification and are not automatically malicious."
        )

        evidence = {
            "source_device_id": device.device_id,
            "mac_address": device.mac_address,
            "ip_address": device.current_ip or event.src_ip,
            "first_seen": device.first_seen.isoformat(),
            "last_seen": device.last_seen.isoformat(),
            "vendor": device.vendor,
            "hostname": device.hostname,
            "trigger_protocol": event.protocol,
            "trigger_event_info": event.info,
            "classification_reason": "Device identifier is absent from the approved-device inventory.",
            "recommended_action": "Verify if this device belongs to an authorized employee, guest, or contractor.",
        }

        alert = Alert(
            detection_type="UNAPPROVED_DEVICE",
            severity=self.severity,
            source_device_id=device.device_id,
            source_mac=device.mac_address,
            source_ip=device.current_ip or event.src_ip,
            target_ip=event.dst_ip,
            target_port=event.dst_port,
            title=title,
            description=description,
            evidence=evidence,
            status=AlertStatus.NEW.value,
            timestamp=event.timestamp,
        )

        logger.warning(
            "ALERT GENERATED: [UNAPPROVED_DEVICE] Source: %s (IP: %s)",
            device.device_id, device.current_ip
        )
        return [alert]


class ArpConflictDetector(BaseDetector):
    """
    Detector that alerts on ARP spoofing or conflicting hardware addresses claiming the same IP.
    """

    def __init__(
        self,
        cooldown_seconds: float = 30.0,
        severity: str = AlertSeverity.HIGH.value,
        enabled: bool = True,
    ):
        super().__init__(
            name="ArpConflictDetector",
            description="Detects anomalous ARP updates or multiple MAC addresses claiming identical IP addresses.",
            enabled=enabled,
            cooldown_seconds=cooldown_seconds,
        )
        self.severity = severity

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        if not self.enabled or not context:
            return []

        conflict_msg = context.get("ip_conflict")
        if not conflict_msg:
            return []

        key = f"arp_conflict_{event.src_ip}"
        event_epoch = event.timestamp.timestamp() if event.timestamp else None

        if self.is_in_cooldown(key, event_epoch):
            return []

        self.record_cooldown(key, event_epoch)

        alert = Alert(
            detection_type="ARP_SPOOF_SUSPECT",
            severity=self.severity,
            source_device_id=device.device_id if device else None,
            source_mac=event.src_mac,
            source_ip=event.src_ip,
            target_ip=event.dst_ip,
            target_port=None,
            title=f"Potential ARP Spoof / IP Conflict on {event.src_ip}",
            description=conflict_msg,
            evidence={
                "ip_address": event.src_ip,
                "claiming_mac": event.src_mac,
                "conflict_details": conflict_msg,
                "protocol": event.protocol,
                "timestamp": event.timestamp.isoformat(),
            },
            status=AlertStatus.NEW.value,
            timestamp=event.timestamp,
        )

        logger.warning("ALERT GENERATED: [ARP_SPOOF_SUSPECT] %s", conflict_msg)
        return [alert]


class StreamingPortScanDetector(BaseDetector):
    """
    Detector that observes rolling port access patterns per source in real time.
    Flags sources probing many distinct destination ports within a short window.
    """

    def __init__(
        self,
        unique_ports_threshold: int = 8,
        window_seconds: float = 15.0,
        cooldown_seconds: float = 60.0,
        severity: str = AlertSeverity.HIGH.value,
        enabled: bool = True,
    ):
        super().__init__(
            name="StreamingPortScanDetector",
            description="Detects rapid port scan probes across multiple distinct destination ports.",
            enabled=enabled,
            cooldown_seconds=cooldown_seconds,
        )
        self.threshold = unique_ports_threshold
        self.window_seconds = window_seconds
        self.severity = severity
        # src_key -> deque of (timestamp, dst_port, dst_ip)
        self._probes: Dict[str, deque] = defaultdict(deque)

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        if not self.enabled or event.dst_port is None or not event.src_ip:
            return []

        # Focus primarily on TCP SYN probes or UDP probes
        if event.protocol == "TCP" and event.tcp_flags and "SYN" not in event.tcp_flags:
            return []

        src_key = device.device_id if device else event.src_ip
        now_sec = event.timestamp.timestamp()
        queue = self._probes[src_key]

        # Evict probes outside sliding time window
        while queue and (now_sec - queue[0][0]) > self.window_seconds:
            queue.popleft()

        queue.append((now_sec, event.dst_port, event.dst_ip))

        unique_ports = {item[1] for item in queue}
        if len(unique_ports) >= self.threshold:
            cd_key = f"port_scan_{src_key}"
            if self.is_in_cooldown(cd_key, now_sec):
                return []

            self.record_cooldown(cd_key, now_sec)

            alert = Alert(
                detection_type="PORT_SCAN_SUSPECT",
                severity=self.severity,
                source_device_id=device.device_id if device else None,
                source_mac=event.src_mac,
                source_ip=event.src_ip,
                target_ip=event.dst_ip,
                target_port=event.dst_port,
                title=f"Port Scan Activity Suspected from {event.src_ip}",
                description=(
                    f"Host at IP '{event.src_ip}' (MAC: {event.src_mac or 'Unknown'}) probed "
                    f"{len(unique_ports)} distinct ports within {self.window_seconds:.0f} seconds."
                ),
                evidence={
                    "probed_ports": sorted(list(unique_ports)),
                    "total_probes_in_window": len(queue),
                    "unique_ports_count": len(unique_ports),
                    "window_duration_seconds": self.window_seconds,
                    "target_host": event.dst_ip,
                },
                status=AlertStatus.NEW.value,
                timestamp=event.timestamp,
            )
            logger.warning("ALERT GENERATED: [PORT_SCAN_SUSPECT] %s probed %d ports", event.src_ip, len(unique_ports))
            return [alert]

        return []
