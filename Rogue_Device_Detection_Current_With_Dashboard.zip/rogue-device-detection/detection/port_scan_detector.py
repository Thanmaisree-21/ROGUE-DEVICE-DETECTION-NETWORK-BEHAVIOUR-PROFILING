"""
Port scanning detection module.
Monitors rapid connection attempts across distinct destination ports (vertical scanning)
and multiple target hosts (horizontal host sweeping), inspecting TCP connection patterns.
"""

from collections import defaultdict, deque
from datetime import datetime, timezone
import logging
from typing import Dict, List, Optional, Any, Set

from config import PortScanDetectorConfig
from detection.base_detector import BaseDetector
from models.alert import Alert, AlertSeverity, AlertStatus
from models.device import Device
from models.events import NetworkEvent

logger = logging.getLogger(__name__)


class PortScanDetector(BaseDetector):
    """
    Independent detector identifying port scanning and network reconnaissance activities.
    Tracks distinct destination ports, connection attempt volumes, and target host dispersion.
    """

    def __init__(
        self,
        config: Optional[PortScanDetectorConfig] = None,
        ports_threshold: Optional[int] = None,
        connection_attempts_threshold: Optional[int] = None,
        target_hosts_threshold: Optional[int] = None,
        window_seconds: Optional[float] = None,
        cooldown_seconds: Optional[float] = None,
        severity: Optional[str] = None,
        enabled: Optional[bool] = None,
    ):
        cfg = config or PortScanDetectorConfig()
        super().__init__(
            name="PortScanDetector",
            description="Identifies vertical port scanning and horizontal host reconnaissance.",
            enabled=enabled if enabled is not None else cfg.enabled,
            cooldown_seconds=cooldown_seconds if cooldown_seconds is not None else cfg.cooldown_seconds,
        )
        self.ports_threshold = ports_threshold if ports_threshold is not None else cfg.ports_threshold
        self.connection_attempts_threshold = (
            connection_attempts_threshold if connection_attempts_threshold is not None else cfg.connection_attempts_threshold
        )
        self.target_hosts_threshold = (
            target_hosts_threshold if target_hosts_threshold is not None else cfg.target_hosts_threshold
        )
        self.window_seconds = window_seconds if window_seconds is not None else cfg.window_seconds
        self.severity = severity or cfg.severity

        # Sliding window history per source identifier:
        # src_id -> deque of (timestamp_epoch, dst_ip, dst_port, protocol, tcp_flags)
        self._probe_history: Dict[str, deque] = defaultdict(deque)

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate an observed network event for signs of reconnaissance or scanning.
        """
        if not self.enabled or not event.src_ip:
            return []

        # Only evaluate events that involve targeted destination ports
        if event.dst_port is None:
            return []

        # Ignore broadcast destinations
        if event.dst_ip in ("255.255.255.255", "0.0.0.0") or (event.dst_ip and event.dst_ip.startswith("224.")):
            return []

        src_key = device.device_id if device else event.src_ip
        now_epoch = event.timestamp.timestamp() if event.timestamp else datetime.now(timezone.utc).timestamp()
        queue = self._probe_history[src_key]

        # Evict records older than the sliding window
        while queue and (now_epoch - queue[0][0]) > self.window_seconds:
            queue.popleft()

        queue.append((
            now_epoch,
            event.dst_ip,
            event.dst_port,
            event.protocol,
            event.tcp_flags,
        ))

        # Calculate sliding window metrics
        distinct_ports: Set[int] = {item[2] for item in queue}
        distinct_targets: Set[str] = {item[1] for item in queue if item[1]}
        total_attempts = len(queue)
        syn_count = sum(1 for item in queue if item[4] and "SYN" in item[4])

        trigger_reasons = []
        is_vertical_scan = len(distinct_ports) >= self.ports_threshold
        is_horizontal_sweep = len(distinct_targets) >= self.target_hosts_threshold
        is_rapid_connect = total_attempts >= self.connection_attempts_threshold

        if is_vertical_scan:
            trigger_reasons.append(
                f"Probed {len(distinct_ports)} distinct destination ports (Threshold: {self.ports_threshold})"
            )
        if is_horizontal_sweep:
            trigger_reasons.append(
                f"Probed {len(distinct_targets)} distinct target hosts (Threshold: {self.target_hosts_threshold})"
            )
        if is_rapid_connect and (len(distinct_ports) >= max(3, self.ports_threshold // 2)):
            trigger_reasons.append(
                f"Generated {total_attempts} connection attempts within {self.window_seconds:.0f}s window"
            )

        if not trigger_reasons:
            return []

        # Check cooldown to prevent duplicate alerts for the same source
        cooldown_key = f"port_scan_{src_key}"
        if self.is_in_cooldown(cooldown_key, now_epoch):
            return []

        self.record_cooldown(cooldown_key, now_epoch)

        reason_str = " | ".join(trigger_reasons)
        mac_display = event.src_mac or (device.mac_address if device else "Unknown MAC")
        primary_target = event.dst_ip if len(distinct_targets) == 1 else f"Multiple ({len(distinct_targets)} targets)"

        title = f"Port Scanning Behavior Suspected from {event.src_ip}"
        description = (
            f"Host at IP '{event.src_ip}' (MAC: {mac_display}) exhibited traffic consistent with port scanning "
            f"or reconnaissance activity: {reason_str}. Observation period: {self.window_seconds:.0f}s."
        )

        evidence = {
            "source_ip": event.src_ip,
            "source_mac": mac_display,
            "source_device_id": device.device_id if device else None,
            "target_ip": primary_target,
            "distinct_ports_count": len(distinct_ports),
            "probed_ports_sample": sorted(list(distinct_ports))[:20],
            "distinct_targets_count": len(distinct_targets),
            "total_attempts_in_window": total_attempts,
            "syn_probe_count": syn_count,
            "window_seconds": self.window_seconds,
            "trigger_reasons": trigger_reasons,
            "analyst_guidance": "Examine if the source is an authorized vulnerability scanner or an unauthorized host probing network assets.",
        }

        alert = Alert(
            detection_type="PORT_SCAN_SUSPECT",
            severity=self.severity,
            source_device_id=device.device_id if device else None,
            source_mac=event.src_mac,
            source_ip=event.src_ip,
            target_ip=event.dst_ip,
            target_port=event.dst_port,
            title=title,
            description=description,
            evidence=evidence,
            status=AlertStatus.NEW.value,
            timestamp=event.timestamp,
        )

        logger.warning(
            "ALERT: [PORT_SCAN_SUSPECT] Source=%s, Ports=%d, Targets=%d (%s)",
            event.src_ip, len(distinct_ports), len(distinct_targets), reason_str
        )
        return [alert]
