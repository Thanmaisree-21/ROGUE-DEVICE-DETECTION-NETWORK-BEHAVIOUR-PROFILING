"""
Base detector interface and common alerting helpers.
Defines detector contracts, cooldown deduplication, and helper utilities.
"""

from abc import ABC, abstractmethod
from datetime import datetime
import logging
import time
from typing import Dict, List, Optional, Any

from models.alert import Alert
from models.events import NetworkEvent
from models.device import Device

logger = logging.getLogger(__name__)


class BaseDetector(ABC):
    """
    Abstract Base Class for all detection modules.
    Provides alert cooldown management to prevent alert flooding.
    """

    def __init__(
        self,
        name: str,
        description: str,
        enabled: bool = True,
        cooldown_seconds: float = 60.0,
    ):
        self.name = name
        self.description = description
        self.enabled = enabled
        self.cooldown_seconds = cooldown_seconds
        # Cooldown tracker: deduplication key -> last fired epoch timestamp
        self._last_alerted: Dict[str, float] = {}

    def is_in_cooldown(self, key: str, current_ts: Optional[float] = None) -> bool:
        """
        Check if a given deduplication key is currently within its cooldown window.
        """
        now = current_ts if current_ts is not None else time.time()
        last = self._last_alerted.get(key)
        if last is None:
            return False
        return (now - last) < self.cooldown_seconds

    def record_cooldown(self, key: str, current_ts: Optional[float] = None) -> None:
        """Record timestamp of fired alert for a deduplication key."""
        now = current_ts if current_ts is not None else time.time()
        self._last_alerted[key] = now

    def reset_cooldown(self, key: Optional[str] = None) -> None:
        """Reset cooldown for a specific key or all keys."""
        if key:
            self._last_alerted.pop(key, None)
        else:
            self._last_alerted.clear()

    @abstractmethod
    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate an observed network event and device state.
        Returns a list of Alert instances if suspicious/unauthorized activity is detected.
        """
        pass
