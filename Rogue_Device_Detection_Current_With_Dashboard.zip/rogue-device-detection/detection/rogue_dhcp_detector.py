"""
Rogue DHCP detection module.
Parses DHCP traffic specifically targeting server-side messages (OFFER, ACK),
identifies unapproved DHCP server identifiers, detects multiple competing DHCP servers,
and flags unexpected DHCP presence in static-only network environments.
"""

from datetime import datetime, timezone
import logging
from typing import Dict, List, Optional, Any, Set

from config import RogueDhcpDetectorConfig
from detection.base_detector import BaseDetector
from models.alert import Alert, AlertSeverity, AlertStatus
from models.device import Device
from models.events import NetworkEvent
from sensor.device_discovery import normalize_mac

logger = logging.getLogger(__name__)


class RogueDhcpDetector(BaseDetector):
    """
    Detector identifying unauthorized DHCP servers operating on the monitored network.
    Examines DHCP message types and server identifiers (Option 54) to differentiate
    legitimate client broadcasts from unauthorized server lease offers.
    """

    def __init__(
        self,
        config: Optional[RogueDhcpDetectorConfig] = None,
        approved_dhcp_servers: Optional[List[str]] = None,
        allow_no_dhcp: Optional[bool] = None,
        cooldown_seconds: Optional[float] = None,
        severity: Optional[str] = None,
        enabled: Optional[bool] = None,
    ):
        cfg = config or RogueDhcpDetectorConfig()
        super().__init__(
            name="RogueDhcpDetector",
            description="Identifies unapproved DHCP server offers, rogue server IDs, and multi-server conflicts.",
            enabled=enabled if enabled is not None else cfg.enabled,
            cooldown_seconds=cooldown_seconds if cooldown_seconds is not None else cfg.cooldown_seconds,
        )
        servers = approved_dhcp_servers if approved_dhcp_servers is not None else cfg.approved_dhcp_servers
        self.approved_dhcp_servers: Set[str] = {
            s.upper() if ":" in s else s for s in servers
        }
        self.allow_no_dhcp = allow_no_dhcp if allow_no_dhcp is not None else cfg.allow_no_dhcp
        self.severity = severity or cfg.severity

        # Track observed DHCP servers during the session: server_identifier -> first_seen_ts
        self._observed_servers: Dict[str, float] = {}
        self._primary_server: Optional[str] = None

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate an event for unauthorized DHCP server responses.
        """
        if not self.enabled or event.protocol != "DHCP":
            return []

        # Discriminate DHCP message types:
        # Crucial requirement: ONLY inspect server OFFER or ACK messages.
        # Client DISCOVER or REQUEST broadcasts must NOT be treated as server offers!
        msg_type = (event.dhcp_message_type or "").upper()
        if not msg_type and event.info:
            info_upper = event.info.upper()
            if "OFFER" in info_upper:
                msg_type = "OFFER"
            elif "ACK" in info_upper and "DHCP ACK" in info_upper:
                msg_type = "ACK"
            elif "DISCOVER" in info_upper or "REQUEST" in info_upper:
                # Client request, ignore
                return []

        if msg_type not in ("OFFER", "ACK"):
            return []

        now_epoch = event.timestamp.timestamp() if event.timestamp else datetime.now(timezone.utc).timestamp()
        server_id = event.dhcp_server_id or event.src_ip or "Unknown-Server-IP"
        server_mac = normalize_mac(event.src_mac) or "Unknown-Server-MAC"

        alerts: List[Alert] = []

        # -----------------------------------------------------------------
        # 1. Static-Only Environment Check
        # -----------------------------------------------------------------
        if self.allow_no_dhcp:
            cd_key = f"dhcp_unexpected_static_{server_id}"
            if not self.is_in_cooldown(cd_key, now_epoch):
                self.record_cooldown(cd_key, now_epoch)

                evidence = {
                    "server_id": server_id,
                    "server_mac": server_mac,
                    "message_type": msg_type,
                    "policy": "Static-only network segment; no DHCP servers are authorized.",
                }
                alert = Alert(
                    detection_type="UNAUTHORIZED_DHCP_STATIC_SEGMENT",
                    severity=self.severity,
                    source_device_id=device.device_id if device else None,
                    source_mac=server_mac,
                    source_ip=server_id,
                    title=f"Unauthorized DHCP Service on Static Segment: {server_id}",
                    description=(
                        f"A DHCP {msg_type} was observed from server '{server_id}' (MAC: {server_mac}) "
                        f"on a network configured for static addressing only."
                    ),
                    evidence=evidence,
                    status=AlertStatus.NEW.value,
                    timestamp=event.timestamp,
                )
                alerts.append(alert)
                return alerts

        # -----------------------------------------------------------------
        # 2. Unapproved DHCP Server Identifier Check
        # -----------------------------------------------------------------
        is_server_approved = (
            server_id in self.approved_dhcp_servers or
            server_mac in self.approved_dhcp_servers or
            (device and device.is_approved and server_id in self.approved_dhcp_servers)
        )

        if not is_server_approved:
            cd_key = f"rogue_dhcp_unapproved_{server_id}_{server_mac}"
            if not self.is_in_cooldown(cd_key, now_epoch):
                self.record_cooldown(cd_key, now_epoch)

                evidence = {
                    "server_identifier": server_id,
                    "server_mac": server_mac,
                    "dhcp_message_type": msg_type,
                    "packet_info": event.info,
                    "approved_servers_configured": list(self.approved_dhcp_servers),
                    "risk_impact": "Rogue DHCP servers can distribute malicious gateway or DNS settings, causing traffic diversion or Denial of Service.",
                }
                title = f"Rogue / Unapproved DHCP Server Offering Leases: {server_id}"
                description = (
                    f"A DHCP {msg_type} was observed originating from unapproved server '{server_id}' "
                    f"(MAC: {server_mac}). This server identifier is not present in the authorized DHCP server inventory."
                )
                alert = Alert(
                    detection_type="ROGUE_DHCP_OFFER_UNAPPROVED",
                    severity=self.severity,
                    source_device_id=device.device_id if device else None,
                    source_mac=server_mac,
                    source_ip=server_id,
                    title=title,
                    description=description,
                    evidence=evidence,
                    status=AlertStatus.NEW.value,
                    timestamp=event.timestamp,
                )
                logger.warning("ALERT: [ROGUE_DHCP_OFFER_UNAPPROVED] Server=%s, MAC=%s", server_id, server_mac)
                alerts.append(alert)

        # -----------------------------------------------------------------
        # 3. Multiple DHCP Servers Observed in Monitored Lab
        # -----------------------------------------------------------------
        if self._observed_servers and server_id not in self._observed_servers:
            cd_key = f"multiple_dhcp_{server_id}"
            if not self.is_in_cooldown(cd_key, now_epoch):
                self.record_cooldown(cd_key, now_epoch)

                other_servers = list(self._observed_servers.keys())
                evidence = {
                    "competing_server_id": server_id,
                    "competing_server_mac": server_mac,
                    "previously_observed_servers": other_servers,
                    "message_type": msg_type,
                }
                title = f"Multiple Competing DHCP Servers Detected: {server_id}"
                description = (
                    f"Multiple DHCP servers are offering IP leases in the monitored network. Server '{server_id}' "
                    f"was observed alongside previously active server(s): {', '.join(other_servers)}."
                )
                alert = Alert(
                    detection_type="MULTIPLE_DHCP_SERVERS_DETECTED",
                    severity=self.severity,
                    source_device_id=device.device_id if device else None,
                    source_mac=server_mac,
                    source_ip=server_id,
                    title=title,
                    description=description,
                    evidence=evidence,
                    status=AlertStatus.NEW.value,
                    timestamp=event.timestamp,
                )
                alerts.append(alert)

        # -----------------------------------------------------------------
        # 4. Primary DHCP Server Identity Change
        # -----------------------------------------------------------------
        if self._primary_server is None:
            self._primary_server = server_id
        elif self._primary_server != server_id and not is_server_approved:
            cd_key = f"dhcp_server_change_{server_id}"
            if not self.is_in_cooldown(cd_key, now_epoch):
                self.record_cooldown(cd_key, now_epoch)

                evidence = {
                    "previous_primary_server": self._primary_server,
                    "new_server_id": server_id,
                    "new_server_mac": server_mac,
                }
                title = f"DHCP Server Identity Changed: {self._primary_server} -> {server_id}"
                description = (
                    f"The active DHCP server providing network leases shifted from '{self._primary_server}' "
                    f"to unauthorized server '{server_id}' (MAC: {server_mac})."
                )
                alert = Alert(
                    detection_type="DHCP_SERVER_IDENTITY_CHANGED",
                    severity=self.severity,
                    source_device_id=device.device_id if device else None,
                    source_mac=server_mac,
                    source_ip=server_id,
                    title=title,
                    description=description,
                    evidence=evidence,
                    status=AlertStatus.NEW.value,
                    timestamp=event.timestamp,
                )
                alerts.append(alert)

        self._observed_servers[server_id] = now_epoch
        return alerts

    def get_observed_servers(self) -> Dict[str, float]:
        """Return all DHCP servers observed during the monitoring session."""
        return dict(self._observed_servers)
