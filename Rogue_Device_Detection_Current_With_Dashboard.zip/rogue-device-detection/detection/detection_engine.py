"""
Detection engine module.
Orchestrates detector execution, applies deduplication, persists generated alerts,
and manages alert investigation lifecycles.
"""

from datetime import datetime, timezone
import logging
from typing import Callable, Dict, List, Optional, Any

from config import DetectionConfig
from database.db import DatabaseManager
from models.alert import Alert, AlertStatus, AlertSeverity
from models.events import NetworkEvent
from models.device import Device
from detection.base_detector import BaseDetector
from detection.rogue_device_detector import RogueDeviceDetector
from detection.port_scan_detector import PortScanDetector
from detection.dos_detector import DosAnomalyDetector
from detection.arp_spoof_detector import ArpSpoofDetector
from detection.rogue_dhcp_detector import RogueDhcpDetector

logger = logging.getLogger(__name__)


class DetectionEngine:
    """
    Central detection coordinator.
    Evaluates observed traffic against registered detector rules and records alerts.
    """

    def __init__(
        self,
        db: DatabaseManager,
        config: Optional[DetectionConfig] = None,
    ):
        self.db = db
        self.config = config or DetectionConfig()
        self.detectors: List[BaseDetector] = []
        self.alert_callbacks: List[Callable[[Alert], None]] = []

        # Register default detectors
        self._init_default_detectors()

    def _init_default_detectors(self) -> None:
        """Register default rule detectors."""
        # 1. Rogue / Unapproved Device Detector
        self.register_detector(
            RogueDeviceDetector(
                cooldown_seconds=self.config.alert_cooldown_seconds,
                severity=self.config.unapproved_device_severity,
            )
        )
        # 2. Port Scanning Detector
        self.register_detector(
            PortScanDetector(config=self.config.port_scan)
        )
        # 3. DoS-like Traffic Anomaly Detector
        self.register_detector(
            DosAnomalyDetector(config=self.config.dos_anomaly, db=self.db)
        )
        # 4. ARP Spoofing / Gateway Hijack Detector
        self.register_detector(
            ArpSpoofDetector(config=self.config.arp_spoof)
        )
        # 5. Rogue DHCP Detector
        self.register_detector(
            RogueDhcpDetector(config=self.config.rogue_dhcp)
        )

    def register_detector(self, detector: BaseDetector) -> None:
        """Add a detector rule to the engine."""
        self.detectors.append(detector)
        logger.info("Registered detector: %s", detector.name)

    def get_detector(self, name: str) -> Optional[BaseDetector]:
        """Retrieve a registered detector by its class or rule name."""
        for d in self.detectors:
            if d.name.lower() == name.lower():
                return d
        return None

    def register_alert_callback(self, callback: Callable[[Alert], None]) -> None:
        """Register a callback invoked whenever an alert is generated."""
        if callback not in self.alert_callbacks:
            self.alert_callbacks.append(callback)

    def process_event(
        self,
        event: NetworkEvent,
        device: Optional[Device] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate an event and its associated device state through all active detectors.
        Persists generated alerts to SQLite and notifies listeners.
        """
        generated_alerts: List[Alert] = []

        for detector in self.detectors:
            if not detector.enabled:
                continue
            try:
                alerts = detector.evaluate(event, device, context)
                for alert in alerts:
                    # Persist alert to database
                    self.db.insert_alert(alert)
                    generated_alerts.append(alert)

                    # Notify callbacks
                    for cb in self.alert_callbacks:
                        try:
                            cb(alert)
                        except Exception as e:
                            logger.exception("Error in alert callback %s: %s", cb, e)
            except Exception as e:
                logger.exception("Error executing detector %s: %s", detector.name, e)

        return generated_alerts

    def process_anomalies(
        self,
        anomalies: List[Dict[str, Any]],
        device_id: str,
        timestamp: Optional[datetime] = None,
    ) -> List[Alert]:
        """
        Convert behavioral profiling anomalies into persisted Alert records.
        """
        ts = timestamp or datetime.now(timezone.utc)
        alerts: List[Alert] = []

        device = self.db.get_device_by_id(device_id)

        for anom in anomalies:
            detection_type = anom.get("type", "BEHAVIORAL_ANOMALY")
            alert = Alert(
                detection_type=detection_type,
                severity=anom.get("severity", AlertSeverity.MEDIUM.value),
                source_device_id=device_id,
                source_mac=device.mac_address if device else None,
                source_ip=device.current_ip if device else None,
                target_ip=None,
                target_port=None,
                title=f"Behavioral Anomaly: {detection_type} on {device_id}",
                description=anom.get("reason", "Anomalous traffic profile detected"),
                evidence=anom.get("metrics", {}),
                status=AlertStatus.NEW.value,
                timestamp=ts,
            )
            self.db.insert_alert(alert)
            alerts.append(alert)

            for cb in self.alert_callbacks:
                try:
                    cb(alert)
                except Exception as e:
                    logger.exception("Error in anomaly alert callback: %s", e)

        return alerts

    def get_alerts(
        self,
        status_filter: Optional[str] = None,
        severity_filter: Optional[str] = None,
        limit: int = 100,
    ) -> List[Alert]:
        """Query alerts from database."""
        return self.db.get_alerts(
            status_filter=status_filter,
            severity_filter=severity_filter,
            limit=limit,
        )

    def update_alert_status(
        self,
        alert_id: str,
        new_status: str,
        analyst: str = "Security Analyst",
        notes: Optional[str] = None,
    ) -> bool:
        """Update investigation status and record audit trail."""
        return self.db.update_alert_status(
            alert_id=alert_id,
            new_status=new_status,
            analyst=analyst,
            notes=notes,
        )
