"""
ARP spoofing detection module.
Monitors ARP observations, identifies conflicting IP-to-MAC mappings,
detects unauthorized changes to the configured default gateway mapping,
and tracks rapid mapping flapping using a bounded historical buffer.
"""

from collections import defaultdict, deque
from datetime import datetime, timezone
import logging
from typing import Dict, List, Optional, Any, Tuple

from config import ArpSpoofDetectorConfig
from detection.base_detector import BaseDetector
from models.alert import Alert, AlertSeverity, AlertStatus
from models.device import Device
from models.events import NetworkEvent
from sensor.device_discovery import normalize_mac

logger = logging.getLogger(__name__)


class ArpSpoofDetector(BaseDetector):
    """
    Detector monitoring ARP broadcasts, unicast replies, and gratuitous ARP frames.
    Maintains an IP-to-MAC observation history to identify spoofing and gateway hijacks.
    """

    def __init__(
        self,
        config: Optional[ArpSpoofDetectorConfig] = None,
        expected_gateway_ip: Optional[str] = None,
        expected_gateway_mac: Optional[str] = None,
        rapid_change_window_seconds: Optional[float] = None,
        flap_count_threshold: Optional[int] = None,
        cooldown_seconds: Optional[float] = None,
        host_severity: Optional[str] = None,
        gateway_severity: Optional[str] = None,
        enabled: Optional[bool] = None,
    ):
        cfg = config or ArpSpoofDetectorConfig()
        super().__init__(
            name="ArpSpoofDetector",
            description="Identifies conflicting ARP mapping changes, rapid MAC flapping, and gateway hijacks.",
            enabled=enabled if enabled is not None else cfg.enabled,
            cooldown_seconds=cooldown_seconds if cooldown_seconds is not None else cfg.cooldown_seconds,
        )
        self.expected_gateway_ip = expected_gateway_ip or cfg.expected_gateway_ip
        self.expected_gateway_mac = normalize_mac(expected_gateway_mac or cfg.expected_gateway_mac)
        self.rapid_change_window_seconds = (
            rapid_change_window_seconds if rapid_change_window_seconds is not None else cfg.rapid_change_window_seconds
        )
        self.flap_count_threshold = flap_count_threshold if flap_count_threshold is not None else cfg.flap_count_threshold
        self.host_severity = host_severity or cfg.host_severity
        self.gateway_severity = gateway_severity or cfg.gateway_severity

        # Bounded ARP mapping history per IP address:
        # ip_address -> deque of (timestamp_epoch, mac_address, info)
        self._arp_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=15))

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate an event for ARP spoofing, gateway corruption, or rapid MAC flapping.
        """
        if not self.enabled:
            return []

        # We evaluate ARP frames or events containing explicit IP conflict context
        src_ip = event.src_ip
        src_mac = normalize_mac(event.src_mac)
        if not src_ip or not src_mac:
            return []

        # Ignore broadcast/multicast source addresses
        if src_mac in ("FF:FF:FF:FF:FF:FF", "00:00:00:00:00:00") or src_ip == "0.0.0.0":
            return []

        # Check context for external IP collision flag from discovery manager if present
        context_conflict = context.get("ip_conflict") if context else None
        is_arp_frame = bool(event.protocol == "ARP")

        if not is_arp_frame and not context_conflict:
            return []

        now_epoch = event.timestamp.timestamp() if event.timestamp else datetime.now(timezone.utc).timestamp()
        history = self._arp_history[src_ip]

        # -----------------------------------------------------------------
        # 1. Gateway Mapping Integrity Check (CRITICAL)
        # -----------------------------------------------------------------
        if self.expected_gateway_ip and src_ip == self.expected_gateway_ip:
            if self.expected_gateway_mac and src_mac != self.expected_gateway_mac:
                cd_key = f"gateway_spoof_{src_ip}_{src_mac}"
                if not self.is_in_cooldown(cd_key, now_epoch):
                    self.record_cooldown(cd_key, now_epoch)

                    evidence = {
                        "gateway_ip": self.expected_gateway_ip,
                        "expected_gateway_mac": self.expected_gateway_mac,
                        "unauthorized_claiming_mac": src_mac,
                        "protocol": event.protocol,
                        "packet_info": event.info,
                        "risk_impact": "Potential Man-in-the-Middle (MitM) or network traffic interception targeting default gateway.",
                    }
                    title = f"CRITICAL: Gateway ARP Spoof / Hijack Detected on {src_ip}"
                    description = (
                        f"Host with MAC '{src_mac}' announced itself as default gateway IP '{src_ip}'. "
                        f"The authorized gateway hardware address is configured as '{self.expected_gateway_mac}'. "
                        f"This observation indicates a severe ARP mapping discrepancy consistent with gateway hijacking."
                    )
                    alert = Alert(
                        detection_type="GATEWAY_ARP_SPOOF_SUSPECT",
                        severity=self.gateway_severity,
                        source_device_id=device.device_id if device else None,
                        source_mac=src_mac,
                        source_ip=src_ip,
                        target_ip=event.dst_ip,
                        target_port=None,
                        title=title,
                        description=description,
                        evidence=evidence,
                        status=AlertStatus.NEW.value,
                        timestamp=event.timestamp,
                    )
                    logger.critical("ALERT: [GATEWAY_ARP_SPOOF_SUSPECT] Claiming MAC=%s, Expected=%s", src_mac, self.expected_gateway_mac)
                    self._record_observation(src_ip, src_mac, now_epoch, event.info)
                    return [alert]

        # -----------------------------------------------------------------
        # 2. Rapid Mapping Flapping & Conflicting Mapping History
        # -----------------------------------------------------------------
        recent_records = [
            r for r in history if (now_epoch - r[0]) <= self.rapid_change_window_seconds
        ]

        distinct_macs = {r[1] for r in recent_records}
        distinct_macs.add(src_mac)

        # Count MAC transitions in window
        transitions = 0
        prev_m = None
        for r in recent_records:
            if prev_m is not None and r[1] != prev_m:
                transitions += 1
            prev_m = r[1]
        if prev_m is not None and src_mac != prev_m:
            transitions += 1

        is_rapid_flapping = (transitions >= self.flap_count_threshold) and (len(distinct_macs) > 1)
        is_direct_conflict = False

        if recent_records and recent_records[-1][1] != src_mac:
            # Previous announcement came from a different MAC within the window
            last_mac = recent_records[-1][1]
            time_since_last = now_epoch - recent_records[-1][0]
            if time_since_last <= self.rapid_change_window_seconds:
                is_direct_conflict = True

        alerts = []

        if is_rapid_flapping:
            cd_key = f"arp_flap_{src_ip}"
            if not self.is_in_cooldown(cd_key, now_epoch):
                self.record_cooldown(cd_key, now_epoch)

                evidence = {
                    "ip_address": src_ip,
                    "competing_macs": list(distinct_macs),
                    "mapping_transitions_count": transitions,
                    "window_seconds": self.rapid_change_window_seconds,
                    "observation_history": [
                        {"timestamp": r[0], "mac": r[1], "info": r[2]} for r in recent_records[-5:]
                    ],
                }
                title = f"Rapid ARP Mapping Flapping on IP {src_ip}"
                description = (
                    f"IP address '{src_ip}' exhibited {transitions} hardware address transitions between "
                    f"distinct MACs ({', '.join(distinct_macs)}) within {self.rapid_change_window_seconds:.0f}s. "
                    f"Rapid mapping alternation indicates competing ARP broadcasts or deliberate spoofing."
                )
                alert = Alert(
                    detection_type="ARP_RAPID_FLAPPING_SUSPECT",
                    severity=self.host_severity,
                    source_device_id=device.device_id if device else None,
                    source_mac=src_mac,
                    source_ip=src_ip,
                    title=title,
                    description=description,
                    evidence=evidence,
                    status=AlertStatus.NEW.value,
                    timestamp=event.timestamp,
                )
                alerts.append(alert)

        elif is_direct_conflict or context_conflict:
            cd_key = f"arp_conflict_{src_ip}_{src_mac}"
            if not self.is_in_cooldown(cd_key, now_epoch):
                self.record_cooldown(cd_key, now_epoch)

                prev_mac = recent_records[-1][1] if recent_records else "Prior Host"
                title = f"Conflicting ARP Mapping Claim on IP {src_ip}"
                description = (
                    f"IP '{src_ip}' was recently claimed by MAC '{prev_mac}', but is now being claimed by "
                    f"MAC '{src_mac}'. This discrepancy indicates a conflicting IP-to-MAC mapping."
                )
                evidence = {
                    "ip_address": src_ip,
                    "previously_observed_mac": prev_mac,
                    "newly_claiming_mac": src_mac,
                    "context_details": context_conflict,
                    "packet_info": event.info,
                }
                alert = Alert(
                    detection_type="ARP_MAPPING_CONFLICT",
                    severity=self.host_severity,
                    source_device_id=device.device_id if device else None,
                    source_mac=src_mac,
                    source_ip=src_ip,
                    title=title,
                    description=description,
                    evidence=evidence,
                    status=AlertStatus.NEW.value,
                    timestamp=event.timestamp,
                )
                alerts.append(alert)

        self._record_observation(src_ip, src_mac, now_epoch, event.info)
        return alerts

    def _record_observation(self, ip: str, mac: str, ts_epoch: float, info: Optional[str]) -> None:
        """Append an observation to the historical buffer."""
        self._arp_history[ip].append((ts_epoch, mac, info or ""))

    def get_mapping_history(self, ip: str) -> List[Tuple[float, str, str]]:
        """Retrieve recent ARP mapping history for a specific IP."""
        return list(self._arp_history.get(ip, []))
