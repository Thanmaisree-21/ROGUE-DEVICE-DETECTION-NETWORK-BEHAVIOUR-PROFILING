"""
DoS-like traffic anomaly detection module.
Monitors packet rates, byte volume bursts, single-target request concentration,
and baseline statistical deviations.
Adheres strictly to defensive labeling standards (flags traffic bursts, never claims confirmed attack).
"""

from collections import defaultdict, deque
from datetime import datetime, timezone
import logging
from typing import Dict, List, Optional, Any

from config import DosAnomalyDetectorConfig
from detection.base_detector import BaseDetector
from models.alert import Alert, AlertSeverity, AlertStatus
from models.device import Device
from models.events import NetworkEvent
from database.db import DatabaseManager

logger = logging.getLogger(__name__)


class DosAnomalyDetector(BaseDetector):
    """
    Detector identifying high-rate traffic bursts, volume anomalies, or target concentration.
    Compares current throughput against static rate limits and learned historical baselines.
    """

    def __init__(
        self,
        config: Optional[DosAnomalyDetectorConfig] = None,
        db: Optional[DatabaseManager] = None,
        packet_rate_threshold: Optional[float] = None,
        byte_rate_threshold: Optional[float] = None,
        single_target_rate_threshold: Optional[float] = None,
        window_seconds: Optional[float] = None,
        baseline_zscore_threshold: Optional[float] = None,
        cooldown_seconds: Optional[float] = None,
        severity: Optional[str] = None,
        enabled: Optional[bool] = None,
    ):
        cfg = config or DosAnomalyDetectorConfig()
        super().__init__(
            name="DosAnomalyDetector",
            description="Identifies abnormal traffic volume bursts and single-target request concentrations.",
            enabled=enabled if enabled is not None else cfg.enabled,
            cooldown_seconds=cooldown_seconds if cooldown_seconds is not None else cfg.cooldown_seconds,
        )
        self.db = db
        self.packet_rate_threshold = (
            packet_rate_threshold if packet_rate_threshold is not None else cfg.packet_rate_threshold
        )
        self.byte_rate_threshold = (
            byte_rate_threshold if byte_rate_threshold is not None else cfg.byte_rate_threshold
        )
        self.single_target_rate_threshold = (
            single_target_rate_threshold if single_target_rate_threshold is not None else cfg.single_target_rate_threshold
        )
        self.window_seconds = window_seconds if window_seconds is not None else cfg.window_seconds
        self.baseline_zscore_threshold = (
            baseline_zscore_threshold if baseline_zscore_threshold is not None else cfg.baseline_zscore_threshold
        )
        self.severity = severity or cfg.severity

        # Sliding window history per source identifier:
        # src_key -> deque of (timestamp_epoch, dst_ip, packet_size, is_syn)
        self._traffic_windows: Dict[str, deque] = defaultdict(deque)

    def evaluate(
        self,
        event: NetworkEvent,
        device: Optional[Device],
        context: Optional[Dict[str, Any]] = None,
    ) -> List[Alert]:
        """
        Evaluate an event for excessive transmission rates or flood patterns.
        """
        if not self.enabled or not event.src_ip:
            return []

        src_key = device.device_id if device else event.src_ip
        now_epoch = event.timestamp.timestamp() if event.timestamp else datetime.now(timezone.utc).timestamp()
        queue = self._traffic_windows[src_key]

        is_syn = bool(event.protocol == "TCP" and event.tcp_flags and "SYN" in event.tcp_flags)
        queue.append((
            now_epoch,
            event.dst_ip,
            event.packet_size,
            is_syn,
        ))

        # Evict records older than window duration
        while queue and (now_epoch - queue[0][0]) > self.window_seconds:
            queue.popleft()

        total_packets = len(queue)
        if total_packets < 6:
            return []

        time_span = now_epoch - queue[0][0]
        effective_window = max(time_span, 1.0)
        packet_rate = total_packets / effective_window
        total_bytes = sum(item[2] for item in queue)
        byte_rate = total_bytes / effective_window

        # Calculate target concentration
        target_counts: Dict[str, int] = defaultdict(int)
        for item in queue:
            if item[1]:
                target_counts[item[1]] += 1

        top_target = None
        top_target_rate = 0.0
        if target_counts:
            top_target, max_count = max(target_counts.items(), key=lambda x: x[1])
            top_target_rate = max_count / effective_window

        trigger_reasons = []
        is_packet_spike = packet_rate >= self.packet_rate_threshold
        is_byte_spike = byte_rate >= self.byte_rate_threshold
        is_target_flood = (top_target_rate >= self.single_target_rate_threshold) and (total_packets >= 8)

        if is_packet_spike:
            trigger_reasons.append(
                f"Abnormal packet rate: {packet_rate:.1f} pkts/s (Threshold: {self.packet_rate_threshold:.1f} pkts/s)"
            )
        if is_byte_spike:
            trigger_reasons.append(
                f"Abnormal throughput: {byte_rate:.0f} bytes/s (Threshold: {self.byte_rate_threshold:.0f} bytes/s)"
            )
        if is_target_flood:
            trigger_reasons.append(
                f"Target concentration: {top_target_rate:.1f} pkts/s focused on destination {top_target} "
                f"(Threshold: {self.single_target_rate_threshold:.1f} pkts/s)"
            )

        # Baseline comparison (Z-score evaluation if historical baseline exists)
        baseline = None
        if device and self.db:
            baseline = self.db.get_baseline(device.device_id)

        if baseline and baseline.sample_windows >= 4 and baseline.std_packet_rate >= 0.1:
            z_score = (packet_rate - baseline.mean_packet_rate) / baseline.std_packet_rate
            if z_score >= self.baseline_zscore_threshold:
                trigger_reasons.append(
                    f"Statistical baseline deviation: Z-score={z_score:.2f} > Threshold {self.baseline_zscore_threshold:.1f} "
                    f"(Historical Mean: {baseline.mean_packet_rate:.1f} pkts/s, StdDev: {baseline.std_packet_rate:.1f})"
                )

        if not trigger_reasons:
            return []

        # Check cooldown deduplication
        cooldown_key = f"dos_anomaly_{src_key}"
        if self.is_in_cooldown(cooldown_key, now_epoch):
            return []

        self.record_cooldown(cooldown_key, now_epoch)

        reason_str = " | ".join(trigger_reasons)
        mac_display = event.src_mac or (device.mac_address if device else "Unknown MAC")

        title = f"Traffic Flood / Abnormal Burst Resembling DoS from {event.src_ip}"
        # Defensive phrasing: clearly state this resembles a flood/burst, NOT confirmed attack
        description = (
            f"Host at IP '{event.src_ip}' (MAC: {mac_display}) generated an anomalous volume burst resembling "
            f"a traffic flood or denial-of-service pattern: {reason_str}. "
            f"Note: This alert identifies an abnormal traffic burst; an intentional denial-of-service attack is not confirmed."
        )

        evidence = {
            "source_ip": event.src_ip,
            "source_mac": mac_display,
            "source_device_id": device.device_id if device else None,
            "target_ip": top_target or event.dst_ip,
            "observed_packet_rate": round(packet_rate, 2),
            "observed_byte_rate": round(byte_rate, 2),
            "top_target_rate": round(top_target_rate, 2),
            "total_packets_in_window": total_packets,
            "window_duration_seconds": round(effective_window, 2),
            "trigger_reasons": trigger_reasons,
            "classification_notice": "Defensive monitoring: Behavior resembles abnormal traffic burst/flood; further investigation required.",
        }

        alert = Alert(
            detection_type="TRAFFIC_ANOMALY_DOS_BURST",
            severity=self.severity,
            source_device_id=device.device_id if device else None,
            source_mac=event.src_mac,
            source_ip=event.src_ip,
            target_ip=top_target or event.dst_ip,
            target_port=event.dst_port,
            title=title,
            description=description,
            evidence=evidence,
            status=AlertStatus.NEW.value,
            timestamp=event.timestamp,
        )

        logger.warning(
            "ALERT: [TRAFFIC_ANOMALY_DOS_BURST] Source=%s, Rate=%.1f pkts/s, Target=%s (%s)",
            event.src_ip, packet_rate, top_target, reason_str
        )
        return [alert]
