"""
Streamlit Web Dashboard for Rogue Device Detection & Network Behavior Profiling.
Provides an unprivileged, interactive GUI for network defense analysts to:
  - Monitor discovered hardware inventory & approval status
  - Inspect explainable 0-100 risk score breakdowns
  - Investigate security alerts & record workflow audit notes
  - Visualize protocol distribution and traffic time-series metrics
  - Trigger synthetic simulation scenarios & export audit reports
"""

import json
from datetime import datetime, timezone
from pathlib import Path
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from dashboard_interface import DashboardDataInterface
from config import load_config
import demo_scenarios

# Initialize interface
st.set_page_config(
    page_title="Rogue Device Detection & Network IDS",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom styling for high-contrast security operations center (SOC) appearance
st.markdown(
    """
    <style>
    .metric-card {
        background-color: #1a1c23;
        border-radius: 8px;
        padding: 16px;
        border: 1px solid #2e3440;
    }
    .badge-critical {
        background-color: #ff4b4b;
        color: white;
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: bold;
    }
    .badge-high {
        background-color: #ff8c00;
        color: white;
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: bold;
    }
    .badge-medium {
        background-color: #ffd700;
        color: #1a1a1a;
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: bold;
    }
    .badge-low {
        background-color: #28a745;
        color: white;
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: bold;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def get_interface():
    return DashboardDataInterface()


interface = get_interface()

# Sidebar: Controls & System Info
with st.sidebar:
    st.title("🛡️ IDS Control Center")
    st.caption("Ethical & Defensive Network Monitoring")

    if st.button("🔄 Refresh Data", use_container_width=True):
        st.rerun()

    st.divider()

    st.subheader("⚙️ Scenario Injection")
    st.caption("Inject safe synthetic test traffic to test detectors:")

    col_s1, col_s2 = st.columns(2)
    with col_s1:
        if st.button("Port Scan (A)", use_container_width=True):
            with st.spinner("Executing Scenario A..."):
                demo_scenarios.run_scenario_a()
            st.success("Scenario A completed!")
            st.rerun()
        if st.button("ARP Spoof (C)", use_container_width=True):
            with st.spinner("Executing Scenario C..."):
                demo_scenarios.run_scenario_c()
            st.success("Scenario C completed!")
            st.rerun()

    with col_s2:
        if st.button("DoS Flood (B)", use_container_width=True):
            with st.spinner("Executing Scenario B..."):
                demo_scenarios.run_scenario_b()
            st.success("Scenario B completed!")
            st.rerun()
        if st.button("Rogue DHCP (D)", use_container_width=True):
            with st.spinner("Executing Scenario D..."):
                demo_scenarios.run_scenario_d()
            st.success("Scenario D completed!")
            st.rerun()

    if st.button("▶️ Run All Scenarios & Reset", use_container_width=True):
        with st.spinner("Resetting and running all scenarios..."):
            demo_scenarios.run_all_scenarios(reset_db=True)
        st.success("All scenarios executed cleanly!")
        st.rerun()

    st.divider()
    overview = interface.get_system_overview()
    st.caption(f"📁 SQLite DB: `{Path(overview['database_path']).name}`")
    st.caption(f"💾 DB Size: {overview['database_size_kb']} KB")


# Top KPI Banner
st.title("🛡️ Rogue Device Detection & Behavior Profiling")
st.markdown(
    "Continuous defensive monitoring for unauthorized hardware, reconnaissance scans, "
    "traffic anomalies, ARP conflicts, and rogue DHCP services."
)

kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
with kpi1:
    st.metric("Total Devices", overview["total_devices"])
with kpi2:
    st.metric("Approved Assets", overview["approved_devices"])
with kpi3:
    st.metric("Unrecognized", overview["unrecognized_devices"])
with kpi4:
    st.metric("Total Alerts", overview["total_alerts"], delta=f"{overview['new_alerts']} New", delta_color="inverse")
with kpi5:
    max_score = overview["max_risk_score"]
    st.metric("Peak Risk Score", f"{max_score}/100")

st.divider()

# Main Application Tabs
tab_devices, tab_alerts, tab_analytics, tab_report = st.tabs([
    "🖥️ Discovered Devices & Risk Profiler",
    "🚨 Security Alerts & Investigation",
    "📊 Traffic & Protocol Analytics",
    "📑 Posture Report & Audit Export",
])

# -----------------------------------------------------------------------------
# TAB 1: Devices & Risk Profiler
# -----------------------------------------------------------------------------
with tab_devices:
    st.subheader("Observed Device Inventory")
    devices_data = interface.get_devices_table()

    if not devices_data:
        st.info("No network devices recorded yet. Run a scenario or simulation from the sidebar.")
    else:
        df_dev = pd.DataFrame(devices_data)

        # Filters
        f_col1, f_col2 = st.columns([1, 2])
        with f_col1:
            status_filter = st.selectbox("Filter by Approval Status:", ["ALL", "APPROVED", "UNRECOGNIZED"])
        with f_col2:
            search_query = st.text_input("Search IP, MAC or Vendor:", "")

        filtered_df = df_dev.copy()
        if status_filter != "ALL":
            filtered_df = filtered_df[filtered_df["approval_status"] == status_filter]
        if search_query:
            q = search_query.strip().lower()
            filtered_df = filtered_df[
                filtered_df["mac_address"].str.lower().str.contains(q)
                | filtered_df["current_ip"].str.lower().str.contains(q)
                | filtered_df["vendor"].str.lower().str.contains(q)
            ]

        # Display table
        cols_to_show = [
            "device_id", "mac_address", "current_ip", "approval_status",
            "vendor", "risk_score", "risk_severity", "total_packets", "last_seen"
        ]
        st.dataframe(
            filtered_df[cols_to_show],
            use_container_width=True,
            column_config={
                "risk_score": st.column_config.ProgressColumn(
                    "Risk Score",
                    min_value=0,
                    max_value=100,
                    format="%d/100",
                ),
            },
            hide_index=True,
        )

        st.divider()
        st.subheader("🔍 Explainable Risk Score & Device Deep-Dive")
        
        dev_ids = df_dev["device_id"].tolist()
        selected_dev_id = st.selectbox("Select Device to Inspect:", dev_ids)

        if selected_dev_id:
            detail = interface.get_device_detail(selected_dev_id)
            if detail:
                d_info = detail["device"]
                risk_eval = detail.get("risk_evaluation") or {}
                baseline = detail.get("baseline")
                dev_alerts = detail.get("alerts", [])

                c1, c2 = st.columns([1, 2])
                with c1:
                    st.markdown(f"**MAC Address:** `{d_info.get('mac_address')}`")
                    st.markdown(f"**Current IP:** `{d_info.get('current_ip')}`")
                    st.markdown(f"**Hardware Vendor:** {d_info.get('vendor')}")
                    st.markdown(f"**Status:** `{d_info.get('approval_status')}`")
                    st.markdown(f"**Total Packets:** {d_info.get('total_packets'):,}")
                    st.markdown(f"**Total Bytes:** {d_info.get('total_bytes'):,} bytes")
                    st.markdown(f"**First Seen:** {d_info.get('first_seen')}")
                    st.markdown(f"**Last Seen:** {d_info.get('last_seen')}")

                with c2:
                    st.markdown("#### Explainable Risk Score Breakdown")
                    score_val = risk_eval.get("risk_score", 0.0)
                    sev_val = risk_eval.get("severity", "LOW")

                    # Color badge
                    sev_colors = {"CRITICAL": "#ff4b4b", "HIGH": "#ff8c00", "MEDIUM": "#ffd700", "LOW": "#28a745"}
                    st.markdown(
                        f"<h2 style='color: {sev_colors.get(sev_val, '#fff')}; margin-bottom: 0;'>"
                        f"{score_val:.1f} / 100 ({sev_val})</h2>",
                        unsafe_allow_html=True,
                    )

                    signals = risk_eval.get("contributing_signals", [])
                    if signals:
                        st.markdown("**Contributing Signals:**")
                        for sig in signals:
                            cat = sig.get("category", "General")
                            pts = sig.get("points", 0.0)
                            desc = sig.get("description", "")
                            meta = sig.get("metadata", {})
                            st.write(f"- **+{pts:.1f} pts** `[{cat}]`: {desc}")
                            if meta:
                                with st.expander(f"Signal Details ({cat})"):
                                    st.json(meta)
                    else:
                        st.write("No adverse risk signals observed. Device behavior complies with baseline.")

                if baseline:
                    st.markdown("#### Behavioral Profiling Baseline")
                    b_col1, b_col2, b_col3 = st.columns(3)
                    with b_col1:
                        st.metric("Avg Packet Rate", f"{baseline.get('mean_packet_rate', 0.0):.2f} pkts/s")
                    with b_col2:
                        st.metric("Avg Byte Rate", f"{baseline.get('mean_byte_rate', 0.0):.2f} B/s")
                    with b_col3:
                        st.metric("Avg Distinct Ports", f"{baseline.get('mean_distinct_ports', 0.0):.2f}")

                if dev_alerts:
                    st.markdown(f"#### Correlated Alerts ({len(dev_alerts)})")
                    st.dataframe(pd.DataFrame(dev_alerts)[["alert_id", "alert_type", "severity", "status", "created_at"]], hide_index=True)


# -----------------------------------------------------------------------------
# TAB 2: Alerts & Investigation
# -----------------------------------------------------------------------------
with tab_alerts:
    st.subheader("Security Alerts & Incident Management")

    col_f1, col_f2 = st.columns(2)
    with col_f1:
        sev_filter = st.selectbox("Filter Severity:", ["ALL", "CRITICAL", "HIGH", "MEDIUM", "LOW"])
    with col_f2:
        stat_filter = st.selectbox("Filter Status:", ["ALL", "NEW", "ACKNOWLEDGED", "UNDER_REVIEW", "RESOLVED", "FALSE_POSITIVE"])

    raw_alerts = interface.get_alerts_table(
        severity_filter=None if sev_filter == "ALL" else sev_filter,
        status_filter=None if stat_filter == "ALL" else stat_filter,
        limit=200,
    )

    if not raw_alerts:
        st.info("No alerts found matching the selected filter criteria.")
    else:
        df_alerts = pd.DataFrame(raw_alerts)
        st.dataframe(
            df_alerts[["alert_id", "severity", "status", "alert_type", "source_ip", "source_mac", "created_at"]],
            use_container_width=True,
            hide_index=True,
        )

        st.divider()
        st.subheader("🔍 Alert Investigation & Workflow State")
        alert_ids = [a["alert_id"] for a in raw_alerts]
        chosen_alert_id = st.selectbox("Select Alert to Inspect or Update:", alert_ids)

        if chosen_alert_id:
            alert_detail = interface.get_alert_detail(chosen_alert_id)
            if alert_detail:
                a_info = alert_detail["alert"]
                history = alert_detail.get("history", [])

                act1, act2 = st.columns([1, 1])
                with act1:
                    st.markdown(f"**Alert Type:** `{a_info.get('alert_type')}`")
                    st.markdown(f"**Severity:** `{a_info.get('severity')}`")
                    st.markdown(f"**Current Status:** `{a_info.get('status')}`")
                    st.markdown(f"**Source IP:** `{a_info.get('source_ip')}`")
                    st.markdown(f"**Source MAC:** `{a_info.get('source_mac')}`")
                    st.markdown(f"**Created At:** {a_info.get('created_at')}")

                    evidence = a_info.get("evidence", {})
                    st.markdown("**Structured Evidence:**")
                    st.json(evidence)

                with act2:
                    st.markdown("#### Update Investigation Status")
                    with st.form(f"update_form_{chosen_alert_id}"):
                        new_status = st.selectbox(
                            "New Status:",
                            ["ACKNOWLEDGED", "UNDER_REVIEW", "RESOLVED", "FALSE_POSITIVE"],
                            index=0,
                        )
                        analyst_name = st.text_input("Analyst Name:", value="Security Analyst")
                        notes = st.text_area("Investigation Notes:", placeholder="Document forensic findings or remediation steps...")
                        submitted = st.form_submit_button("Submit Status Update")

                        if submitted:
                            success = interface.update_alert_status(
                                alert_id=chosen_alert_id,
                                new_status=new_status,
                                analyst=analyst_name,
                                notes=notes,
                            )
                            if success:
                                st.success(f"Alert {chosen_alert_id} successfully transitioned to {new_status}!")
                                st.rerun()
                            else:
                                st.error("Failed to update alert.")

                    if history:
                        st.markdown("#### Audit History Log")
                        st.dataframe(pd.DataFrame(history)[["previous_status", "new_status", "changed_by", "notes", "changed_at"]], hide_index=True)


# -----------------------------------------------------------------------------
# TAB 3: Analytics & Visualizations
# -----------------------------------------------------------------------------
with tab_analytics:
    st.subheader("Network Posture & Traffic Distribution")

    col_chart1, col_chart2 = st.columns(2)
    with col_chart1:
        st.markdown("#### Protocol Breakdown")
        proto_dist = interface.get_protocol_distribution()
        if proto_dist:
            df_proto = pd.DataFrame(list(proto_dist.items()), columns=["Protocol", "Packets"])
            fig_proto = px.pie(
                df_proto,
                names="Protocol",
                values="Packets",
                hole=0.4,
                color_discrete_sequence=px.colors.qualitative.Dark24,
            )
            fig_proto.update_layout(margin=dict(t=20, b=20, l=20, r=20))
            st.plotly_chart(fig_proto, use_container_width=True)
        else:
            st.caption("No protocol events recorded yet.")

    with col_chart2:
        st.markdown("#### Risk Severity Distribution")
        risk_dist = interface.get_risk_distribution()
        if risk_dist:
            df_risk = pd.DataFrame(list(risk_dist.items()), columns=["Severity", "Count"])
            colors = {"LOW": "#28a745", "MEDIUM": "#ffd700", "HIGH": "#ff8c00", "CRITICAL": "#ff4b4b"}
            fig_risk = px.bar(
                df_risk,
                x="Severity",
                y="Count",
                color="Severity",
                color_discrete_map=colors,
            )
            fig_risk.update_layout(margin=dict(t=20, b=20, l=20, r=20), showlegend=False)
            st.plotly_chart(fig_risk, use_container_width=True)
        else:
            st.caption("No risk distributions calculated yet.")

    st.divider()
    st.markdown("#### Rolling Traffic Throughput Time-Series")
    timeseries_data = interface.get_traffic_timeseries(limit=50)

    if timeseries_data:
        df_ts = pd.DataFrame(timeseries_data)
        fig_ts = go.Figure()
        fig_ts.add_trace(go.Scatter(
            x=df_ts["window_end"],
            y=df_ts["packet_rate"],
            mode="lines+markers",
            name="Packet Rate (pkts/s)",
            line=dict(color="#00bcd4", width=2),
        ))
        fig_ts.add_trace(go.Scatter(
            x=df_ts["window_end"],
            y=df_ts["byte_rate"],
            mode="lines",
            name="Byte Rate (bytes/s)",
            yaxis="y2",
            line=dict(color="#ff9800", dash="dot"),
        ))
        fig_ts.update_layout(
            yaxis=dict(title="Packets / Sec"),
            yaxis2=dict(title="Bytes / Sec", overlaying="y", side="right"),
            margin=dict(t=30, b=30, l=40, r=40),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        )
        st.plotly_chart(fig_ts, use_container_width=True)
    else:
        st.info("No window aggregates available yet. Run simulation replay to generate rolling window traffic.")


# -----------------------------------------------------------------------------
# TAB 4: Audit Report & Posture Export
# -----------------------------------------------------------------------------
with tab_report:
    st.subheader("Security Posture Audit Report")
    st.markdown("Export a comprehensive JSON snapshot of the monitored network state for compliance and lab documentation.")

    report = interface.export_security_report()

    st.download_button(
        label="📥 Download JSON Security Posture Report",
        data=json.dumps(report, indent=2),
        file_name=f"network_security_audit_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json",
        mime="application/json",
        use_container_width=True,
    )

    st.json(report)
