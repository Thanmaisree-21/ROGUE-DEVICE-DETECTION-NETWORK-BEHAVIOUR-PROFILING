"""
Main application entry point for Rogue Device Detection & Network Behavior Profiling.
Coordinates the packet sensor, device discovery, four independent detection modules,
behavioral profiling, and explainable multi-signal risk scoring.
"""

import argparse
from datetime import datetime, timezone
import json
import logging
import signal
import sys
import time
from typing import Optional, List

from config import load_config, AppConfig
from database.db import DatabaseManager
from models.events import NetworkEvent
from models.alert import Alert, AlertStatus
from sensor.packet_sensor import PacketSensor, PacketCapturePermissionError
from sensor.device_discovery import DeviceDiscoveryManager
from profiling.feature_extractor import FeatureExtractor
from profiling.behavior_profiler import BehaviorProfiler
from profiling.risk_scorer import RiskScorer
from detection.detection_engine import DetectionEngine


def configure_logging(log_level: str, log_file: Optional[str] = None) -> None:
    """Configure centralized logging format for console and file."""
    handlers = [logging.StreamHandler(sys.stdout)]
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding="utf-8"))

    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
    )


class NetworkMonitoringApp:
    """Master application coordinator."""

    def __init__(self, config: Optional[AppConfig] = None):
        self.config = config or load_config()
        self.db = DatabaseManager(
            db_path=self.config.database.db_file,
            schema_path=self.config.database.schema_file,
            enable_wal=self.config.database.enable_wal_mode,
        )
        self.db.init_db()

        # Sync approved devices fixture if enabled
        if self.config.inventory.auto_sync_approved and self.config.inventory.approved_devices_file.exists():
            self.db.import_approved_assets_from_json(self.config.inventory.approved_devices_file)

        self.discovery_mgr = DeviceDiscoveryManager(self.db)
        self.profiler = BehaviorProfiler(self.db, self.config.profiling)
        self.detection_engine = DetectionEngine(self.db, self.config.detection)
        self.risk_scorer = RiskScorer(self.config.detection.risk_scoring)
        self.sensor = PacketSensor(self.config.sensor)

        # Wire up callbacks
        self.sensor.register_callback(self._on_event_received)
        self.detection_engine.register_alert_callback(self._on_alert_generated)

        # Rolling window cache for feature extraction
        self._window_events: List[NetworkEvent] = []
        self._last_window_time = time.time()

    def _on_event_received(self, event: NetworkEvent) -> None:
        """Pipeline invoked whenever the sensor captures or replays a packet."""
        # 1. Persist raw event metadata to SQLite
        try:
            self.db.insert_event(event)
        except Exception as e:
            logging.getLogger(__name__).debug("Failed to persist event: %s", e)

        # 2. Device discovery & inventory correlation
        device, is_new, conflict_msg = self.discovery_mgr.process_event(event)

        # 3. Rule-based detection across all 4 modules
        context = {"ip_conflict": conflict_msg}
        self.detection_engine.process_event(event, device, context)

        # 4. Buffer for rolling behavioral window
        self._window_events.append(event)
        now = time.time()
        if (now - self._last_window_time) >= self.config.profiling.window_seconds:
            self._flush_profiling_window()
            self._last_window_time = now

    def _flush_profiling_window(self) -> None:
        """Extract features and check behavioral profiling anomalies across the window."""
        if not self._window_events:
            return

        window_end = datetime.now(timezone.utc)
        window_start = datetime.fromtimestamp(self._last_window_time, tz=timezone.utc)
        events_slice = list(self._window_events)
        self._window_events.clear()

        metrics_list = FeatureExtractor.extract_all_devices_in_window(
            events_slice, window_start, window_end
        )

        for metrics in metrics_list:
            anomalies = self.profiler.process_window(metrics)
            if anomalies:
                self.detection_engine.process_anomalies(
                    anomalies=anomalies,
                    device_id=metrics.device_id,
                    timestamp=window_end,
                )

        # Update explainable risk scores for all observed devices
        self.update_device_risk_scores()

    def update_device_risk_scores(self) -> None:
        """Compute and persist updated explainable risk scores for all active devices."""
        all_alerts = self.db.get_alerts(limit=500)
        for device in self.discovery_mgr.get_all_devices():
            dev_alerts = [
                a for a in all_alerts
                if (a.source_device_id == device.device_id or
                    (device.mac_address and a.source_mac == device.mac_address) or
                    (device.current_ip and a.source_ip == device.current_ip))
            ]
            report = self.risk_scorer.evaluate_device_risk(device, dev_alerts)
            self.db.upsert_device_risk_score(
                device_id=device.device_id,
                risk_score=report.overall_score,
                severity=report.severity,
                contributing_signals=[s.to_dict() for s in report.signals],
                updated_at=report.updated_at,
            )

    def _on_alert_generated(self, alert: Alert) -> None:
        """Display newly generated alert to the operator console."""
        print(
            f"\n[!] >>> SECURITY ALERT DETECTED <<< [!]\n"
            f"    Alert ID:  {alert.alert_id}\n"
            f"    Type:      {alert.detection_type}\n"
            f"    Severity:  {alert.severity}\n"
            f"    Source:    {alert.source_mac or 'N/A'} ({alert.source_ip or 'N/A'})\n"
            f"    Title:     {alert.title}\n"
            f"    Details:   {alert.description}\n"
            f"    Status:    {alert.status}\n"
        )

    def start(self, duration: Optional[float] = None) -> None:
        """Start monitoring sensor and block for specified duration or until interrupt."""
        logger = logging.getLogger(__name__)
        logger.info("Initializing Network Monitoring Application...")
        try:
            self.sensor.start()
        except (PacketCapturePermissionError, Exception) as e:
            print("\n" + "=" * 80)
            print("[!] LIVE PACKET CAPTURE INITIALIZATION FAILED")
            print("=" * 80)
            print(f"Error: {e}")
            print("\nPrerequisites for Live Network Capture:")
            print("  * Windows: Install Npcap (https://npcap.com/) with 'WinPcap API-compatible Mode'")
            print("             and run this command from an elevated (Administrator) terminal.")
            print("  * Linux:   Run with 'sudo' or grant capabilities:")
            print("             sudo setcap cap_net_raw,cap_net_admin=eip $(readlink -f $(which python3))")
            print("\nSafe Unprivileged Alternative:")
            print("  Use SIMULATION MODE for offline evaluation, lab grading, and unit testing:")
            print("      python app.py --mode simulate")
            print("  Or run the attack/anomaly demonstration workflows:")
            print("      python demo_scenarios.py --scenario all")
            print("=" * 80 + "\n")
            return

        try:
            if duration and duration > 0:
                logger.info("Running monitoring for %s seconds...", duration)
                start_t = time.time()
                while time.time() - start_t < duration and self.sensor.is_running:
                    time.sleep(0.5)
            else:
                logger.info("Monitoring running. Press Ctrl+C to terminate.")
                while self.sensor.is_running:
                    time.sleep(0.5)
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received.")
        finally:
            self.stop()

    def stop(self) -> None:
        """Stop sensor, flush remaining windows, and calculate final risk scores."""
        self.sensor.stop()
        self._flush_profiling_window()
        self.update_device_risk_scores()
        logging.getLogger(__name__).info("Application stopped gracefully.")


# -----------------------------------------------------------------------------
# CLI Utility Functions
# -----------------------------------------------------------------------------
def cmd_list_devices(db: DatabaseManager) -> None:
    """Print tabular inventory of observed network devices including risk scores."""
    devices = db.get_all_devices()
    risk_records = {r["device_id"]: r for r in db.get_all_device_risk_scores()}

    print("\n" + "=" * 105)
    print(f"{'DEVICE ID':<22} | {'MAC ADDRESS':<18} | {'CURRENT IP':<15} | {'STATUS':<12} | {'RISK':<5} | {'SEVERITY':<8} | {'PKTS':<5}")
    print("=" * 105)
    for d in devices:
        mac = d.mac_address or "Unknown"
        ip = d.current_ip or "Unknown"
        status = d.approval_status
        risk_info = risk_records.get(d.device_id, {})
        risk_score = f"{risk_info.get('risk_score', 0.0):.0f}" if risk_info else "0"
        risk_sev = risk_info.get("severity", "LOW") if risk_info else "LOW"
        print(f"{d.device_id:<22} | {mac:<18} | {ip:<15} | {status:<12} | {risk_score:<5} | {risk_sev:<8} | {d.total_packets:<5}")
    print("=" * 105)
    print(f"Total Observed Devices: {len(devices)}\n")


def cmd_list_alerts(db: DatabaseManager, status: Optional[str] = None) -> None:
    """Print tabular list of security alerts."""
    alerts = db.get_alerts(status_filter=status)
    print("\n" + "=" * 115)
    print(f"{'ALERT ID':<36} | {'SEVERITY':<8} | {'TYPE':<28} | {'SOURCE':<22} | {'STATUS':<12}")
    print("=" * 115)
    for a in alerts:
        src = f"{a.source_mac or ''} {a.source_ip or ''}".strip() or "N/A"
        print(f"{a.alert_id:<36} | {a.severity:<8} | {a.detection_type:<28} | {src:<22} | {a.status:<12}")
    print("=" * 115)
    print(f"Total Alerts: {len(alerts)}\n")


def cmd_risk_report(db: DatabaseManager, device_id: str) -> None:
    """Display detailed explainable risk breakdown for a device."""
    record = db.get_device_risk_score(device_id)
    if not record:
        print(f"No risk score record found for device '{device_id}'.")
        return

    print("\n" + "=" * 80)
    print(f"EXPLAINABLE RISK REPORT: {device_id}")
    print(f"Overall Risk Score: {record['risk_score']:.1f}/100  (Severity: {record['severity']})")
    print(f"Last Evaluated:     {record['updated_at'].strftime('%Y-%m-%d %H:%M:%S UTC')}")
    print("=" * 80)
    signals = record.get("contributing_signals", [])
    if signals:
        print("Contributing Signals:")
        for idx, sig in enumerate(signals, 1):
            print(f"  {idx}. [{sig.get('category')}] {sig.get('title')}: +{sig.get('score_contribution', 0.0):.1f} pts")
            evidence = sig.get("evidence", {})
            for k, v in evidence.items():
                print(f"     * {k}: {v}")
    else:
        print("No risk signals observed for this device.")
    print("=" * 80 + "\n")


def cmd_list_interfaces() -> None:
    """Print tabular list of available local network interfaces."""
    interfaces = PacketSensor.list_interfaces()
    print("\n" + "=" * 110)
    print(f"{'INTERFACE NAME':<35} | {'IP ADDRESS':<16} | {'MAC ADDRESS':<18} | {'DESCRIPTION':<32}")
    print("=" * 110)
    for iface in interfaces:
        name = iface.get("name", "")[:34]
        ip = iface.get("ip", "")[:15]
        mac = iface.get("mac", "")[:17]
        desc = iface.get("description", "")[:32]
        print(f"{name:<35} | {ip:<16} | {mac:<18} | {desc:<32}")
    print("=" * 110)
    print(f"Total Detected Interfaces: {len(interfaces)}\n")


def cmd_reset_db(config: AppConfig) -> None:
    """Wipe SQLite database and re-initialize with fresh schema and approved assets."""
    db_file = config.database.db_file
    if db_file.exists():
        try:
            db_file.unlink()
            print(f"Removed existing database file: {db_file}")
        except Exception as e:
            print(f"Warning: Could not remove database file directly: {e}")
    # Also remove WAL and SHM if present
    for suffix in ["-wal", "-shm"]:
        sidecar = db_file.with_name(db_file.name + suffix)
        if sidecar.exists():
            try:
                sidecar.unlink()
            except Exception:
                pass

    db = DatabaseManager(config.database.db_file, config.database.schema_file)
    db.init_db()
    if config.inventory.approved_devices_file.exists():
        count = db.import_approved_assets_from_json(config.inventory.approved_devices_file)
        print(f"Database reset complete. Imported {count} approved devices.")
    else:
        print("Database reset complete.")



def main() -> None:
    """CLI argument parser and entry point."""
    parser = argparse.ArgumentParser(
        description="Rogue Device Detection & Network Behavior Profiling",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--mode",
        choices=["simulate", "live"],
        default="simulate",
        help="Run sensor in simulation mode (offline replay) or live capture mode",
    )
    parser.add_argument(
        "--interface",
        type=str,
        default=None,
        help="Network interface name to bind for live capture (e.g. 'eth0', 'Wi-Fi')",
    )
    parser.add_argument(
        "--duration",
        type=float,
        default=0.0,
        help="Run duration in seconds before exiting (0 runs indefinitely or until replay ends)",
    )
    parser.add_argument(
        "--init-db",
        action="store_true",
        help="Initialize or reset SQLite database schema",
    )
    parser.add_argument(
        "--reset-db",
        action="store_true",
        help="Reset database: wipe existing data, recreate schema, and re-import approved assets",
    )
    parser.add_argument(
        "--list-interfaces",
        action="store_true",
        help="Display list of detected network interfaces for live capture binding",
    )
    parser.add_argument(
        "--list-devices",
        action="store_true",
        help="Display the current inventory of observed devices with risk scores",
    )
    parser.add_argument(
        "--list-alerts",
        action="store_true",
        help="Display security alerts",
    )
    parser.add_argument(
        "--risk-report",
        type=str,
        metavar="DEVICE_ID",
        help="Display detailed explainable risk report for a specific device ID",
    )
    parser.add_argument(
        "--update-alert",
        type=str,
        metavar="ALERT_ID",
        help="Update status of an alert (use with --status)",
    )
    parser.add_argument(
        "--status",
        choices=[s.value for s in AlertStatus],
        help="New status for alert investigation",
    )
    parser.add_argument(
        "--notes",
        type=str,
        default="Updated via CLI",
        help="Analyst investigation notes",
    )

    args = parser.parse_args()
    config = load_config()

    if args.mode == "simulate":
        config.sensor.simulation_mode = True
    elif args.mode == "live":
        config.sensor.simulation_mode = False

    if args.interface:
        config.sensor.interface = args.interface

    configure_logging(config.log_level, str(config.log_file) if config.log_file else None)

    # Standalone query commands
    if args.list_interfaces:
        cmd_list_interfaces()
        return

    if args.reset_db:
        cmd_reset_db(config)
        return

    if args.init_db:
        db = DatabaseManager(config.database.db_file, config.database.schema_file)
        db.init_db()
        print("Database schema successfully initialized.")
        return

    if args.list_devices:
        db = DatabaseManager(config.database.db_file, config.database.schema_file)
        cmd_list_devices(db)
        return

    if args.list_alerts:
        db = DatabaseManager(config.database.db_file, config.database.schema_file)
        cmd_list_alerts(db, status=args.status)
        return

    if args.risk_report:
        db = DatabaseManager(config.database.db_file, config.database.schema_file)
        cmd_risk_report(db, device_id=args.risk_report)
        return

    if args.update_alert:
        if not args.status:
            print("Error: --status is required when updating an alert.")
            sys.exit(1)
        db = DatabaseManager(config.database.db_file, config.database.schema_file)
        success = db.update_alert_status(
            alert_id=args.update_alert,
            new_status=args.status,
            analyst="Security Analyst (CLI)",
            notes=args.notes,
        )
        if success:
            print(f"Successfully updated alert {args.update_alert} to {args.status}.")
        else:
            print(f"Alert with ID {args.update_alert} not found.")
        return

    # Start monitoring application
    app = NetworkMonitoringApp(config)

    def sig_handler(sig, frame):
        app.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, sig_handler)
    app.start(duration=args.duration)


if __name__ == "__main__":
    main()
