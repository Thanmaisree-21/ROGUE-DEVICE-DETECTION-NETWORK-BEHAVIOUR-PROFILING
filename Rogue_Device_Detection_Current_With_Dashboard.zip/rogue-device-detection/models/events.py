"""
Network event model representing parsed packet metadata.
Payload data is omitted to respect privacy and storage efficiency.
"""

from dataclasses import dataclass, asdict, fields
from datetime import datetime, timezone
from typing import Optional, Dict, Any


@dataclass
class NetworkEvent:
    """Represents an observed network frame/packet metadata record."""
    timestamp: datetime
    src_mac: Optional[str] = None
    dst_mac: Optional[str] = None
    src_ip: Optional[str] = None
    dst_ip: Optional[str] = None
    ip_version: Optional[int] = 4
    protocol: str = "OTHER"  # ARP, TCP, UDP, ICMP, DHCP, DNS, OTHER
    src_port: Optional[int] = None
    dst_port: Optional[int] = None
    packet_size: int = 0
    tcp_flags: Optional[str] = None
    info: Optional[str] = None
    raw_summary: Optional[str] = None
    is_synthetic: bool = False
    scenario: Optional[str] = None
    dhcp_message_type: Optional[str] = None
    dhcp_server_id: Optional[str] = None
    is_dns: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary with ISO-formatted timestamp."""
        res = asdict(self)
        res["timestamp"] = self.timestamp.isoformat()
        return res

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NetworkEvent":
        """Deserialize from dictionary with backward compatibility for extra/missing fields."""
        d = dict(data)
        if isinstance(d.get("timestamp"), str):
            ts_str = d["timestamp"]
            if ts_str.endswith("Z"):
                ts_str = ts_str[:-1] + "+00:00"
            d["timestamp"] = datetime.fromisoformat(ts_str)
        elif isinstance(d.get("timestamp"), (int, float)):
            d["timestamp"] = datetime.fromtimestamp(d["timestamp"], tz=timezone.utc)
        elif d.get("timestamp") is None:
            d["timestamp"] = datetime.now(timezone.utc)

        # Filter only fields declared on the dataclass
        valid_field_names = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in d.items() if k in valid_field_names}
        return cls(**filtered)

    @property
    def display_str(self) -> str:
        """Human-friendly summary for logs and investigation."""
        src = f"{self.src_mac or '??'} ({self.src_ip or '??'})"
        dst = f"{self.dst_mac or '??'} ({self.dst_ip or '??'})"
        ports = f" {self.src_port}->{self.dst_port}" if self.src_port or self.dst_port else ""
        synth = " [SYNTHETIC]" if self.is_synthetic else ""
        return f"[{self.timestamp.strftime('%H:%M:%S')}{synth}] {self.protocol}{ports}: {src} -> {dst} ({self.packet_size} bytes)"
