"""
Device and asset inventory models.
Tracks persistent identities, IP history, approval states, and counters.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, List, Dict, Any


class DeviceStatus(str, Enum):
    """Device authorization classification."""
    APPROVED = "APPROVED"
    UNRECOGNIZED = "UNRECOGNIZED"
    SUSPICIOUS = "SUSPICIOUS"
    BLOCKED = "BLOCKED"


@dataclass
class ApprovedAsset:
    """Pre-registered authorized network asset."""
    mac_address: str  # Normalized uppercase "XX:XX:XX:XX:XX:XX"
    device_name: str
    device_type: str = "Standard Host"  # Workstation, Server, Printer, Gateway, IoT
    assigned_ip: Optional[str] = None
    owner: str = "IT / Security"
    added_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    description: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mac_address": self.mac_address.upper(),
            "device_name": self.device_name,
            "device_type": self.device_type,
            "assigned_ip": self.assigned_ip,
            "owner": self.owner,
            "added_at": self.added_at.isoformat(),
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ApprovedAsset":
        d = dict(data)
        if isinstance(d.get("added_at"), str):
            ts_str = d["added_at"]
            if ts_str.endswith("Z"):
                ts_str = ts_str[:-1] + "+00:00"
            d["added_at"] = datetime.fromisoformat(ts_str)
        elif d.get("added_at") is None:
            d["added_at"] = datetime.now(timezone.utc)
        d["mac_address"] = d["mac_address"].upper()
        return cls(**d)


@dataclass
class DeviceIPObservation:
    """Historical association of an IP address observed for a device."""
    device_id: str
    ip_address: str
    observed_at: datetime
    source: str = "IP_TRAFFIC"  # ARP, DHCP, IP_TRAFFIC

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "ip_address": self.ip_address,
            "observed_at": self.observed_at.isoformat(),
            "source": self.source,
        }


@dataclass
class Device:
    """
    Observed network device entity.
    Identified primarily by MAC address when available, but accounts for
    dynamic IP reallocations and MAC spoofing concerns.
    """
    device_id: str
    mac_address: Optional[str] = None
    current_ip: Optional[str] = None
    first_seen: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_seen: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_approved: bool = False
    approval_status: str = DeviceStatus.UNRECOGNIZED.value
    vendor: Optional[str] = None
    hostname: Optional[str] = None
    total_packets: int = 0
    total_bytes: int = 0
    ip_history: List[str] = field(default_factory=list)

    def normalize_mac(self) -> Optional[str]:
        if self.mac_address:
            self.mac_address = self.mac_address.upper().replace("-", ":")
        return self.mac_address

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "mac_address": self.mac_address,
            "current_ip": self.current_ip,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "is_approved": 1 if self.is_approved else 0,
            "approval_status": self.approval_status,
            "vendor": self.vendor,
            "hostname": self.hostname,
            "total_packets": self.total_packets,
            "total_bytes": self.total_bytes,
            "ip_history": self.ip_history,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Device":
        d = dict(data)
        if isinstance(d.get("first_seen"), str):
            ts = d["first_seen"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["first_seen"] = datetime.fromisoformat(ts)
        if isinstance(d.get("last_seen"), str):
            ts = d["last_seen"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["last_seen"] = datetime.fromisoformat(ts)
        if isinstance(d.get("is_approved"), int):
            d["is_approved"] = bool(d["is_approved"])
        if "ip_history" not in d or d["ip_history"] is None:
            d["ip_history"] = []
        return cls(**d)
