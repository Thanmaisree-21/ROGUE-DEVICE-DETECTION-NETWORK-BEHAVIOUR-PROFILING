"""
Device traffic metrics and behavioral baseline models.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Dict, List, Any


@dataclass
class TrafficWindowMetrics:
    """Aggregated traffic metrics for a single observation window."""
    device_id: str
    window_start: datetime
    window_end: datetime
    packet_count: int = 0
    byte_count: int = 0
    packet_rate: float = 0.0  # packets per second
    byte_rate: float = 0.0    # bytes per second
    distinct_targets: int = 0
    distinct_ports: int = 0
    protocol_counts: Dict[str, int] = field(default_factory=dict)
    syn_packet_count: int = 0
    ack_packet_count: int = 0
    connection_attempts: int = 0
    dns_query_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "window_start": self.window_start.isoformat(),
            "window_end": self.window_end.isoformat(),
            "packet_count": self.packet_count,
            "byte_count": self.byte_count,
            "packet_rate": round(self.packet_rate, 2),
            "byte_rate": round(self.byte_rate, 2),
            "distinct_targets": self.distinct_targets,
            "distinct_ports": self.distinct_ports,
            "protocol_counts": self.protocol_counts,
            "syn_packet_count": self.syn_packet_count,
            "ack_packet_count": self.ack_packet_count,
            "connection_attempts": self.connection_attempts,
            "dns_query_count": self.dns_query_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrafficWindowMetrics":
        d = dict(data)
        if isinstance(d.get("window_start"), str):
            ts = d["window_start"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["window_start"] = datetime.fromisoformat(ts)
        if isinstance(d.get("window_end"), str):
            ts = d["window_end"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["window_end"] = datetime.fromisoformat(ts)
        return cls(**d)

    def to_feature_vector(self) -> List[float]:
        """Convert metrics to a numerical feature vector for ML clustering/isolation forest."""
        return [
            float(self.packet_rate),
            float(self.byte_rate),
            float(self.distinct_targets),
            float(self.distinct_ports),
            float(self.syn_packet_count),
            float(self.dns_query_count),
        ]


@dataclass
class DeviceBaseline:
    """Learned behavioral baseline profile for a device."""
    device_id: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    sample_windows: int = 0
    mean_packet_rate: float = 0.0
    std_packet_rate: float = 0.0
    mean_byte_rate: float = 0.0
    std_byte_rate: float = 0.0
    expected_protocols: Dict[str, float] = field(default_factory=dict)
    known_ports: List[int] = field(default_factory=list)
    mean_dns_queries: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "sample_windows": self.sample_windows,
            "mean_packet_rate": round(self.mean_packet_rate, 2),
            "std_packet_rate": round(self.std_packet_rate, 2),
            "mean_byte_rate": round(self.mean_byte_rate, 2),
            "std_byte_rate": round(self.std_byte_rate, 2),
            "expected_protocols": self.expected_protocols,
            "known_ports": self.known_ports,
            "mean_dns_queries": round(self.mean_dns_queries, 2),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DeviceBaseline":
        d = dict(data)
        if isinstance(d.get("created_at"), str):
            ts = d["created_at"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["created_at"] = datetime.fromisoformat(ts)
        if isinstance(d.get("updated_at"), str):
            ts = d["updated_at"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["updated_at"] = datetime.fromisoformat(ts)
        return cls(**d)
