"""
Security alert and investigation lifecycle models.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, Dict, Any
import uuid


class AlertSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class AlertStatus(str, Enum):
    NEW = "NEW"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    UNDER_REVIEW = "UNDER_REVIEW"
    RESOLVED = "RESOLVED"
    FALSE_POSITIVE = "FALSE_POSITIVE"


@dataclass
class Alert:
    """Security alert emitted by detection modules."""
    alert_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    detection_type: str = "UNAPPROVED_DEVICE"
    severity: str = AlertSeverity.MEDIUM.value
    source_device_id: Optional[str] = None
    source_mac: Optional[str] = None
    source_ip: Optional[str] = None
    target_ip: Optional[str] = None
    target_port: Optional[int] = None
    title: str = "Alert"
    description: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    status: str = AlertStatus.NEW.value
    resolution_notes: Optional[str] = None
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alert_id": self.alert_id,
            "timestamp": self.timestamp.isoformat(),
            "detection_type": self.detection_type,
            "severity": self.severity,
            "source_device_id": self.source_device_id,
            "source_mac": self.source_mac,
            "source_ip": self.source_ip,
            "target_ip": self.target_ip,
            "target_port": self.target_port,
            "title": self.title,
            "description": self.description,
            "evidence": self.evidence,
            "status": self.status,
            "resolution_notes": self.resolution_notes,
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Alert":
        d = dict(data)
        if isinstance(d.get("timestamp"), str):
            ts = d["timestamp"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["timestamp"] = datetime.fromisoformat(ts)
        if isinstance(d.get("updated_at"), str):
            ts = d["updated_at"]
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            d["updated_at"] = datetime.fromisoformat(ts)
        if not d.get("evidence"):
            d["evidence"] = {}
        return cls(**d)


@dataclass
class AlertHistory:
    """Audit log entry for an alert status update or investigation note."""
    alert_id: str
    changed_at: datetime
    previous_status: str
    new_status: str
    changed_by: str = "Security Analyst"
    comment: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alert_id": self.alert_id,
            "changed_at": self.changed_at.isoformat(),
            "previous_status": self.previous_status,
            "new_status": self.new_status,
            "changed_by": self.changed_by,
            "comment": self.comment,
        }
