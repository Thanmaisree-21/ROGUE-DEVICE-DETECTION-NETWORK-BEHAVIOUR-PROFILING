# Rogue Device Detection & Network Behavior Profiling

A defensive network intrusion and monitoring system designed for Computer Networks and Ethical Hacking course projects. The application discovers network-connected devices, identifies unapproved/rogue hardware against an authorized inventory baseline, extracts rolling behavioral features, runs four independent detection modules, and computes explainable multi-signal risk scores (0–100) with structured evidence.

> **Defensive & Ethical Monitoring Notice**:
> This software is designed exclusively for authorized network defense, lab research, and educational analysis. It operates in **monitoring-only mode** and must only be executed on networks and devices that the operator owns or has explicit permission to monitor. It does not perform active exploits, packet injection attacks, or MITM poisoning.

---

## 1. Key Features

### A. Four Independent Detection Modules
- **1. Port Scanning & Reconnaissance Detection (`PortScanDetector`)**:
  - Monitors distinct destination ports probed (vertical scan).
  - Monitors distinct target hosts contacted (horizontal sweep).
  - Inspects TCP connection attempt volume and SYN flag patterns.
  - Fully configurable thresholds and sliding time windows.
  - Generates structured alerts with source, target, distinct port counts, and severity `HIGH`.
- **2. DoS-Like Traffic Anomaly Detection (`DosAnomalyDetector`)**:
  - Monitors transmission packet rates, byte volume bursts, and request concentrations focused on single target hosts.
  - Compares real-time transmission rates against historical baseline averages ($Z$-score statistical testing).
  - **Defensive Labeling**: Alerts explicitly indicate that traffic resembles an abnormal volume burst or traffic flood; they never claim an intentional attack is confirmed.
- **3. ARP Spoofing & Gateway Integrity Detection (`ArpSpoofDetector`)**:
  - Validates default gateway hardware mapping integrity against configured expected values (`expected_gateway_ip`, `expected_gateway_mac`).
  - Identifies conflicting IP-to-MAC mapping announcements.
  - Maintains a historical sliding queue to detect rapid MAC flapping and repeated conflicting claims while tolerating single legitimate reassignments.
  - Alerts on gateway hijacks with `CRITICAL` severity and host conflicts with `HIGH` severity.
- **4. Rogue DHCP Detection (`RogueDhcpDetector`)**:
  - Differentiates client broadcasts (`DISCOVER`, `REQUEST`) from server lease offers (`OFFER`, `ACK`).
  - Detects offers originating from server identifiers (Option 54) absent from the authorized server inventory (`approved_dhcp_servers`).
  - Detects multiple competing DHCP servers offering leases in the monitored lab.
  - Supports static-only network configurations (`allow_no_dhcp=True`), immediately flagging unauthorized DHCP presence.

### B. Explainable Multi-Signal Risk Scoring (0–100)
- The [`RiskScorer`](file:///c:/Users/thanm/Downloads/Rouge%20device%20detection/profiling/risk_scorer.py) consolidates observations into an explainable 0–100 score per device.
- **Anti-Double-Counting**:
  - Alerts are grouped by independent risk categories with sub-score maximum caps.
  - Diminishing marginal returns are applied to repeated alerts within the same domain ($S = \text{Base} \times (1 + \alpha \ln(N))$) to prevent runaway scores from alert flooding.
  - Contributing signals and raw evidence are fully stored in the database for transparent analyst auditing.
- **Project-Defined Severity Thresholds**:
  - **Low**: $0.0 \le \text{Score} < 30.0$
  - **Medium**: $30.0 \le \text{Score} < 60.0$
  - **High**: $60.0 \le \text{Score} < 80.0$
  - **Critical**: $80.0 \le \text{Score} \le 100.0$

### C. Behavioral Profiling & Optional Isolation Forest
- Rolling feature extraction calculates:
  - Packet rates (pkts/s) and byte rates (bytes/s).
  - Distinct target IPs and destination ports.
  - Connection attempts (TCP SYN probes + UDP probes).
  - Protocol distributions (TCP, UDP, ARP, ICMP, DHCP).
  - DNS query counts (where DNS traffic on port 53 is observable).
- **Optional Isolation Forest Detector**:
  - Uses `scikit-learn` to identify complex multivariate anomalies across all feature dimensions simultaneously.
  - Completely decoupled from the rule-based modules; can be enabled or disabled independently in configuration (`enable_isolation_forest`).
  - Uses defensive anomaly labels ("statistical anomaly; not a confirmed attack").

### D. SQLite Persistence & Investigation Lifecycle
- Relational SQLite schema storing pre-approved assets, observed devices, dynamic IP histories, packet metadata, rolling traffic aggregates, behavioral baselines, alerts, audit histories, and calculated risk scores.
- Supports complete alert workflow tracking (`NEW`, `ACKNOWLEDGED`, `UNDER_REVIEW`, `RESOLVED`, `FALSE_POSITIVE`).

---

## 2. System Architecture

```
                       +-----------------------------+
                       |   Packet Sensor (Scapy)     |
                       | (Live Sniff or Simulation)  |
                       +--------------+--------------+
                                      |
                               NetworkEvent
                                      |
             +------------------------+------------------------+
             |                                                 |
             v                                                 v
 +-------------------------+                       +-------------------------+
 | Device Discovery        |                       | Database Manager        |
 | - MAC/IP Correlation    |                       | (SQLite Storage)        |
 | - Dynamic IP History    |                       | - Events & Aggregates   |
 | - Inventory Status      |                       | - Inventories & Alerts  |
 +-----------+-------------+                       | - Device Risk Scores    |
             |                                     +------------+------------+
       Device State                                             ^
             |                                                  |
             v                                                  |
 +---------------------------------------------------------+    |
 | Shared Detection Engine                                 |    |
 | - RogueDeviceDetector        (Unrecognized assets)      |    |
 | - PortScanDetector           (Vertical & horizontal)    |    |
 | - DosAnomalyDetector         (Rate bursts & floods)     |    |
 | - ArpSpoofDetector           (Gateway & rapid flapping) |----+
 | - RogueDhcpDetector          (Unapproved server offers) | Alerts & Signals
 +---------------------------------------------------------+    |
             |                                                  |
             v                                                  v
 +-------------------------+                       +-------------------------+
 | Behavior Profiler       |                       | Explainable Risk Scorer |
 | - Rolling Window Stats  |   Feature Vectors     | - Anti-Double Counting  |
 | - Mean/StdDev Baselines |---------------------->| - Category Sub-Caps     |
 | - Isolation Forest (ML) |                       | - 0-100 Device Scoring  |
 +-------------------------+                       +-------------------------+
                                                                |
                                                                v
                                                        CLI Management /
                                                  DashboardDataInterface (Unprivileged)
```

### Virtual Lab Network Topology

```
              +-------------------------------------------------------------+
              |           SUBNET: 192.168.1.0/24 (Subnet Mask: 255.255.255.0)|
              +-------------------------------------------------------------+
                                             |
             +-------------------------------+-------------------------------+
             |                               |                               |
             v                               v                               v
+-------------------------+     +-------------------------+     +-------------------------+
| Default Gateway/Router  |     | File Server / NAS       |     | Admin Workstation       |
| IP:  192.168.1.1        |     | IP:  192.168.1.20       |     | IP:  192.168.1.10       |
| MAC: 00:1A:2B:3C:4D:5E  |     | MAC: 00:0C:29:4F:8D:12  |     | MAC: 00:50:56:A1:B2:C3  |
| Status: APPROVED        |     | Status: APPROVED        |     | Status: APPROVED        |
| Role: DHCP & DNS Server |     | Role: Internal Storage  |     | Role: Security Ops      |
+-------------------------+     +-------------------------+     +-------------------------+
             |                               |                               |
             +-------------------------------+-------------------------------+
                                             |
                                             v
                      +---------------------------------------------+
                      |         MANAGED ETHERNET SWITCH             |
                      |   (SPAN Port / Mirroring to Port 8)         |
                      +----------------------+----------------------+
                                             |
                                             | (SPAN / Mirror Feed)
                                             v
                               +-----------------------------+
                               | MONITORING STATION (IDS)    |
                               | (Antigravity Defensive IDS) |
                               | - PacketSensor (Scapy)      |
                               | - 4 Independent Detectors   |
                               | - Behavior Profiler & ML    |
                               | - SQLite rogue_detector.db  |
                               +-----------------------------+
                                             ^
                                             |
         +-----------------------------------+-----------------------------------+
         |                                   |                                   |
         v                                   v                                   v
+-------------------------+         +-------------------------+         +-------------------------+
| [Scenario A] Scan Node  |         | [Scenario B] Surge Node |         | [Scenario C & D] Rogues |
| IP:  192.168.1.199      |         | IP:  192.168.1.210      |         | C: DE:AD:BE:EF:00:01    |
| MAC: B8:27:EB:99:88:77  |         | MAC: 00:11:22:33:44:99  |         |    (Gateway Spoof Attempt)|
| Status: UNRECOGNIZED    |         | Status: UNRECOGNIZED    |         | D: 00:E0:4C:12:34:56    |
| Action: TCP Port Scan   |         | Action: Traffic Flood   |         |    (Rogue DHCP Server)  |
+-------------------------+         +-------------------------+         +-------------------------+
```

---

## 3. Project Directory Structure

```
rogue-device-detection/
├── app.py                      # Master application runner & CLI management tool
├── demo_scenarios.py           # Demonstration runner for Scenarios A, B, C, D
├── dashboard_interface.py      # Unprivileged query API for dashboards and reporting
├── config.py                   # Centralized configuration dataclasses
├── requirements.txt            # Python dependencies (Scapy, Pandas, Pytest, Scikit-learn)
├── README.md                   # System documentation & architectural reference
├── rogue_detector.db           # Persistent SQLite database (auto-created)
│
├── database/
│   ├── __init__.py
│   ├── schema.sql              # Relational SQLite DDL with indexes & foreign keys
│   └── db.py                   # Thread-safe DatabaseManager with CRUD and audit logging
│
├── models/
│   ├── __init__.py
│   ├── events.py               # NetworkEvent data model (metadata only, no payload)
│   ├── device.py               # Device, ApprovedAsset, DeviceIPObservation
│   ├── alert.py                # Alert, AlertHistory, AlertStatus, AlertSeverity
│   └── profile.py              # TrafficWindowMetrics, DeviceBaseline
│
├── sensor/
│   ├── __init__.py
│   ├── protocol_parser.py      # Scapy metadata parser (L2-L4, DHCP message types, DNS)
│   ├── device_discovery.py     # Device inventory correlation & dynamic IP handler
│   └── packet_sensor.py        # Bounded buffer, live sniffer & simulated replay sensor
│
├── detection/
│   ├── __init__.py
│   ├── base_detector.py        # BaseDetector ABC with per-rule cooldown deduplication
│   ├── rogue_device_detector.py# Unapproved hardware detector
│   ├── port_scan_detector.py   # Port scanning & horizontal host sweep module
│   ├── dos_detector.py         # DoS-like traffic flood & burst anomaly module
│   ├── arp_spoof_detector.py   # Gateway integrity & rapid ARP flapping module
│   ├── rogue_dhcp_detector.py  # Rogue DHCP offer & multi-server conflict module
│   └── detection_engine.py     # Shared engine orchestrating all detection rules
│
├── profiling/
│   ├── __init__.py
│   ├── feature_extractor.py    # Rolling window traffic feature aggregator
│   ├── behavior_profiler.py    # Statistical baseline learner & anomaly detector
│   ├── isolation_forest_detector.py # Independent Scikit-learn ML outlier detector
│   └── risk_scorer.py          # Multi-signal explainable risk scorer (0-100)
│
├── data/
│   ├── approved_devices.json   # Approved hardware inventory fixture
│   └── sample_events.json      # Deterministic simulation fixture (7 security scenarios)
│
└── tests/
    ├── __init__.py
    ├── test_db.py              # Database integrity, transactions, and risk scores
    ├── test_protocol_parser.py # Header parsing & payload omission verification
    ├── test_inventory.py       # Device discovery & dynamic IP reassignment tests
    ├── test_detector.py        # Rogue device detector & engine integration tests
    ├── test_port_scan_detector.py   # Vertical port scans & horizontal sweeps
    ├── test_dos_detector.py         # Rate bursts, baseline deviations & defensive wording
    ├── test_arp_spoof_detector.py   # Gateway hijacks, rapid flapping & conflicts
    ├── test_rogue_dhcp_detector.py  # Unapproved offers, client filtering & static segments
    ├── test_risk_scorer.py          # Explainable scoring & anti-double counting tests
    ├── test_isolation_forest.py     # Isolation Forest multivariate outlier tests
    ├── test_malformed_events.py     # Resilience against corrupt/incomplete packets
    ├── test_profiler.py             # Feature extraction and Z-score baselines
    ├── test_sensor_simulation.py    # Circular buffer & playback playback tests
    ├── test_dashboard_interface.py  # Unprivileged query layer & export tests
    └── test_demo_scenarios.py       # Demonstration workflows & event generators
```

---

## 4. Setup and Installation

### Prerequisites
- Python 3.10+ (Tested on Python 3.14)
- Windows / Linux / macOS
- For optional live capture: Npcap (Windows) or libpcap (Linux/macOS) with administrative privileges.

### Step 1: Virtual Environment Setup
```powershell
# Create dedicated virtual environment
python -m venv .venv

# Activate on Windows PowerShell:
.\.venv\Scripts\Activate.ps1

# Activate on Linux/macOS:
source .venv/bin/activate
```

### Step 2: Install Dependencies
```powershell
pip install -r requirements.txt
```

---

## 5. Running the Tests

Execute all 67 automated unit and integration tests with `pytest`:

```powershell
python -m pytest -v
```

**Test Verification Summary:**
```text
============================= 67 passed in 9.70s =============================
tests/test_arp_spoof_detector.py ......................... [  6%]
tests/test_dashboard_interface.py ........................ [ 18%]
tests/test_db.py ......................................... [ 28%]
tests/test_demo_scenarios.py ............................. [ 40%]
tests/test_detector.py ................................... [ 48%]
tests/test_dos_detector.py ............................... [ 55%]
tests/test_inventory.py .................. ............... [ 61%]
tests/test_isolation_forest.py ........................... [ 64%]
tests/test_malformed_events.py ........................... [ 67%]
tests/test_port_scan_detector.py ......................... [ 73%]
tests/test_profiler.py ................................... [ 78%]
tests/test_protocol_parser.py ............................ [ 85%]
tests/test_risk_scorer.py ................................ [ 91%]
tests/test_rogue_dhcp_detector.py ........................ [ 97%]
tests/test_sensor_simulation.py .......................... [100%]
```

---

## 6. How to Run the Application

### A. Run Simulation Mode (Offline Replay)
Replays realistic multi-scenario events from `data/sample_events.json` without requiring elevated privileges:

```powershell
python app.py --mode simulate --duration 3
```

During simulation playback, the application evaluates:
1. Approved workstation traffic (DNS, HTTPS) without false positives.
2. Legitimate dynamic IP lease renewal for an approved MacBook without attack alerts.
3. Unrecognized Raspberry Pi joining the network (`UNAPPROVED_DEVICE`).
4. Reconnaissance port scan across 8 distinct ports (`PORT_SCAN_SUSPECT`).
5. Abnormal traffic volume flood directed at a internal server (`TRAFFIC_ANOMALY_DOS_BURST`).
6. Attacker hardware claiming default gateway IP `192.168.1.1` (`GATEWAY_ARP_SPOOF_SUSPECT` - CRITICAL).
7. Rapid ARP mapping alternation between two MACs on IP `192.168.1.55` (`ARP_RAPID_FLAPPING_SUSPECT`).
8. Unapproved DHCP server offering IP lease with server ID `192.168.1.254` (`ROGUE_DHCP_OFFER_UNAPPROVED`).

### B. View Observed Devices & Risk Scores
```powershell
python app.py --list-devices
```

**Example Output:**
```text
=========================================================================================================
DEVICE ID              | MAC ADDRESS        | CURRENT IP      | STATUS       | RISK  | SEVERITY | PKTS 
=========================================================================================================
mac_DE:AD:BE:EF:00:01  | DE:AD:BE:EF:00:01  | 192.168.1.1     | UNRECOGNIZED | 85    | CRITICAL | 3    
mac_00:E0:4C:12:34:56  | 00:E0:4C:12:34:56  | 192.168.1.254   | UNRECOGNIZED | 70    | HIGH     | 1    
mac_11:22:33:44:55:66  | 11:22:33:44:55:66  | 192.168.1.55    | UNRECOGNIZED | 65    | HIGH     | 3    
mac_B8:27:EB:99:88:77  | B8:27:EB:99:88:77  | 192.168.1.199   | UNRECOGNIZED | 58    | MEDIUM   | 660  
mac_3C:22:FB:44:55:66  | 3C:22:FB:44:55:66  | 192.168.1.105   | APPROVED     | 0     | LOW      | 21   
=========================================================================================================
```

### C. Inspect Detailed Explainable Risk Report
Inspect the exact signals, evidence, and scoring breakdown that produced a device's risk score:

```powershell
python app.py --risk-report "mac_DE:AD:BE:EF:00:01"
```

**Example Output:**
```text
================================================================================
EXPLAINABLE RISK REPORT: mac_DE:AD:BE:EF:00:01
Overall Risk Score: 85.0/100  (Severity: CRITICAL)
Last Evaluated:     2026-10-11 07:25:21 UTC
================================================================================
Contributing Signals:
  1. [UNKNOWN_DEVICE] Unrecognized Device Status: +25.0 pts
     * approval_status: UNRECOGNIZED
  2. [ARP_CONFLICT] ARP Mapping Conflict / Gateway Hijack: +60.0 pts
     * has_gateway_spoof: True
     * expected_gateway_mac: 00:1A:2B:3C:4D:5E
     * unauthorized_claiming_mac: DE:AD:BE:EF:00:01
     * risk_impact: Potential Man-in-the-Middle (MitM) or network interception.
================================================================================
```

### D. View Security Alerts & Update Investigation Workflow
```powershell
# List alerts
python app.py --list-alerts

# Update alert investigation status with audit logging
python app.py --update-alert "<ALERT_ID>" --status "ACKNOWLEDGED" --notes "Investigating physical drop in Lab 3"
```

### E. Run Deterministic Scenario Demonstrations (`demo_scenarios.py`)
Execute reproducible, student-grade CLI workflows for the four core defensive security scenarios:

```powershell
# Run Scenario A: Port Scanning Reconnaissance
python demo_scenarios.py --scenario A

# Run Scenario B: DoS-Like Traffic Anomaly / Volume Burst
python demo_scenarios.py --scenario B

# Run Scenario C: ARP Spoofing & Gateway Impersonation
python demo_scenarios.py --scenario C

# Run Scenario D: Rogue DHCP Server Lease Offer
python demo_scenarios.py --scenario D

# Run all scenarios sequentially with clean database reset and summary posture report
python demo_scenarios.py --reset --scenario all --report
```

Each workflow execution prints:
1. **Prerequisites & Baseline Configuration**: Approved assets, expected gateway IP/MAC, approved DHCP servers.
2. **Injected Synthetic Traffic Breakdown**: Timestamped protocol frames, source/destination IPs and MACs, flags/parameters.
3. **Pipeline Execution & Triggered Alerts**: Target detector results, alert ID, severity, and structured evidence dictionary.
4. **Device Risk Impact**: Recalculated 0–100 explainable risk score and contributing signal breakdown.
5. **Defensive Guidance & Mitigation**: Operator remediation steps (e.g., Dynamic ARP Inspection, DHCP Snooping, port isolation).

### F. Network Interface Enumeration & Database Management
```powershell
# List all detected local network interfaces with friendly names and addresses
python app.py --list-interfaces

# Run live packet capture bound to a specific interface (requires Admin / Npcap)
python app.py --mode live --interface "Wi-Fi" --duration 30

# Reset SQLite database (removes existing DB and sidecars, re-creates schema, reloads approved assets)
python app.py --reset-db
```

---

## 7. False-Positive Risks & Defensive Framing

Defensive intrusion monitoring requires careful evaluation to avoid false accusations and alert fatigue:

1. **Traffic Bursts vs. Confirmed Attacks (`DosAnomalyDetector`)**:
   - **Ethical & Defensive Phrasing**: High packet rates and byte volume bursts are explicitly labeled as **"TRAFFIC ANOMALY"** or **"DOS-LIKE BURST"**, never as confirmed malicious denial-of-service attacks.
   - **Legitimate Causes**: Scheduled cloud backups, automated software upgrades, database replication, video streaming, and internal file synchronization routinely cause sudden traffic spikes.
   - **Mitigation**: Anomalies are flagged with an investigation recommendation requiring analysts to inspect endpoint process states before taking disruptive isolation actions.

2. **Unapproved Hardware vs. Benign Devices (`RogueDeviceDetector`)**:
   - **Defensive Phrasing**: Unrecognized devices are classified as `UNRECOGNIZED` with severity `MEDIUM`.
   - **Legitimate Causes**: Guest devices, newly provisioned employee laptops, mobile phones on corporate Wi-Fi, or authorized IoT hardware awaiting CMDB registration.
   - **Mitigation**: Alerts trigger an asset verification request rather than automatic network shutdown.

3. **DHCP Client Requests vs. Server Responses (`RogueDhcpDetector`)**:
   - Legitimate DHCP clients broadcast `DISCOVER` and `REQUEST` messages with source IP `0.0.0.0`. The detector strictly discards client broadcasts and evaluates only server-issued `OFFER` and `ACK` messages to eliminate false positives on normal client onboarding.

---

## 8. Packet Visibility Limitations in Switched Networks

When transitioning from simulation mode to live network monitoring, defensive monitors encounter physical and protocol visibility constraints:

1. **Switched Ethernet Segmentation**:
   - Modern network switches forward unicast packets only to the destination MAC's physical switch port based on their MAC address learning tables (CAM table).
   - Without a **SPAN (Port Mirroring)** session, **Network TAP**, or managed switch monitoring configuration, the sensor only observes broadcast frames (ARP, DHCP Discover), multicast packets, and traffic destined to or originating from the monitoring host itself.
2. **Encrypted Payloads**:
   - Modern protocols use TLS/HTTPS, SSH, or QUIC. The application's design is **payload-independent**, relying solely on observable L2-L4 transport and session headers (IPs, MACs, TCP flags, port distributions, packet rates), preserving privacy and functioning even when payloads are encrypted.
3. **MAC Address Randomization**:
   - Mobile operating systems (iOS, Android, Windows) randomize MAC addresses when scanning or connecting to untrusted Wi-Fi. The inventory system tracks dynamic IP histories and OUI vendors, but operators should ensure enterprise networks enforce 802.1X (EAP-TLS) authentication for definitive machine identification.

---

## 9. Unprivileged Dashboard Data Interface (`DashboardDataInterface`)

The system architecture completely decouples the data presentation layer from low-level packet capture processes through [`DashboardDataInterface`](file:///c:/Users/thanm/Downloads/Rouge%20device%20detection/dashboard_interface.py):

- **Zero Privileges Required**: Interacts purely with the SQLite database file via read/write SQL queries; requires no root/Administrator privileges, raw socket permissions, or packet capture drivers.
- **Available Query Methods**:
  - `get_system_overview()`: Returns KPI metrics (total devices, approved, unrecognized, alert counts by severity/status, maximum risk score).
  - `get_devices_table()`: Returns flattened device inventory joined with latest risk scores and severities.
  - `get_device_detail(device_id)`: Fetches complete device metadata, behavioral baseline, risk score report, and correlated security alerts.
  - `get_alerts_table(status_filter, severity_filter, limit)`: Filterable list of security alerts.
  - `get_alert_detail(alert_id)`: Returns alert evidence and full analyst audit investigation history.
  - `update_alert_status(alert_id, new_status, analyst, notes)`: Transitions alert state and records audit log.
  - `get_traffic_timeseries(device_id, limit)`: Returns chronological window aggregates for Plotly throughput charts.
  - `get_protocol_distribution()`: Aggregate protocol breakdown across captured events.
  - `export_security_report()`: Generates complete JSON audit report of network posture.

---

## 10. Course Project Presentation Checklist

For students demonstrating this project during lab evaluations and course presentations:

- [x] **1. Architecture & Design Principles**:
  - [x] Clean modular pipeline separating capture, discovery, detection, profiling, and storage.
  - [x] Payload omission to maintain privacy and defensive ethics.
  - [x] Zero-privilege dashboard access layer decoupled from packet sniffing.
- [x] **2. Four Independent Detection Modules**:
  - [x] Port Scan Detector (`PORT_SCAN_SUSPECT`) with distinct port and host sweep thresholds.
  - [x] DoS Anomaly Detector (`TRAFFIC_ANOMALY_DOS_BURST`) with statistical baseline comparison and defensive labeling.
  - [x] ARP Spoof Detector (`GATEWAY_ARP_SPOOF_SUSPECT` - CRITICAL) and rapid flapping detection.
  - [x] Rogue DHCP Detector (`ROGUE_DHCP_OFFER_UNAPPROVED`) with client vs. server message discrimination.
- [x] **3. Behavioral Profiling & Risk Scoring**:
  - [x] Rolling window feature extraction (packet/byte rates, unique targets/ports, TCP connection attempts).
  - [x] Explainable 0–100 risk scoring with category sub-caps and anti-double-counting.
  - [x] Optional unsupervised Machine Learning (Isolation Forest) multivariate anomaly detection.
- [x] **4. Persistence & Audit Trail**:
  - [x] SQLite relational schema with foreign keys, indexes, and WAL mode.
  - [x] Investigation workflow transitions (`NEW` -> `ACKNOWLEDGED` -> `RESOLVED`) with analyst audit logging.
- [x] **5. Reproducible Verification & Demonstrations**:
  - [x] 67 automated unit and integration tests passing (`python -m pytest`).
  - [x] Standalone demonstration runner for Scenarios A, B, C, D (`python demo_scenarios.py --scenario all`).
  - [x] Offline simulation replay without requiring root/Administrator or specialized hardware.
