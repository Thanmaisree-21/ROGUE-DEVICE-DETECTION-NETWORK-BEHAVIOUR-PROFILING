"""
Configuration module for Rogue Device Detection & Network Behavior Profiling.
Centralizes all settings, file paths, thresholds, and operational flags.
"""

from dataclasses import dataclass, field
import os
from pathlib import Path
from typing import Optional, List


# Base directory for the project
BASE_DIR = Path(__file__).resolve().parent


@dataclass
class SensorConfig:
    """Configuration for packet capture and event buffering."""
    # Network interface name (None uses the OS default interface)
    interface: Optional[str] = None
    
    # Maximum number of parsed events retained in the in-memory buffer
    buffer_size: int = 2000
    
    # Berkeley Packet Filter (BPF) filter string, e.g. 'ip or arp'
    bpf_filter: str = "ip or arp"
    
    # Run in simulation mode without requiring root/admin raw sockets
    simulation_mode: bool = True
    
    # Path to simulation data file
    sample_events_file: Path = field(
        default_factory=lambda: BASE_DIR / "data" / "sample_events.json"
    )
    
    # Sleep interval between simulated packets (in seconds)
    simulation_packet_delay: float = 0.05


@dataclass
class DatabaseConfig:
    """Configuration for SQLite storage."""
    db_file: Path = field(
        default_factory=lambda: BASE_DIR / "rogue_detector.db"
    )
    schema_file: Path = field(
        default_factory=lambda: BASE_DIR / "database" / "schema.sql"
    )
    # Enable SQLite WAL (Write-Ahead Logging) mode for concurrent read/write
    enable_wal_mode: bool = True


@dataclass
class InventoryConfig:
    """Configuration for device inventory and approved asset list."""
    approved_devices_file: Path = field(
        default_factory=lambda: BASE_DIR / "data" / "approved_devices.json"
    )
    # Auto-approve devices already stored in approved_devices.json
    auto_sync_approved: bool = True


@dataclass
class ProfilingConfig:
    """Configuration for rolling behavioral profiling and feature extraction."""
    # Duration of the rolling aggregation window in seconds
    window_seconds: float = 30.0
    
    # Minimum samples required before establishing a statistical baseline
    min_samples_for_baseline: int = 4
    
    # Multiplier of standard deviation for statistical anomaly detection (Z-score)
    zscore_threshold: float = 3.0
    
    # Threshold of distinct destination ports probed within a single window to flag port scanning
    port_scan_unique_ports_threshold: int = 12
    
    # Threshold of distinct destination IPs contacted within a single window to flag host scanning
    host_scan_unique_targets_threshold: int = 10
    
    # Optional Machine Learning: Isolation Forest for multivariate anomaly detection
    enable_isolation_forest: bool = True
    isolation_forest_contamination: float = 0.05
    isolation_forest_min_samples: int = 6


@dataclass
class PortScanDetectorConfig:
    """Configuration for Port Scanning Detection module."""
    enabled: bool = True
    ports_threshold: int = 8                    # Distinct destination ports probed
    connection_attempts_threshold: int = 20     # Total probe attempts in window
    target_hosts_threshold: int = 8             # Distinct hosts probed (horizontal scan)
    window_seconds: float = 15.0                # Sliding inspection window
    cooldown_seconds: float = 60.0              # Alert deduplication cooldown
    severity: str = "HIGH"


@dataclass
class DosAnomalyDetectorConfig:
    """Configuration for DoS-like Traffic Anomaly Detection module."""
    enabled: bool = True
    packet_rate_threshold: float = 40.0         # Packets/sec from single source
    byte_rate_threshold: float = 50000.0        # Bytes/sec from single source (~400 kbps)
    single_target_rate_threshold: float = 25.0  # Packets/sec directed at one specific host
    window_seconds: float = 10.0                # Rolling window duration
    baseline_zscore_threshold: float = 3.0      # Z-score multiplier above baseline
    cooldown_seconds: float = 60.0              # Alert deduplication cooldown
    severity: str = "HIGH"


@dataclass
class ArpSpoofDetectorConfig:
    """Configuration for ARP Spoofing Detection module."""
    enabled: bool = True
    expected_gateway_ip: Optional[str] = "192.168.1.1"
    expected_gateway_mac: Optional[str] = "00:1A:2B:3C:4D:5E"
    rapid_change_window_seconds: float = 30.0   # Window to track mapping changes
    flap_count_threshold: int = 2               # Flap changes within window to flag repeated conflict
    cooldown_seconds: float = 45.0              # Cooldown duration
    host_severity: str = "HIGH"
    gateway_severity: str = "CRITICAL"


@dataclass
class RogueDhcpDetectorConfig:
    """Configuration for Rogue DHCP Detection module."""
    enabled: bool = True
    approved_dhcp_servers: List[str] = field(
        default_factory=lambda: ["192.168.1.1", "00:1A:2B:3C:4D:5E"]
    )
    allow_no_dhcp: bool = False                 # Set True if lab network uses static addressing only
    cooldown_seconds: float = 60.0              # Alert deduplication cooldown
    severity: str = "HIGH"


@dataclass
class RiskScoringConfig:
    """Configuration for Explainable Multi-Signal Risk Scoring (0 - 100)."""
    # Base category sub-score weights (maximum contribution per category to prevent runaway scores)
    unknown_device_max_score: float = 25.0
    port_scan_max_score: float = 35.0
    dos_anomaly_max_score: float = 30.0
    arp_conflict_max_score: float = 40.0
    gateway_conflict_bonus: float = 20.0
    rogue_dhcp_max_score: float = 45.0
    behavioral_anomaly_max_score: float = 20.0
    
    # Severity classification thresholds (project-defined)
    low_threshold: float = 30.0       # 0 <= score < 30 -> LOW
    medium_threshold: float = 60.0    # 30 <= score < 60 -> MEDIUM
    high_threshold: float = 80.0      # 60 <= score < 80 -> HIGH, >= 80 -> CRITICAL


@dataclass
class DetectionConfig:
    """Configuration for detection engine and individual detector modules."""
    alert_cooldown_seconds: float = 60.0
    unapproved_device_severity: str = "MEDIUM"
    
    # Sub-detector configurations
    port_scan: PortScanDetectorConfig = field(default_factory=PortScanDetectorConfig)
    dos_anomaly: DosAnomalyDetectorConfig = field(default_factory=DosAnomalyDetectorConfig)
    arp_spoof: ArpSpoofDetectorConfig = field(default_factory=ArpSpoofDetectorConfig)
    rogue_dhcp: RogueDhcpDetectorConfig = field(default_factory=RogueDhcpDetectorConfig)
    risk_scoring: RiskScoringConfig = field(default_factory=RiskScoringConfig)


@dataclass
class AppConfig:
    """Master application configuration combining all subsystem settings."""
    sensor: SensorConfig = field(default_factory=SensorConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    inventory: InventoryConfig = field(default_factory=InventoryConfig)
    profiling: ProfilingConfig = field(default_factory=ProfilingConfig)
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    
    # Logging configuration
    log_level: str = "INFO"
    log_file: Optional[Path] = field(
        default_factory=lambda: BASE_DIR / "sensor.log"
    )


def load_config() -> AppConfig:
    """Factory function to load and optionally override configuration from environment."""
    cfg = AppConfig()
    
    # Environment variable overrides
    if os.getenv("SENSOR_SIMULATION_MODE") is not None:
        cfg.sensor.simulation_mode = os.getenv("SENSOR_SIMULATION_MODE", "1").lower() in ("1", "true", "yes")
    
    if os.getenv("SENSOR_INTERFACE"):
        cfg.sensor.interface = os.getenv("SENSOR_INTERFACE")
        
    if os.getenv("DB_PATH"):
        cfg.database.db_file = Path(os.getenv("DB_PATH"))
        
    if os.getenv("LOG_LEVEL"):
        cfg.log_level = os.getenv("LOG_LEVEL").upper()
        
    return cfg
