"""
Dashboard data interface for Rogue Device Detection & Network Behavior Profiling.
Provides a clean, unprivileged read/write query interface over SQLite persistence.
Allows dashboards (e.g. Streamlit, Web UI, CLI) to query inventories, alerts,
traffic metrics, and risk scores without needing elevated or raw socket permissions.
"""

from datetime import datetime, timezone
import json
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Any

from config import load_config, BASE_DIR
from database.db import DatabaseManager

logger = logging.getLogger(__name__)


class DashboardDataInterface:
    """
    Unprivileged data access layer for dashboards, reporting tools, and UI consumers.
    Decoupled from live capture processes; interacts purely with the SQLite database.
    """

    def __init__(self, db_path: Optional[Path] = None):
        cfg = load_config()
        self.db_path = Path(db_path) if db_path else cfg.database.db_file
        self.db = DatabaseManager(self.db_path, cfg.database.schema_file)

    def get_system_overview(self) -> Dict[str, Any]:
        """Fetch high-level posture metrics for summary widgets and KPI cards."""
        devices = self.db.get_all_devices()
        alerts = self.db.get_alerts(limit=1000)
        risk_scores = self.db.get_all_device_risk_scores()

        approved_count = sum(1 for d in devices if d.is_approved)
        unrecognized_count = len(devices) - approved_count

        severity_counts = {"LOW": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0}
        for a in alerts:
            sev = a.severity.upper()
            if sev in severity_counts:
                severity_counts[sev] += 1

        status_counts = {"NEW": 0, "ACKNOWLEDGED": 0, "UNDER_REVIEW": 0, "RESOLVED": 0, "FALSE_POSITIVE": 0}
        for a in alerts:
            st = a.status.upper()
            if st in status_counts:
                status_counts[st] += 1

        max_risk = 0.0
        highest_risk_dev = None
        if risk_scores:
            top = risk_scores[0]
            max_risk = top.get("risk_score", 0.0)
            highest_risk_dev = top.get("device_id")

        db_size_kb = 0.0
        if self.db_path.exists():
            db_size_kb = round(os.path.getsize(self.db_path) / 1024.0, 1)

        return {
            "total_devices": len(devices),
            "approved_devices": approved_count,
            "unrecognized_devices": unrecognized_count,
            "total_alerts": len(alerts),
            "critical_alerts": severity_counts.get("CRITICAL", 0),
            "high_alerts": severity_counts.get("HIGH", 0),
            "new_alerts": status_counts.get("NEW", 0),
            "resolved_alerts": status_counts.get("RESOLVED", 0),
            "max_risk_score": max_risk,
            "highest_risk_device": highest_risk_dev,
            "database_size_kb": db_size_kb,
            "database_path": str(self.db_path),
        }

    def get_devices_table(self) -> List[Dict[str, Any]]:
        """Retrieve flattened device inventory with risk scores for tabular views."""
        devices = self.db.get_all_devices()
        risk_map = {r["device_id"]: r for r in self.db.get_all_device_risk_scores()}

        table = []
        for d in devices:
            risk_info = risk_map.get(d.device_id, {})
            table.append({
                "device_id": d.device_id,
                "mac_address": d.mac_address or "Unknown MAC",
                "current_ip": d.current_ip or "Unknown IP",
                "is_approved": d.is_approved,
                "approval_status": d.approval_status,
                "vendor": d.vendor or "Unknown Vendor",
                "hostname": d.hostname or "N/A",
                "total_packets": d.total_packets,
                "total_bytes": d.total_bytes,
                "risk_score": round(risk_info.get("risk_score", 0.0), 1),
                "risk_severity": risk_info.get("severity", "LOW"),
                "first_seen": d.first_seen.isoformat(),
                "last_seen": d.last_seen.isoformat(),
            })
        return table

    def get_device_detail(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Fetch complete profiling, baseline, IP history, and risk details for a single device."""
        device = self.db.get_device_by_id(device_id)
        if not device:
            return None

        baseline = self.db.get_baseline(device_id)
        risk_record = self.db.get_device_risk_score(device_id)
        all_alerts = self.db.get_alerts(limit=500)

        # Correlate alerts
        device_alerts = [
            a.to_dict() for a in all_alerts
            if (a.source_device_id == device_id or
                (device.mac_address and a.source_mac == device.mac_address) or
                (device.current_ip and a.source_ip == device.current_ip))
        ]

        return {
            "device": device.to_dict(),
            "baseline": baseline.to_dict() if baseline else None,
            "risk_evaluation": risk_record,
            "alerts": device_alerts,
        }

    def get_alerts_table(
        self,
        status_filter: Optional[str] = None,
        severity_filter: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Retrieve security alerts formatted for dashboard tables and filtering."""
        alerts = self.db.get_alerts(
            status_filter=status_filter,
            severity_filter=severity_filter,
            limit=limit,
        )
        return [a.to_dict() for a in alerts]

    def get_alert_detail(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve single alert with structured evidence and audit investigation history."""
        alert = self.db.get_alert(alert_id)
        if not alert:
            return None

        history = self.db.get_alert_history(alert_id)
        return {
            "alert": alert.to_dict(),
            "history": [h.to_dict() for h in history],
        }

    def update_alert_status(
        self,
        alert_id: str,
        new_status: str,
        analyst: str = "Security Analyst",
        notes: Optional[str] = None,
    ) -> bool:
        """Update investigation status and record audit log."""
        return self.db.update_alert_status(
            alert_id=alert_id,
            new_status=new_status,
            analyst=analyst,
            notes=notes,
        )

    def get_traffic_timeseries(
        self,
        device_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """Retrieve aggregated window time-series data points for Plotly throughput charts."""
        with self.db.transaction() as conn:
            if device_id:
                sql = """
                    SELECT device_id, window_start, window_end, packet_count, byte_count,
                           packet_rate, byte_rate, distinct_targets, distinct_ports
                    FROM traffic_aggregates
                    WHERE device_id = ?
                    ORDER BY window_start DESC LIMIT ?;
                """
                rows = conn.execute(sql, (device_id, limit)).fetchall()
            else:
                sql = """
                    SELECT device_id, window_start, window_end, packet_count, byte_count,
                           packet_rate, byte_rate, distinct_targets, distinct_ports
                    FROM traffic_aggregates
                    ORDER BY window_start DESC LIMIT ?;
                """
                rows = conn.execute(sql, (limit,)).fetchall()

            results = []
            for r in rows:
                results.append({
                    "device_id": r["device_id"],
                    "window_start": r["window_start"],
                    "window_end": r["window_end"],
                    "packet_count": r["packet_count"],
                    "byte_count": r["byte_count"],
                    "packet_rate": round(r["packet_rate"], 2),
                    "byte_rate": round(r["byte_rate"], 2),
                    "distinct_targets": r["distinct_targets"],
                    "distinct_ports": r["distinct_ports"],
                })
            # Reverse to chronological order for line charts
            return list(reversed(results))

    def get_protocol_distribution(self) -> Dict[str, int]:
        """Aggregate protocol counts across all stored network events."""
        with self.db.transaction() as conn:
            sql = "SELECT protocol, COUNT(*) as count FROM network_events GROUP BY protocol ORDER BY count DESC;"
            rows = conn.execute(sql).fetchall()
            return {r["protocol"]: r["count"] for r in rows}

    def get_risk_distribution(self) -> Dict[str, int]:
        """Return count of devices grouped by risk severity."""
        scores = self.db.get_all_device_risk_scores()
        dist = {"LOW": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0}
        for s in scores:
            sev = s.get("severity", "LOW").upper()
            if sev in dist:
                dist[sev] += 1
        return dist

    def export_security_report(self) -> Dict[str, Any]:
        """Generate a complete JSON-exportable audit report of the network security posture."""
        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "overview": self.get_system_overview(),
            "protocol_distribution": self.get_protocol_distribution(),
            "risk_distribution": self.get_risk_distribution(),
            "devices": self.get_devices_table(),
            "recent_alerts": self.get_alerts_table(limit=50),
        }
