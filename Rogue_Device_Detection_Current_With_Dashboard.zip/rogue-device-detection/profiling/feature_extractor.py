"""
Feature extractor for network traffic.
Aggregates rolling event windows into per-device statistical features,
including packet/byte rates, target and port counts, protocol ratios, and DNS query counts.
"""

from collections import defaultdict
from datetime import datetime, timezone
import logging
from typing import Dict, List, Optional

from models.events import NetworkEvent
from models.profile import TrafficWindowMetrics
from sensor.device_discovery import normalize_mac

logger = logging.getLogger(__name__)


class FeatureExtractor:
    """Extracts summary metrics from a slice/window of network events."""

    @staticmethod
    def extract_device_metrics(
        device_id: str,
        events: List[NetworkEvent],
        window_start: datetime,
        window_end: datetime,
    ) -> TrafficWindowMetrics:
        """
        Aggregate events originating from a specific device into a TrafficWindowMetrics object.
        """
        duration = max((window_end - window_start).total_seconds(), 0.001)

        packet_count = len(events)
        byte_count = sum(e.packet_size for e in events)
        packet_rate = packet_count / duration
        byte_rate = byte_count / duration

        distinct_targets = len({e.dst_ip for e in events if e.dst_ip and e.dst_ip not in ("255.255.255.255", "0.0.0.0")})
        distinct_ports = len({e.dst_port for e in events if e.dst_port is not None})

        protocol_counts: Dict[str, int] = defaultdict(int)
        syn_count = 0
        ack_count = 0
        connection_attempts = 0
        dns_query_count = 0

        for e in events:
            protocol_counts[e.protocol] += 1
            if e.tcp_flags:
                if "SYN" in e.tcp_flags:
                    syn_count += 1
                    connection_attempts += 1
                if "ACK" in e.tcp_flags:
                    ack_count += 1

            # Count DNS queries (port 53 or DNS event or info tag)
            if e.is_dns or e.dst_port == 53 or (e.info and "DNS Query" in e.info):
                dns_query_count += 1

            # Include UDP probe connection attempts
            if e.protocol == "UDP" and e.dst_port is not None and e.dst_port != 53:
                connection_attempts += 1

        return TrafficWindowMetrics(
            device_id=device_id,
            window_start=window_start,
            window_end=window_end,
            packet_count=packet_count,
            byte_count=byte_count,
            packet_rate=packet_rate,
            byte_rate=byte_rate,
            distinct_targets=distinct_targets,
            distinct_ports=distinct_ports,
            protocol_counts=dict(protocol_counts),
            syn_packet_count=syn_count,
            ack_packet_count=ack_count,
            connection_attempts=connection_attempts,
            dns_query_count=dns_query_count,
        )

    @classmethod
    def extract_all_devices_in_window(
        cls,
        events: List[NetworkEvent],
        window_start: datetime,
        window_end: datetime,
    ) -> List[TrafficWindowMetrics]:
        """
        Partition events by source device and extract metrics for each active device.
        """
        device_events: Dict[str, List[NetworkEvent]] = defaultdict(list)

        for e in events:
            src_mac = normalize_mac(e.src_mac)
            if src_mac and src_mac not in ("FF:FF:FF:FF:FF:FF", "00:00:00:00:00:00"):
                dev_id = f"mac_{src_mac}"
            elif e.src_ip and e.src_ip != "0.0.0.0":
                dev_id = f"ip_{e.src_ip}"
            else:
                continue

            device_events[dev_id].append(e)

        metrics_list = []
        for dev_id, dev_evs in device_events.items():
            metrics = cls.extract_device_metrics(dev_id, dev_evs, window_start, window_end)
            metrics_list.append(metrics)

        return metrics_list
