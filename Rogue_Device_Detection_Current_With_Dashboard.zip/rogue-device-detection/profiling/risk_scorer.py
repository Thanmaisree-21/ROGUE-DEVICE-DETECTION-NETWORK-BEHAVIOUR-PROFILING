"""
Explainable multi-signal risk scoring component.
Computes a normalized risk score (0 to 100) per device by synthesizing unknown-device status,
port scanning, traffic anomalies, ARP conflicts, rogue DHCP, and behavioral baselines.
Dampens correlated signals to prevent runaway double-counting.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import logging
import math
from typing import Dict, List, Optional, Any

from config import RiskScoringConfig
from models.alert import Alert, AlertSeverity
from models.device import Device, DeviceStatus

logger = logging.getLogger(__name__)


class RiskCategory(str, Enum):
    UNKNOWN_DEVICE = "UNKNOWN_DEVICE"
    PORT_SCAN = "PORT_SCAN"
    TRAFFIC_ANOMALY = "TRAFFIC_ANOMALY"
    ARP_CONFLICT = "ARP_CONFLICT"
    ROGUE_DHCP = "ROGUE_DHCP"
    BEHAVIORAL_PROFILE = "BEHAVIORAL_PROFILE"


@dataclass
class RiskSignal:
    """Individual contributing evidence signal to the composite risk score."""
    category: str
    title: str
    weight: float
    score_contribution: float
    evidence: Dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "category": self.category,
            "title": self.title,
            "weight": round(self.weight, 2),
            "score_contribution": round(self.score_contribution, 2),
            "evidence": self.evidence,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class RiskReport:
    """Consolidated, explainable risk assessment report for a device."""
    device_id: str
    overall_score: float          # 0.0 to 100.0
    severity: str                 # LOW, MEDIUM, HIGH, CRITICAL
    category_scores: Dict[str, float]
    signals: List[RiskSignal]
    explanation: str
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "overall_score": round(self.overall_score, 1),
            "severity": self.severity,
            "category_scores": {k: round(v, 1) for k, v in self.category_scores.items()},
            "signals": [s.to_dict() for s in self.signals],
            "explanation": self.explanation,
            "updated_at": self.updated_at.isoformat(),
        }


class RiskScorer:
    """
    Computes explainable, non-redundant device risk scores from 0 to 100.
    Applies diminishing marginal weights to correlated alerts within the same domain.
    """

    def __init__(self, config: Optional[RiskScoringConfig] = None):
        self.config = config or RiskScoringConfig()

    def evaluate_device_risk(
        self,
        device: Device,
        alerts: List[Alert],
        behavioral_anomalies: Optional[List[Dict[str, Any]]] = None,
    ) -> RiskReport:
        """
        Calculate an explainable risk score for a device based on observed signals.
        """
        signals: List[RiskSignal] = []
        cat_scores: Dict[str, float] = {cat.value: 0.0 for cat in RiskCategory}

        # -----------------------------------------------------------------
        # 1. Unknown Device Status
        # -----------------------------------------------------------------
        if not device.is_approved or device.approval_status != DeviceStatus.APPROVED.value:
            unapproved_subscore = self.config.unknown_device_max_score
            cat_scores[RiskCategory.UNKNOWN_DEVICE.value] = unapproved_subscore
            signals.append(RiskSignal(
                category=RiskCategory.UNKNOWN_DEVICE.value,
                title="Unrecognized Device Status",
                weight=self.config.unknown_device_max_score,
                score_contribution=unapproved_subscore,
                evidence={
                    "approval_status": device.approval_status,
                    "first_seen": device.first_seen.isoformat(),
                    "vendor": device.vendor,
                },
            ))

        # -----------------------------------------------------------------
        # 2. Partition Alerts by Category (Dampen Correlated Multiples)
        # -----------------------------------------------------------------
        port_scan_alerts = [a for a in alerts if "PORT_SCAN" in a.detection_type]
        dos_alerts = [a for a in alerts if "TRAFFIC_ANOMALY" in a.detection_type or "DOS" in a.detection_type]
        arp_alerts = [a for a in alerts if "ARP" in a.detection_type]
        dhcp_alerts = [a for a in alerts if "DHCP" in a.detection_type]

        # Port Scan Sub-score
        if port_scan_alerts:
            n = len(port_scan_alerts)
            # Diminishing marginal returns for duplicate scan triggers
            marginal_factor = 1.0 + 0.15 * math.log(max(n, 1))
            raw_score = min(
                self.config.port_scan_max_score,
                self.config.port_scan_max_score * marginal_factor * 0.85
            )
            cat_scores[RiskCategory.PORT_SCAN.value] = raw_score
            signals.append(RiskSignal(
                category=RiskCategory.PORT_SCAN.value,
                title=f"Port Scanning Activity ({n} alert{'s' if n > 1 else ''})",
                weight=self.config.port_scan_max_score,
                score_contribution=raw_score,
                evidence={
                    "alert_count": n,
                    "latest_alert_title": port_scan_alerts[-1].title,
                    "probed_ports_sample": port_scan_alerts[-1].evidence.get("probed_ports_sample", []),
                },
            ))

        # DoS / Traffic Flood Sub-score
        if dos_alerts:
            n = len(dos_alerts)
            raw_score = min(
                self.config.dos_anomaly_max_score,
                self.config.dos_anomaly_max_score * (1.0 + 0.1 * math.log(max(n, 1))) * 0.9
            )
            cat_scores[RiskCategory.TRAFFIC_ANOMALY.value] = raw_score
            signals.append(RiskSignal(
                category=RiskCategory.TRAFFIC_ANOMALY.value,
                title=f"Traffic Rate / Flood Anomaly ({n} alert{'s' if n > 1 else ''})",
                weight=self.config.dos_anomaly_max_score,
                score_contribution=raw_score,
                evidence={
                    "alert_count": n,
                    "latest_alert_title": dos_alerts[-1].title,
                    "observed_packet_rate": dos_alerts[-1].evidence.get("observed_packet_rate"),
                },
            ))

        # ARP Spoof / Conflict Sub-score
        if arp_alerts:
            has_gateway_spoof = any("GATEWAY" in a.detection_type for a in arp_alerts)
            base_arp_score = self.config.arp_conflict_max_score
            if has_gateway_spoof:
                base_arp_score = min(
                    100.0,
                    self.config.arp_conflict_max_score + self.config.gateway_conflict_bonus
                )
            cat_scores[RiskCategory.ARP_CONFLICT.value] = base_arp_score
            signals.append(RiskSignal(
                category=RiskCategory.ARP_CONFLICT.value,
                title="ARP Mapping Conflict / Gateway Hijack",
                weight=base_arp_score,
                score_contribution=base_arp_score,
                evidence={
                    "has_gateway_spoof": has_gateway_spoof,
                    "alert_count": len(arp_alerts),
                    "latest_evidence": arp_alerts[-1].evidence,
                },
            ))

        # Rogue DHCP Sub-score
        if dhcp_alerts:
            raw_score = self.config.rogue_dhcp_max_score
            cat_scores[RiskCategory.ROGUE_DHCP.value] = raw_score
            signals.append(RiskSignal(
                category=RiskCategory.ROGUE_DHCP.value,
                title="Rogue DHCP Server Offers",
                weight=self.config.rogue_dhcp_max_score,
                score_contribution=raw_score,
                evidence={
                    "alert_count": len(dhcp_alerts),
                    "server_details": dhcp_alerts[-1].evidence,
                },
            ))

        # -----------------------------------------------------------------
        # 3. Behavioral Profile & Isolation Forest Anomalies
        # -----------------------------------------------------------------
        if behavioral_anomalies:
            n_anom = len(behavioral_anomalies)
            anom_subscore = min(
                self.config.behavioral_anomaly_max_score,
                8.0 * n_anom
            )
            cat_scores[RiskCategory.BEHAVIORAL_PROFILE.value] = anom_subscore
            signals.append(RiskSignal(
                category=RiskCategory.BEHAVIORAL_PROFILE.value,
                title=f"Behavioral Profile / Outlier Anomaly ({n_anom} event{'s' if n_anom > 1 else ''})",
                weight=self.config.behavioral_anomaly_max_score,
                score_contribution=anom_subscore,
                evidence={"anomalies": behavioral_anomalies},
            ))

        # -----------------------------------------------------------------
        # 4. Composite Score Synthesis (Avoid Double Counting)
        # -----------------------------------------------------------------
        total_score = sum(cat_scores.values())
        clamped_score = min(100.0, max(0.0, total_score))

        # Map to severity thresholds
        if clamped_score < self.config.low_threshold:
            severity = AlertSeverity.LOW.value
        elif clamped_score < self.config.medium_threshold:
            severity = AlertSeverity.MEDIUM.value
        elif clamped_score < self.config.high_threshold:
            severity = AlertSeverity.HIGH.value
        else:
            severity = AlertSeverity.CRITICAL.value

        # Generate human-readable explanation
        explanation_lines = [
            f"Device {device.device_id} assigned risk score {clamped_score:.1f}/100 (Severity: {severity})."
        ]
        if signals:
            explanation_lines.append("Contributing risk signals:")
            for s in signals:
                explanation_lines.append(f" - [{s.category}] {s.title}: +{s.score_contribution:.1f} pts")
        else:
            explanation_lines.append("No suspicious indicators or inventory anomalies observed.")

        explanation = "\n".join(explanation_lines)

        return RiskReport(
            device_id=device.device_id,
            overall_score=clamped_score,
            severity=severity,
            category_scores=cat_scores,
            signals=signals,
            explanation=explanation,
        )
