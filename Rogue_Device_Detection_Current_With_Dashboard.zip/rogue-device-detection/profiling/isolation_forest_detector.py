"""
Optional Machine Learning behavioral anomaly detector using Isolation Forest (scikit-learn).
Completely decoupled from rule-based detectors.
Evaluates multivariate feature distributions and flags statistical outliers without claiming confirmed attacks.
"""

from collections import defaultdict, deque
import logging
from typing import Dict, List, Optional, Any
import numpy as np

try:
    from sklearn.ensemble import IsolationForest
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

from models.profile import TrafficWindowMetrics

logger = logging.getLogger(__name__)


class IsolationForestAnomalyDetector:
    """
    Independent unsupervised ML detector for multivariate traffic profiling anomalies.
    Detects complex outliers across rates, ports, targets, flags, and DNS counts simultaneously.
    """

    def __init__(
        self,
        enabled: bool = True,
        contamination: float = 0.05,
        min_samples: int = 6,
        random_state: int = 42,
    ):
        self.enabled = enabled and SKLEARN_AVAILABLE
        self.contamination = contamination
        self.min_samples = min_samples
        self.random_state = random_state

        if not SKLEARN_AVAILABLE and enabled:
            logger.warning("scikit-learn is not installed; Isolation Forest detector is disabled.")

        # Historical feature vectors per device: device_id -> deque of List[float]
        self._feature_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=60))

    def evaluate_window(self, metrics: TrafficWindowMetrics) -> List[Dict[str, Any]]:
        """
        Evaluate a single TrafficWindowMetrics instance against historical feature distribution.
        Returns list of anomaly dictionaries if flagged as an Isolation Forest outlier.
        """
        if not self.enabled:
            return []

        dev_id = metrics.device_id
        vec = metrics.to_feature_vector()
        history = self._feature_history[dev_id]

        # Ensure we have sufficient training data before modeling
        if len(history) < self.min_samples:
            history.append(vec)
            return []

        anomalies = []
        try:
            X_train = np.array(list(history))
            X_test = np.array([vec])

            # Check if training variance exists across features
            if np.all(np.std(X_train, axis=0) < 1e-4):
                # If training data is identical, simple Euclidean distance check
                diff = np.linalg.norm(vec - np.mean(X_train, axis=0))
                if diff > 15.0:
                    anomalies.append(self._build_anomaly_dict(metrics, anomaly_score=-0.5, raw_vector=vec))
                history.append(vec)
                return anomalies

            # Fit Isolation Forest on baseline history
            model = IsolationForest(
                contamination=self.contamination,
                random_state=self.random_state,
                n_estimators=50,
            )
            model.fit(X_train)

            pred = model.predict(X_test)[0]          # -1 for anomaly, 1 for normal
            score = float(model.decision_function(X_test)[0])  # Lower is more abnormal

            if pred == -1 or score < -0.05:
                anomalies.append(self._build_anomaly_dict(metrics, anomaly_score=score, raw_vector=vec))

        except Exception as e:
            logger.debug("Isolation Forest evaluation error for %s: %s", dev_id, e)

        # Append observation to history after scoring
        history.append(vec)
        return anomalies

    def _build_anomaly_dict(
        self,
        metrics: TrafficWindowMetrics,
        anomaly_score: float,
        raw_vector: List[float],
    ) -> Dict[str, Any]:
        """Construct structured explainable anomaly record."""
        return {
            "type": "ISOLATION_FOREST_OUTLIER",
            "reason": (
                f"Multivariate traffic profile diverges significantly from historical clustering "
                f"(Anomaly Score: {anomaly_score:.3f} < threshold). "
                f"Observed: {metrics.packet_rate:.1f} pkts/s, {metrics.distinct_ports} ports, "
                f"{metrics.distinct_targets} targets, {metrics.dns_query_count} DNS queries. "
                f"Note: This is an unsupervised statistical anomaly; not a confirmed attack."
            ),
            "severity": "MEDIUM",
            "anomaly_score": round(anomaly_score, 3),
            "metrics": {
                "packet_rate": round(metrics.packet_rate, 2),
                "byte_rate": round(metrics.byte_rate, 2),
                "distinct_targets": metrics.distinct_targets,
                "distinct_ports": metrics.distinct_ports,
                "syn_packet_count": metrics.syn_packet_count,
                "dns_query_count": metrics.dns_query_count,
            },
        }

    def reset(self, device_id: Optional[str] = None) -> None:
        """Reset historical feature vectors."""
        if device_id:
            self._feature_history.pop(device_id, None)
        else:
            self._feature_history.clear()
