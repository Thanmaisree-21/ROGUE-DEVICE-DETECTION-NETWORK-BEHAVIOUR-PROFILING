"""
Behavior profiler module.
Maintains device behavioral baselines, evaluates rolling traffic metrics for anomalies,
and coordinates optional machine-learning outlier evaluation via Isolation Forest.
"""

from collections import deque, defaultdict
from datetime import datetime, timezone
import logging
import math
from typing import Dict, List, Optional, Deque, Any

from config import ProfilingConfig
from database.db import DatabaseManager
from models.profile import TrafficWindowMetrics, DeviceBaseline
from profiling.isolation_forest_detector import IsolationForestAnomalyDetector

logger = logging.getLogger(__name__)


class BehaviorProfiler:
    """
    Maintains rolling traffic baselines and computes deviation anomalies.
    Integrates statistical Z-score checks and optional Isolation Forest detection.
    """

    def __init__(self, db: DatabaseManager, config: Optional[ProfilingConfig] = None):
        self.db = db
        self.config = config or ProfilingConfig()
        # In-memory history of metrics windows per device: device_id -> deque of TrafficWindowMetrics
        self._history: Dict[str, Deque[TrafficWindowMetrics]] = defaultdict(lambda: deque(maxlen=50))
        # Cached baselines: device_id -> DeviceBaseline
        self._baselines: Dict[str, DeviceBaseline] = {}

        # Optional ML outlier detector
        self.isolation_forest = IsolationForestAnomalyDetector(
            enabled=self.config.enable_isolation_forest,
            contamination=self.config.isolation_forest_contamination,
            min_samples=self.config.isolation_forest_min_samples,
        )

    def process_window(self, metrics: TrafficWindowMetrics) -> List[Dict[str, Any]]:
        """
        Record a new window metric, update baseline, and check for behavioral anomalies.
        Returns a list of anomaly descriptor dictionaries (if any).
        """
        device_id = metrics.device_id

        # 1. Evaluate against existing historical baseline prior to absorbing the new window
        existing_baseline = self.get_baseline(device_id)
        anomalies: List[Dict[str, Any]] = []
        if existing_baseline:
            anomalies = self._detect_anomalies(metrics, existing_baseline)

        # 2. Evaluate with optional Isolation Forest detector
        if self.isolation_forest.enabled:
            ml_anomalies = self.isolation_forest.evaluate_window(metrics)
            anomalies.extend(ml_anomalies)

        # 3. Record window in history and database
        self._history[device_id].append(metrics)
        self.db.insert_traffic_aggregate(metrics)

        # 4. Update statistical baseline with new data point
        self._update_baseline(device_id)

        return anomalies

    def _update_baseline(self, device_id: str) -> DeviceBaseline:
        """Recalculate baseline statistics based on recorded history."""
        windows = list(self._history[device_id])
        sample_count = len(windows)

        if sample_count == 0:
            return DeviceBaseline(device_id=device_id)

        packet_rates = [w.packet_rate for w in windows]
        byte_rates = [w.byte_rate for w in windows]
        dns_queries = [w.dns_query_count for w in windows]

        mean_pkt = sum(packet_rates) / sample_count
        var_pkt = sum((r - mean_pkt) ** 2 for r in packet_rates) / sample_count
        std_pkt = math.sqrt(var_pkt)

        mean_byte = sum(byte_rates) / sample_count
        var_byte = sum((b - mean_byte) ** 2 for b in byte_rates) / sample_count
        std_byte = math.sqrt(var_byte)

        mean_dns = sum(dns_queries) / sample_count

        # Aggregate protocol distribution
        proto_totals: Dict[str, int] = defaultdict(int)
        all_ports = set()
        total_packets = 0

        for w in windows:
            for proto, count in w.protocol_counts.items():
                proto_totals[proto] += count
                total_packets += count

        proto_ratios = {}
        if total_packets > 0:
            for proto, count in proto_totals.items():
                proto_ratios[proto] = round(count / total_packets, 4)

        existing = self.db.get_baseline(device_id)
        now_ts = datetime.now(timezone.utc)
        created_at = existing.created_at if existing else now_ts

        baseline = DeviceBaseline(
            device_id=device_id,
            created_at=created_at,
            updated_at=now_ts,
            sample_windows=sample_count,
            mean_packet_rate=mean_pkt,
            std_packet_rate=std_pkt,
            mean_byte_rate=mean_byte,
            std_byte_rate=std_byte,
            expected_protocols=proto_ratios,
            known_ports=list(all_ports),
            mean_dns_queries=mean_dns,
        )

        self._baselines[device_id] = baseline
        self.db.upsert_baseline(baseline)
        return baseline

    def _detect_anomalies(
        self,
        metrics: TrafficWindowMetrics,
        baseline: DeviceBaseline,
    ) -> List[Dict[str, Any]]:
        """Evaluate traffic metrics against baseline thresholds."""
        anomalies = []

        # 1. Port scan anomaly (high unique destination ports probed)
        if metrics.distinct_ports >= self.config.port_scan_unique_ports_threshold:
            anomalies.append({
                "type": "PORT_SCAN_SUSPECT",
                "reason": (
                    f"Device probed {metrics.distinct_ports} distinct destination ports within a "
                    f"single {round((metrics.window_end - metrics.window_start).total_seconds())}s window "
                    f"(Threshold: {self.config.port_scan_unique_ports_threshold})."
                ),
                "severity": "HIGH",
                "metrics": {
                    "distinct_ports": metrics.distinct_ports,
                    "packet_count": metrics.packet_count,
                    "syn_packets": metrics.syn_packet_count,
                },
            })

        # 2. Host sweep anomaly (high unique destination IPs contacted)
        if metrics.distinct_targets >= self.config.host_scan_unique_targets_threshold:
            anomalies.append({
                "type": "HOST_SWEEP_SUSPECT",
                "reason": (
                    f"Device contacted {metrics.distinct_targets} distinct destination hosts within "
                    f"a single window (Threshold: {self.config.host_scan_unique_targets_threshold})."
                ),
                "severity": "HIGH",
                "metrics": {
                    "distinct_targets": metrics.distinct_targets,
                    "packet_count": metrics.packet_count,
                },
            })

        # 3. Traffic volume spike anomaly (statistical Z-score check)
        if baseline.sample_windows >= self.config.min_samples_for_baseline and baseline.std_packet_rate > 0.1:
            z_score = (metrics.packet_rate - baseline.mean_packet_rate) / baseline.std_packet_rate
            if z_score > self.config.zscore_threshold:
                anomalies.append({
                    "type": "TRAFFIC_VOLUME_SPIKE",
                    "reason": (
                        f"Abnormal packet rate: {metrics.packet_rate:.2f} pkts/s "
                        f"(Baseline Mean: {baseline.mean_packet_rate:.2f}, StdDev: {baseline.std_packet_rate:.2f}, "
                        f"Z-score: {z_score:.2f} > Threshold {self.config.zscore_threshold})."
                    ),
                    "severity": "MEDIUM",
                    "metrics": {
                        "packet_rate": metrics.packet_rate,
                        "mean_packet_rate": baseline.mean_packet_rate,
                        "z_score": round(z_score, 2),
                    },
                })

        return anomalies

    def get_baseline(self, device_id: str) -> Optional[DeviceBaseline]:
        """Retrieve the in-memory or database baseline for a device."""
        if device_id in self._baselines:
            return self._baselines[device_id]
        b = self.db.get_baseline(device_id)
        if b:
            self._baselines[device_id] = b
        return b
