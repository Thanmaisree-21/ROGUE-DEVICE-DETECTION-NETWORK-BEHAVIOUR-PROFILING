"""Database package for Rogue Device Detection."""

from .db import DatabaseManager

__all__ = ["DatabaseManager"]
