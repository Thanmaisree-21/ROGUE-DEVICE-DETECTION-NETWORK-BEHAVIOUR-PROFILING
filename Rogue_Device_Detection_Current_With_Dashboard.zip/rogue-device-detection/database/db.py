"""
Database access layer for Rogue Device Detection.
Provides thread-safe persistence using SQLite for devices, events, baselines, and alerts.
"""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import sqlite3
from typing import List, Optional, Dict, Any, Generator

from models.device import Device, DeviceIPObservation, ApprovedAsset, DeviceStatus
from models.events import NetworkEvent
from models.alert import Alert, AlertHistory, AlertStatus
from models.profile import TrafficWindowMetrics, DeviceBaseline

logger = logging.getLogger(__name__)


def _parse_ts(ts_val: Any) -> datetime:
    """Helper to parse timestamps from SQLite records into timezone-aware datetimes."""
    if isinstance(ts_val, datetime):
        return ts_val if ts_val.tzinfo else ts_val.replace(tzinfo=timezone.utc)
    if isinstance(ts_val, str):
        if ts_val.endswith("Z"):
            ts_val = ts_val[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(ts_val)
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


class DatabaseManager:
    """Manages SQLite database connections, schema execution, and data operations."""

    def __init__(
        self,
        db_path: Path,
        schema_path: Optional[Path] = None,
        enable_wal: bool = True
    ):
        self.db_path = Path(db_path)
        self.schema_path = Path(schema_path) if schema_path else (Path(__file__).parent / "schema.sql")
        self.enable_wal = enable_wal
        self._ensure_parent_dir()

    def _ensure_parent_dir(self) -> None:
        """Create parent directory for the database if it doesn't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def get_connection(self) -> sqlite3.Connection:
        """Create a new SQLite connection configured with row factory and pragmas."""
        conn = sqlite3.connect(
            str(self.db_path),
            check_same_thread=False,
            timeout=10.0
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        if self.enable_wal:
            try:
                conn.execute("PRAGMA journal_mode = WAL;")
            except sqlite3.OperationalError:
                pass
        return conn

    @contextmanager
    def transaction(self) -> Generator[sqlite3.Connection, None, None]:
        """Context manager providing an atomic transaction block."""
        conn = self.get_connection()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init_db(self) -> None:
        """Initialize database tables and indexes from schema.sql."""
        if not self.schema_path.exists():
            raise FileNotFoundError(f"Schema file not found at {self.schema_path}")

        schema_sql = self.schema_path.read_text(encoding="utf-8")
        with self.transaction() as conn:
            conn.executescript(schema_sql)
        logger.info("Initialized database at %s", self.db_path)

    # -------------------------------------------------------------------------
    # Approved Assets
    # -------------------------------------------------------------------------
    def add_approved_asset(self, asset: ApprovedAsset) -> None:
        """Add or update an approved asset."""
        norm_mac = asset.mac_address.upper()
        sql = """
            INSERT INTO approved_assets (mac_address, assigned_ip, device_name, device_type, owner, added_at, description)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(mac_address) DO UPDATE SET
                assigned_ip = excluded.assigned_ip,
                device_name = excluded.device_name,
                device_type = excluded.device_type,
                owner = excluded.owner,
                description = excluded.description;
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                norm_mac,
                asset.assigned_ip,
                asset.device_name,
                asset.device_type,
                asset.owner,
                asset.added_at.isoformat(),
                asset.description,
            ))

    def get_approved_asset(self, mac_address: str) -> Optional[ApprovedAsset]:
        """Look up an approved asset by MAC address."""
        if not mac_address:
            return None
        norm_mac = mac_address.upper()
        sql = "SELECT * FROM approved_assets WHERE mac_address = ?;"
        with self.transaction() as conn:
            row = conn.execute(sql, (norm_mac,)).fetchone()
            if not row:
                return None
            return ApprovedAsset(
                mac_address=row["mac_address"],
                assigned_ip=row["assigned_ip"],
                device_name=row["device_name"],
                device_type=row["device_type"],
                owner=row["owner"],
                added_at=_parse_ts(row["added_at"]),
                description=row["description"],
            )

    def get_all_approved_assets(self) -> List[ApprovedAsset]:
        """Retrieve all registered approved assets."""
        sql = "SELECT * FROM approved_assets ORDER BY device_name ASC;"
        with self.transaction() as conn:
            rows = conn.execute(sql).fetchall()
            return [
                ApprovedAsset(
                    mac_address=r["mac_address"],
                    assigned_ip=r["assigned_ip"],
                    device_name=r["device_name"],
                    device_type=r["device_type"],
                    owner=r["owner"],
                    added_at=_parse_ts(r["added_at"]),
                    description=r["description"],
                )
                for r in rows
            ]

    def import_approved_assets_from_json(self, json_path: Path) -> int:
        """Import approved assets from a JSON file. Returns count of assets imported."""
        p = Path(json_path)
        if not p.exists():
            logger.warning("Approved devices file does not exist: %s", p)
            return 0
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)

        count = 0
        for item in data:
            asset = ApprovedAsset.from_dict(item)
            self.add_approved_asset(asset)
            count += 1
        logger.info("Imported %d approved assets from %s", count, p)
        return count

    # -------------------------------------------------------------------------
    # Devices Inventory
    # -------------------------------------------------------------------------
    def upsert_device(self, device: Device) -> None:
        """Insert or update observed device metadata."""
        sql = """
            INSERT INTO devices (
                device_id, mac_address, current_ip, first_seen, last_seen,
                is_approved, approval_status, vendor, hostname, total_packets, total_bytes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(device_id) DO UPDATE SET
                mac_address = coalesce(excluded.mac_address, devices.mac_address),
                current_ip = coalesce(excluded.current_ip, devices.current_ip),
                last_seen = excluded.last_seen,
                is_approved = excluded.is_approved,
                approval_status = excluded.approval_status,
                vendor = coalesce(excluded.vendor, devices.vendor),
                hostname = coalesce(excluded.hostname, devices.hostname),
                total_packets = devices.total_packets + excluded.total_packets,
                total_bytes = devices.total_bytes + excluded.total_bytes;
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                device.device_id,
                device.mac_address.upper() if device.mac_address else None,
                device.current_ip,
                device.first_seen.isoformat(),
                device.last_seen.isoformat(),
                1 if device.is_approved else 0,
                device.approval_status,
                device.vendor,
                device.hostname,
                device.total_packets,
                device.total_bytes,
            ))

    def get_device_by_id(self, device_id: str) -> Optional[Device]:
        """Look up device by device_id."""
        sql = "SELECT * FROM devices WHERE device_id = ?;"
        with self.transaction() as conn:
            row = conn.execute(sql, (device_id,)).fetchone()
            if not row:
                return None
            return self._row_to_device(conn, row)

    def get_device_by_mac(self, mac_address: str) -> Optional[Device]:
        """Look up device by MAC address."""
        if not mac_address:
            return None
        sql = "SELECT * FROM devices WHERE mac_address = ?;"
        with self.transaction() as conn:
            row = conn.execute(sql, (mac_address.upper(),)).fetchone()
            if not row:
                return None
            return self._row_to_device(conn, row)

    def get_device_by_ip(self, ip_address: str) -> Optional[Device]:
        """Look up currently active device associated with IP address."""
        if not ip_address:
            return None
        sql = "SELECT * FROM devices WHERE current_ip = ? ORDER BY last_seen DESC LIMIT 1;"
        with self.transaction() as conn:
            row = conn.execute(sql, (ip_address,)).fetchone()
            if not row:
                return None
            return self._row_to_device(conn, row)

    def get_all_devices(self, status_filter: Optional[str] = None) -> List[Device]:
        """Retrieve all observed devices with optional status filter."""
        with self.transaction() as conn:
            if status_filter:
                sql = "SELECT * FROM devices WHERE approval_status = ? ORDER BY last_seen DESC;"
                rows = conn.execute(sql, (status_filter,)).fetchall()
            else:
                sql = "SELECT * FROM devices ORDER BY last_seen DESC;"
                rows = conn.execute(sql).fetchall()
            return [self._row_to_device(conn, r) for r in rows]

    def _row_to_device(self, conn: sqlite3.Connection, row: sqlite3.Row) -> Device:
        """Map SQLite row to Device object, including IP history."""
        device_id = row["device_id"]
        hist_rows = conn.execute(
            "SELECT DISTINCT ip_address FROM device_ip_history WHERE device_id = ? ORDER BY observed_at DESC;",
            (device_id,)
        ).fetchall()
        ip_history = [hr["ip_address"] for hr in hist_rows]

        return Device(
            device_id=device_id,
            mac_address=row["mac_address"],
            current_ip=row["current_ip"],
            first_seen=_parse_ts(row["first_seen"]),
            last_seen=_parse_ts(row["last_seen"]),
            is_approved=bool(row["is_approved"]),
            approval_status=row["approval_status"],
            vendor=row["vendor"],
            hostname=row["hostname"],
            total_packets=row["total_packets"],
            total_bytes=row["total_bytes"],
            ip_history=ip_history,
        )

    # -------------------------------------------------------------------------
    # Device IP History
    # -------------------------------------------------------------------------
    def record_ip_observation(self, observation: DeviceIPObservation) -> None:
        """Record an IP address observation associated with a device."""
        sql = """
            INSERT INTO device_ip_history (device_id, ip_address, observed_at, source)
            VALUES (?, ?, ?, ?);
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                observation.device_id,
                observation.ip_address,
                observation.observed_at.isoformat(),
                observation.source,
            ))

    def get_devices_sharing_ip(self, ip_address: str, since: Optional[datetime] = None) -> List[str]:
        """Find distinct device IDs observed on a given IP (useful for detecting ARP spoofing/conflicts)."""
        with self.transaction() as conn:
            if since:
                sql = """
                    SELECT DISTINCT device_id FROM device_ip_history
                    WHERE ip_address = ? AND observed_at >= ?;
                """
                rows = conn.execute(sql, (ip_address, since.isoformat())).fetchall()
            else:
                sql = "SELECT DISTINCT device_id FROM device_ip_history WHERE ip_address = ?;"
                rows = conn.execute(sql, (ip_address,)).fetchall()
            return [r["device_id"] for r in rows]

    # -------------------------------------------------------------------------
    # Network Events
    # -------------------------------------------------------------------------
    def insert_event(self, event: NetworkEvent) -> int:
        """Insert a single network event metadata row."""
        sql = """
            INSERT INTO network_events (
                timestamp, src_mac, dst_mac, src_ip, dst_ip, protocol,
                src_port, dst_port, packet_size, tcp_flags, info
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """
        with self.transaction() as conn:
            cur = conn.execute(sql, (
                event.timestamp.isoformat(),
                event.src_mac.upper() if event.src_mac else None,
                event.dst_mac.upper() if event.dst_mac else None,
                event.src_ip,
                event.dst_ip,
                event.protocol,
                event.src_port,
                event.dst_port,
                event.packet_size,
                event.tcp_flags,
                event.info,
            ))
            return cur.lastrowid

    def insert_events_batch(self, events: List[NetworkEvent]) -> int:
        """Insert a batch of network events efficiently."""
        if not events:
            return 0
        sql = """
            INSERT INTO network_events (
                timestamp, src_mac, dst_mac, src_ip, dst_ip, protocol,
                src_port, dst_port, packet_size, tcp_flags, info
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """
        rows = [
            (
                e.timestamp.isoformat(),
                e.src_mac.upper() if e.src_mac else None,
                e.dst_mac.upper() if e.dst_mac else None,
                e.src_ip,
                e.dst_ip,
                e.protocol,
                e.src_port,
                e.dst_port,
                e.packet_size,
                e.tcp_flags,
                e.info,
            )
            for e in events
        ]
        with self.transaction() as conn:
            conn.executemany(sql, rows)
        return len(events)

    def get_recent_events(self, limit: int = 100) -> List[NetworkEvent]:
        """Fetch the most recent network events."""
        sql = "SELECT * FROM network_events ORDER BY timestamp DESC LIMIT ?;"
        with self.transaction() as conn:
            rows = conn.execute(sql, (limit,)).fetchall()
            return [
                NetworkEvent(
                    timestamp=_parse_ts(r["timestamp"]),
                    src_mac=r["src_mac"],
                    dst_mac=r["dst_mac"],
                    src_ip=r["src_ip"],
                    dst_ip=r["dst_ip"],
                    protocol=r["protocol"],
                    src_port=r["src_port"],
                    dst_port=r["dst_port"],
                    packet_size=r["packet_size"],
                    tcp_flags=r["tcp_flags"],
                    info=r["info"],
                )
                for r in rows
            ]

    # -------------------------------------------------------------------------
    # Traffic Aggregates & Baselines
    # -------------------------------------------------------------------------
    def insert_traffic_aggregate(self, metric: TrafficWindowMetrics) -> None:
        """Store window-level aggregated metrics."""
        sql = """
            INSERT INTO traffic_aggregates (
                device_id, window_start, window_end, packet_count, byte_count,
                packet_rate, byte_rate, distinct_targets, distinct_ports,
                protocol_counts_json, syn_packet_count, ack_packet_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                metric.device_id,
                metric.window_start.isoformat(),
                metric.window_end.isoformat(),
                metric.packet_count,
                metric.byte_count,
                metric.packet_rate,
                metric.byte_rate,
                metric.distinct_targets,
                metric.distinct_ports,
                json.dumps(metric.protocol_counts),
                metric.syn_packet_count,
                metric.ack_packet_count,
            ))

    def upsert_baseline(self, baseline: DeviceBaseline) -> None:
        """Store or update behavioral baseline for a device."""
        sql = """
            INSERT INTO device_baselines (
                device_id, created_at, updated_at, sample_windows,
                mean_packet_rate, std_packet_rate, mean_byte_rate, std_byte_rate,
                expected_protocols_json, known_ports_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(device_id) DO UPDATE SET
                updated_at = excluded.updated_at,
                sample_windows = excluded.sample_windows,
                mean_packet_rate = excluded.mean_packet_rate,
                std_packet_rate = excluded.std_packet_rate,
                mean_byte_rate = excluded.mean_byte_rate,
                std_byte_rate = excluded.std_byte_rate,
                expected_protocols_json = excluded.expected_protocols_json,
                known_ports_json = excluded.known_ports_json;
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                baseline.device_id,
                baseline.created_at.isoformat(),
                baseline.updated_at.isoformat(),
                baseline.sample_windows,
                baseline.mean_packet_rate,
                baseline.std_packet_rate,
                baseline.mean_byte_rate,
                baseline.std_byte_rate,
                json.dumps(baseline.expected_protocols),
                json.dumps(baseline.known_ports),
            ))

    def get_baseline(self, device_id: str) -> Optional[DeviceBaseline]:
        """Fetch baseline profile for a device."""
        sql = "SELECT * FROM device_baselines WHERE device_id = ?;"
        with self.transaction() as conn:
            row = conn.execute(sql, (device_id,)).fetchone()
            if not row:
                return None
            return DeviceBaseline(
                device_id=row["device_id"],
                created_at=_parse_ts(row["created_at"]),
                updated_at=_parse_ts(row["updated_at"]),
                sample_windows=row["sample_windows"],
                mean_packet_rate=row["mean_packet_rate"],
                std_packet_rate=row["std_packet_rate"],
                mean_byte_rate=row["mean_byte_rate"],
                std_byte_rate=row["std_byte_rate"],
                expected_protocols=json.loads(row["expected_protocols_json"] or "{}"),
                known_ports=json.loads(row["known_ports_json"] or "[]"),
            )

    # -------------------------------------------------------------------------
    # Security Alerts & Investigation Audit Trail
    # -------------------------------------------------------------------------
    def insert_alert(self, alert: Alert) -> str:
        """Insert a security alert and create an initial history record."""
        sql = """
            INSERT INTO alerts (
                alert_id, timestamp, detection_type, severity, source_device_id,
                source_mac, source_ip, target_ip, target_port, title, description,
                evidence_json, status, resolution_notes, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                alert.alert_id,
                alert.timestamp.isoformat(),
                alert.detection_type,
                alert.severity,
                alert.source_device_id,
                alert.source_mac.upper() if alert.source_mac else None,
                alert.source_ip,
                alert.target_ip,
                alert.target_port,
                alert.title,
                alert.description,
                json.dumps(alert.evidence),
                alert.status,
                alert.resolution_notes,
                alert.updated_at.isoformat(),
            ))
            # Initial history record
            conn.execute(
                """
                INSERT INTO alert_history (alert_id, changed_at, previous_status, new_status, changed_by, comment)
                VALUES (?, ?, ?, ?, ?, ?);
                """,
                (
                    alert.alert_id,
                    alert.timestamp.isoformat(),
                    "NONE",
                    alert.status,
                    "Detection Engine",
                    "Alert generated by detection rule",
                )
            )
        return alert.alert_id

    def get_alert(self, alert_id: str) -> Optional[Alert]:
        """Fetch alert by alert ID."""
        sql = "SELECT * FROM alerts WHERE alert_id = ?;"
        with self.transaction() as conn:
            row = conn.execute(sql, (alert_id,)).fetchone()
            if not row:
                return None
            return self._row_to_alert(row)

    def get_alerts(
        self,
        status_filter: Optional[str] = None,
        severity_filter: Optional[str] = None,
        limit: int = 100
    ) -> List[Alert]:
        """Retrieve alerts with optional filters."""
        query_parts = ["SELECT * FROM alerts WHERE 1=1"]
        params: List[Any] = []
        if status_filter:
            query_parts.append("AND status = ?")
            params.append(status_filter)
        if severity_filter:
            query_parts.append("AND severity = ?")
            params.append(severity_filter)
        query_parts.append("ORDER BY timestamp DESC LIMIT ?")
        params.append(limit)

        sql = " ".join(query_parts)
        with self.transaction() as conn:
            rows = conn.execute(sql, tuple(params)).fetchall()
            return [self._row_to_alert(r) for r in rows]

    def update_alert_status(
        self,
        alert_id: str,
        new_status: str,
        analyst: str = "Security Analyst",
        notes: Optional[str] = None
    ) -> bool:
        """Update the investigation status of an alert and log an audit trail entry."""
        with self.transaction() as conn:
            row = conn.execute("SELECT status FROM alerts WHERE alert_id = ?;", (alert_id,)).fetchone()
            if not row:
                return False
            prev_status = row["status"]
            now_ts = datetime.now(timezone.utc).isoformat()

            conn.execute(
                """
                UPDATE alerts
                SET status = ?, resolution_notes = coalesce(?, resolution_notes), updated_at = ?
                WHERE alert_id = ?;
                """,
                (new_status, notes, now_ts, alert_id)
            )

            conn.execute(
                """
                INSERT INTO alert_history (alert_id, changed_at, previous_status, new_status, changed_by, comment)
                VALUES (?, ?, ?, ?, ?, ?);
                """,
                (alert_id, now_ts, prev_status, new_status, analyst, notes)
            )
            return True

    def get_alert_history(self, alert_id: str) -> List[AlertHistory]:
        """Fetch investigation audit trail for an alert."""
        sql = "SELECT * FROM alert_history WHERE alert_id = ? ORDER BY changed_at ASC;"
        with self.transaction() as conn:
            rows = conn.execute(sql, (alert_id,)).fetchall()
            return [
                AlertHistory(
                    alert_id=r["alert_id"],
                    changed_at=_parse_ts(r["changed_at"]),
                    previous_status=r["previous_status"],
                    new_status=r["new_status"],
                    changed_by=r["changed_by"],
                    comment=r["comment"],
                )
                for r in rows
            ]

    def _row_to_alert(self, row: sqlite3.Row) -> Alert:
        """Map SQLite row to Alert object."""
        evidence = {}
        if row["evidence_json"]:
            try:
                evidence = json.loads(row["evidence_json"])
            except Exception:
                evidence = {}
        return Alert(
            alert_id=row["alert_id"],
            timestamp=_parse_ts(row["timestamp"]),
            detection_type=row["detection_type"],
            severity=row["severity"],
            source_device_id=row["source_device_id"],
            source_mac=row["source_mac"],
            source_ip=row["source_ip"],
            target_ip=row["target_ip"],
            target_port=row["target_port"],
            title=row["title"],
            description=row["description"],
            evidence=evidence,
            status=row["status"],
            resolution_notes=row["resolution_notes"],
            updated_at=_parse_ts(row["updated_at"]),
        )

    # -------------------------------------------------------------------------
    # Device Risk Scores
    # -------------------------------------------------------------------------
    def upsert_device_risk_score(
        self,
        device_id: str,
        risk_score: float,
        severity: str,
        contributing_signals: List[Dict[str, Any]],
        updated_at: Optional[datetime] = None,
    ) -> None:
        """Store or update a calculated risk score for a device."""
        now_ts = (updated_at or datetime.now(timezone.utc)).isoformat()
        sql = """
            INSERT INTO device_risk_scores (device_id, risk_score, severity, contributing_signals_json, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(device_id) DO UPDATE SET
                risk_score = excluded.risk_score,
                severity = excluded.severity,
                contributing_signals_json = excluded.contributing_signals_json,
                updated_at = excluded.updated_at;
        """
        with self.transaction() as conn:
            conn.execute(sql, (
                device_id,
                risk_score,
                severity,
                json.dumps(contributing_signals),
                now_ts,
            ))

    def get_device_risk_score(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Fetch the latest risk score record for a device."""
        sql = "SELECT * FROM device_risk_scores WHERE device_id = ?;"
        with self.transaction() as conn:
            row = conn.execute(sql, (device_id,)).fetchone()
            if not row:
                return None
            return {
                "device_id": row["device_id"],
                "risk_score": row["risk_score"],
                "severity": row["severity"],
                "contributing_signals": json.loads(row["contributing_signals_json"] or "[]"),
                "updated_at": _parse_ts(row["updated_at"]),
            }

    def get_all_device_risk_scores(self) -> List[Dict[str, Any]]:
        """Retrieve all device risk score evaluations ordered by risk descending."""
        sql = "SELECT * FROM device_risk_scores ORDER BY risk_score DESC;"
        with self.transaction() as conn:
            rows = conn.execute(sql).fetchall()
            return [
                {
                    "device_id": r["device_id"],
                    "risk_score": r["risk_score"],
                    "severity": r["severity"],
                    "contributing_signals": json.loads(r["contributing_signals_json"] or "[]"),
                    "updated_at": _parse_ts(r["updated_at"]),
                }
                for r in rows
            ]

