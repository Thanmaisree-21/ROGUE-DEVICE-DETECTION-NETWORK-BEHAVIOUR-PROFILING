-- SQLite Schema for Rogue Device Detection & Network Behavior Profiling
-- Stores device inventories, traffic metadata, baseline statistics, and alerts.
-- Does NOT store packet payloads to preserve confidentiality and conserve storage.

PRAGMA foreign_keys = ON;

-- 1. Pre-approved Assets Inventory
CREATE TABLE IF NOT EXISTS approved_assets (
    mac_address TEXT PRIMARY KEY,
    assigned_ip TEXT,
    device_name TEXT NOT NULL,
    device_type TEXT DEFAULT 'Standard Host',
    owner TEXT DEFAULT 'IT / Security',
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description TEXT
);

-- 2. Observed Devices
CREATE TABLE IF NOT EXISTS devices (
    device_id TEXT PRIMARY KEY,
    mac_address TEXT UNIQUE,
    current_ip TEXT,
    first_seen TIMESTAMP NOT NULL,
    last_seen TIMESTAMP NOT NULL,
    is_approved INTEGER DEFAULT 0,
    approval_status TEXT DEFAULT 'UNRECOGNIZED',
    vendor TEXT,
    hostname TEXT,
    total_packets INTEGER DEFAULT 0,
    total_bytes INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_devices_mac ON devices(mac_address);
CREATE INDEX IF NOT EXISTS idx_devices_current_ip ON devices(current_ip);
CREATE INDEX IF NOT EXISTS idx_devices_approval_status ON devices(approval_status);
CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON devices(last_seen);

-- 3. Device IP History (Tracks dynamic IP reallocations & address changes)
CREATE TABLE IF NOT EXISTS device_ip_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    ip_address TEXT NOT NULL,
    observed_at TIMESTAMP NOT NULL,
    source TEXT DEFAULT 'IP_TRAFFIC',
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ip_history_device ON device_ip_history(device_id);
CREATE INDEX IF NOT EXISTS idx_ip_history_ip ON device_ip_history(ip_address);
CREATE INDEX IF NOT EXISTS idx_ip_history_observed ON device_ip_history(observed_at);

-- 4. Observed Network Events (Metadata only)
CREATE TABLE IF NOT EXISTS network_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TIMESTAMP NOT NULL,
    src_mac TEXT,
    dst_mac TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    protocol TEXT NOT NULL,
    src_port INTEGER,
    dst_port INTEGER,
    packet_size INTEGER NOT NULL DEFAULT 0,
    tcp_flags TEXT,
    info TEXT
);

CREATE INDEX IF NOT EXISTS idx_events_timestamp ON network_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_events_src_mac ON network_events(src_mac);
CREATE INDEX IF NOT EXISTS idx_events_src_ip ON network_events(src_ip);
CREATE INDEX IF NOT EXISTS idx_events_protocol ON network_events(protocol);

-- 5. Traffic Aggregates (Rolling Windows)
CREATE TABLE IF NOT EXISTS traffic_aggregates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT NOT NULL,
    window_start TIMESTAMP NOT NULL,
    window_end TIMESTAMP NOT NULL,
    packet_count INTEGER DEFAULT 0,
    byte_count INTEGER DEFAULT 0,
    packet_rate REAL DEFAULT 0.0,
    byte_rate REAL DEFAULT 0.0,
    distinct_targets INTEGER DEFAULT 0,
    distinct_ports INTEGER DEFAULT 0,
    protocol_counts_json TEXT,
    syn_packet_count INTEGER DEFAULT 0,
    ack_packet_count INTEGER DEFAULT 0,
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_traffic_agg_dev ON traffic_aggregates(device_id);
CREATE INDEX IF NOT EXISTS idx_traffic_agg_win ON traffic_aggregates(window_start, window_end);

-- 6. Device Behavioral Baselines
CREATE TABLE IF NOT EXISTS device_baselines (
    device_id TEXT PRIMARY KEY,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    sample_windows INTEGER DEFAULT 0,
    mean_packet_rate REAL DEFAULT 0.0,
    std_packet_rate REAL DEFAULT 0.0,
    mean_byte_rate REAL DEFAULT 0.0,
    std_byte_rate REAL DEFAULT 0.0,
    expected_protocols_json TEXT,
    known_ports_json TEXT,
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE
);

-- 7. Security Alerts
CREATE TABLE IF NOT EXISTS alerts (
    alert_id TEXT PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL,
    detection_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    source_device_id TEXT,
    source_mac TEXT,
    source_ip TEXT,
    target_ip TEXT,
    target_port INTEGER,
    title TEXT NOT NULL,
    description TEXT,
    evidence_json TEXT,
    status TEXT DEFAULT 'NEW',
    resolution_notes TEXT,
    updated_at TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp);
CREATE INDEX IF NOT EXISTS idx_alerts_type ON alerts(detection_type);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_src_mac ON alerts(source_mac);

-- 8. Alert Investigation History (Audit Trail)
CREATE TABLE IF NOT EXISTS alert_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT NOT NULL,
    changed_at TIMESTAMP NOT NULL,
    previous_status TEXT NOT NULL,
    new_status TEXT NOT NULL,
    changed_by TEXT DEFAULT 'Security Analyst',
    comment TEXT,
    FOREIGN KEY (alert_id) REFERENCES alerts(alert_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_alert_history_id ON alert_history(alert_id);

-- 9. Device Risk Scores
CREATE TABLE IF NOT EXISTS device_risk_scores (
    device_id TEXT PRIMARY KEY,
    risk_score REAL NOT NULL,
    severity TEXT NOT NULL,
    contributing_signals_json TEXT,
    updated_at TIMESTAMP NOT NULL,
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_device_risk_score ON device_risk_scores(risk_score);
