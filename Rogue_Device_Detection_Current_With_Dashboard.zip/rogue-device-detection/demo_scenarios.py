"""
Demonstration runner for Rogue Device Detection & Network Behavior Profiling.
Provides reproducible, deterministic CLI workflows for 4 defensive security scenarios:
  - Scenario A: Port Scanning Reconnaissance
  - Scenario B: DoS-Like Traffic Anomaly / Volume Burst
  - Scenario C: ARP Spoofing / Gateway Impersonation & Rapid Flapping
  - Scenario D: Rogue DHCP Server Lease Offer

All traffic is synthetic, marked defensive-only, and safe to execute offline
without administrative privileges, live network drivers, or real packet flooding.
"""

import argparse
from datetime import datetime, timezone, timedelta
import logging
import sys
import time
from typing import Dict, List, Optional, Any

from config import load_config, AppConfig
from database.db import DatabaseManager
from models.events import NetworkEvent
from models.alert import Alert
from app import NetworkMonitoringApp, cmd_reset_db
from dashboard_interface import DashboardDataInterface

logger = logging.getLogger(__name__)


# =============================================================================
# Synthetic Event Generators for Scenarios A, B, C, D
# =============================================================================

def generate_scenario_a_events(base_time: Optional[datetime] = None) -> List[NetworkEvent]:
    """
    Scenario A: Port Scanning Reconnaissance.
    Simulates sequential TCP SYN probes across multiple destination ports (FTP 21, SSH 22,
    Telnet 23, HTTP 80, NetBIOS 139, HTTPS 443, SMB 445, RDP 3389, HTTP-Alt 8080)
    originating from an unauthorized host directed at an internal file server.
    """
    now = base_time or datetime.now(timezone.utc)
    probed_ports = [
        (21, "FTP"),
        (22, "SSH"),
        (23, "Telnet"),
        (80, "HTTP"),
        (139, "NetBIOS"),
        (443, "HTTPS"),
        (445, "SMB"),
        (3389, "RDP"),
        (8080, "HTTP-Alt"),
    ]
    events = []
    # Initial ARP announcement
    events.append(NetworkEvent(
        timestamp=now,
        src_mac="B8:27:EB:99:88:77",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.199",
        dst_ip="192.168.1.255",
        ip_version=4,
        protocol="ARP",
        src_port=None,
        dst_port=None,
        packet_size=42,
        tcp_flags=None,
        info="ARP Announcement: 192.168.1.199 is at B8:27:EB:99:88:77",
        is_synthetic=True,
        scenario="PORT_SCAN_ATTEMPT",
    ))

    # Sequential port probes
    for idx, (port, service) in enumerate(probed_ports):
        t = now + timedelta(milliseconds=100 + (idx * 150))
        events.append(NetworkEvent(
            timestamp=t,
            src_mac="B8:27:EB:99:88:77",
            dst_mac="00:0C:29:4F:8D:12",
            src_ip="192.168.1.199",
            dst_ip="192.168.1.20",
            ip_version=4,
            protocol="TCP",
            src_port=52000 + idx,
            dst_port=port,
            packet_size=60,
            tcp_flags="SYN",
            info=f"TCP SYN Probe to Port {port} ({service})",
            is_synthetic=True,
            scenario="PORT_SCAN_ATTEMPT",
        ))
    return events


def generate_scenario_b_events(base_time: Optional[datetime] = None) -> List[NetworkEvent]:
    """
    Scenario B: DoS-Like Traffic Anomaly / Volume Burst.
    Simulates a high-rate packet surge (45 packets within ~0.9s, ~54 KB) from a single host
    focused on an internal file server, exceeding standard packet and destination rate thresholds.
    """
    now = base_time or datetime.now(timezone.utc)
    events = []
    # Baseline normal packets first
    events.append(NetworkEvent(
        timestamp=now,
        src_mac="00:11:22:33:44:99",
        dst_mac="00:1A:2B:3C:4D:5E",
        src_ip="192.168.1.210",
        dst_ip="192.168.1.1",
        ip_version=4,
        protocol="UDP",
        src_port=53001,
        dst_port=53,
        packet_size=68,
        tcp_flags=None,
        info="DNS Query: files.internal.lan",
        is_synthetic=True,
        scenario="DOS_LIKE_TRAFFIC_BURST",
        is_dns=True,
    ))

    # Rapid high-volume burst
    for i in range(45):
        t = now + timedelta(milliseconds=50 + (i * 20))
        events.append(NetworkEvent(
            timestamp=t,
            src_mac="00:11:22:33:44:99",
            dst_mac="00:0C:29:4F:8D:12",
            src_ip="192.168.1.210",
            dst_ip="192.168.1.20",
            ip_version=4,
            protocol="TCP",
            src_port=49000 + i,
            dst_port=80,
            packet_size=1200,
            tcp_flags="ACK",
            info=f"High-volume payload request burst #{i + 1}",
            is_synthetic=True,
            scenario="DOS_LIKE_TRAFFIC_BURST",
        ))
    return events


def generate_scenario_c_events(base_time: Optional[datetime] = None) -> List[NetworkEvent]:
    """
    Scenario C: ARP Spoofing / Gateway Impersonation & Rapid Flapping.
    Part 1: Unauthorized MAC DE:AD:BE:EF:00:01 claims default gateway IP 192.168.1.1.
    Part 2: IP 192.168.1.55 oscillates rapidly between two distinct MAC addresses (flapping).
    """
    now = base_time or datetime.now(timezone.utc)
    events = []

    # Gateway spoof attempt (CRITICAL)
    events.append(NetworkEvent(
        timestamp=now,
        src_mac="DE:AD:BE:EF:00:01",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.1",
        dst_ip="192.168.1.10",
        ip_version=4,
        protocol="ARP",
        src_port=None,
        dst_port=None,
        packet_size=42,
        tcp_flags=None,
        info="Gratuitous ARP: 192.168.1.1 is at DE:AD:BE:EF:00:01 (Impersonating Default Gateway)",
        is_synthetic=True,
        scenario="GATEWAY_ARP_SPOOF_ATTEMPT",
    ))

    # Rapid ARP Flapping sequence
    events.append(NetworkEvent(
        timestamp=now + timedelta(seconds=1),
        src_mac="11:22:33:44:55:66",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.55",
        dst_ip="192.168.1.10",
        ip_version=4,
        protocol="ARP",
        src_port=None,
        dst_port=None,
        packet_size=42,
        tcp_flags=None,
        info="ARP Is-at: 192.168.1.55 is at 11:22:33:44:55:66",
        is_synthetic=True,
        scenario="RAPID_ARP_FLAPPING",
    ))

    events.append(NetworkEvent(
        timestamp=now + timedelta(seconds=2),
        src_mac="AA:BB:CC:DD:EE:FF",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.55",
        dst_ip="192.168.1.10",
        ip_version=4,
        protocol="ARP",
        src_port=None,
        dst_port=None,
        packet_size=42,
        tcp_flags=None,
        info="ARP Is-at: 192.168.1.55 is at AA:BB:CC:DD:EE:FF (Competing claim)",
        is_synthetic=True,
        scenario="RAPID_ARP_FLAPPING",
    ))

    events.append(NetworkEvent(
        timestamp=now + timedelta(seconds=3),
        src_mac="11:22:33:44:55:66",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.55",
        dst_ip="192.168.1.10",
        ip_version=4,
        protocol="ARP",
        src_port=None,
        dst_port=None,
        packet_size=42,
        tcp_flags=None,
        info="ARP Is-at: 192.168.1.55 is at 11:22:33:44:55:66 (Oscillation / Flap)",
        is_synthetic=True,
        scenario="RAPID_ARP_FLAPPING",
    ))
    return events


def generate_scenario_d_events(base_time: Optional[datetime] = None) -> List[NetworkEvent]:
    """
    Scenario D: Rogue DHCP Server Lease Offer.
    Simulates an unauthorized device (00:E0:4C:12:34:56) advertising DHCP OFFER leases
    from unapproved server IP 192.168.1.254 on a subnet where 192.168.1.1 is the sole authorized server.
    """
    now = base_time or datetime.now(timezone.utc)
    events = []

    # Legitimate DHCP Request from client
    events.append(NetworkEvent(
        timestamp=now,
        src_mac="3C:22:FB:44:55:66",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="0.0.0.0",
        dst_ip="255.255.255.255",
        ip_version=4,
        protocol="DHCP",
        src_port=68,
        dst_port=67,
        packet_size=300,
        tcp_flags=None,
        info="DHCP DISCOVER from 3C:22:FB:44:55:66",
        is_synthetic=True,
        scenario="LEGITIMATE_DHCP_RENEWAL",
        dhcp_message_type="DISCOVER",
    ))

    # Rogue server responds with OFFER
    events.append(NetworkEvent(
        timestamp=now + timedelta(milliseconds=80),
        src_mac="00:E0:4C:12:34:56",
        dst_mac="FF:FF:FF:FF:FF:FF",
        src_ip="192.168.1.254",
        dst_ip="255.255.255.255",
        ip_version=4,
        protocol="DHCP",
        src_port=67,
        dst_port=68,
        packet_size=340,
        tcp_flags=None,
        info="DHCP Offer: ServerID=192.168.1.254, OfferedIP=192.168.1.177, DNS=192.168.1.254",
        is_synthetic=True,
        scenario="UNAPPROVED_DHCP_OFFER",
        dhcp_message_type="OFFER",
        dhcp_server_id="192.168.1.254",
    ))
    return events


# =============================================================================
# Demonstration Scenario Runner
# =============================================================================

SCENARIO_METADATA = {
    "A": {
        "title": "Scenario A: Port Scanning Reconnaissance",
        "detector": "PortScanDetector",
        "expected_alert": "PORT_SCAN_SUSPECT",
        "generator": generate_scenario_a_events,
        "prerequisites": (
            "- Baseline server: 192.168.1.20 (FileServer-NAS, approved)\n"
            "- Port scan threshold: 8 distinct destination ports within 15s window\n"
            "- Attacking source: 192.168.1.199 (MAC: B8:27:EB:99:88:77, unapproved)"
        ),
        "defensive_summary": (
            "Port scanning indicates reconnaissance activity searching for reachable network services.\n"
            "Defensive action: Identify scan source, verify asset ownership, inspect perimeter firewall rules,\n"
            "and alert endpoint security on the probed server."
        ),
    },
    "B": {
        "title": "Scenario B: DoS-Like Traffic Anomaly / Volume Burst",
        "detector": "DosAnomalyDetector",
        "expected_alert": "TRAFFIC_ANOMALY_DOS_BURST",
        "generator": generate_scenario_b_events,
        "prerequisites": (
            "- Target server: 192.168.1.20 (FileServer-NAS)\n"
            "- Rate thresholds: 40 pkts/s source rate or 25 pkts/s single target concentration\n"
            "- Burst source: 192.168.1.210 (MAC: 00:11:22:33:44:99, unapproved)"
        ),
        "defensive_summary": (
            "Traffic bursts represent abnormal volume spikes that may saturate service capacity.\n"
            "Defensive disclaimer: Labeled as 'TRAFFIC ANOMALY' rather than confirmed malicious attack.\n"
            "Legitimate causes include bulk data backups, software updates, or network benchmarking.\n"
            "Defensive action: Correlate with system performance logs and check host process activity."
        ),
    },
    "C": {
        "title": "Scenario C: ARP Spoofing / Gateway Impersonation & Rapid Flapping",
        "detector": "ArpSpoofDetector",
        "expected_alert": "GATEWAY_ARP_SPOOF_SUSPECT",
        "generator": generate_scenario_c_events,
        "prerequisites": (
            "- Subnet Default Gateway: 192.168.1.1 (Expected Authorized MAC: 00:1A:2B:3C:4D:5E)\n"
            "- Impersonating host: MAC DE:AD:BE:EF:00:01\n"
            "- Secondary victim IP: 192.168.1.55 oscillating between two MACs"
        ),
        "defensive_summary": (
            "ARP spoofing against the default gateway allows adversaries to position as a Man-in-the-Middle (MitM)\n"
            "and intercept or tamper with all egress subnet traffic.\n"
            "Defensive action: Isolate rogue switch port, enable Dynamic ARP Inspection (DAI) / DHCP Snooping,\n"
            "and configure static ARP bindings on critical hosts."
        ),
    },
    "D": {
        "title": "Scenario D: Rogue DHCP Server Lease Offer",
        "detector": "RogueDhcpDetector",
        "expected_alert": "ROGUE_DHCP_OFFER_UNAPPROVED",
        "generator": generate_scenario_d_events,
        "prerequisites": (
            "- Authorized DHCP Server: 192.168.1.1 (MAC: 00:1A:2B:3C:4D:5E)\n"
            "- Unauthorized DHCP Server: 192.168.1.254 (MAC: 00:E0:4C:12:34:56)\n"
            "- Client requesting IP: 3C:22:FB:44:55:66"
        ),
        "defensive_summary": (
            "Rogue DHCP servers can distribute rogue DNS servers, rogue gateways, or malicious IP assignments,\n"
            "diverting workstation traffic without user awareness.\n"
            "Defensive action: Enable DHCP Snooping on network switches, shut down rogue switch port,\n"
            "and audit physical and virtual access points."
        ),
    },
}


def run_scenario(scenario_key: str, app: NetworkMonitoringApp, delay: float = 0.0) -> bool:
    """Execute a single scenario end-to-end and display rich formatted output."""
    meta = SCENARIO_METADATA.get(scenario_key.upper())
    if not meta:
        print(f"Unknown scenario key: {scenario_key}")
        return False

    print("\n" + "=" * 80)
    print(f" DEMONSTRATION WORKFLOW: {meta['title']}")
    print("=" * 80)

    # 1. Prerequisites
    print("\n[1] Prerequisites & Baseline Configuration:")
    for line in meta["prerequisites"].split("\n"):
        print(f"    {line}")

    # 2. Traffic Generation
    events = meta["generator"]()
    print(f"\n[2] Injected Synthetic Traffic:")
    print(f"    Generated {len(events)} synthetic packets (safe offline playback):")
    for idx, ev in enumerate(events[:5], 1):
        print(f"    - Event #{idx}: [{ev.protocol}] {ev.src_ip or ev.src_mac} -> {ev.dst_ip or ev.dst_mac} | {ev.info}")
    if len(events) > 5:
        print(f"    - ... and {len(events) - 5} additional events in this test sequence.")

    # 3. Pipeline Execution
    print(f"\n[3] Executing Pipeline (Sensor -> Discovery -> Detectors -> Database):")
    start_alerts_count = len(app.db.get_alerts())
    captured_alerts: List[Alert] = []

    def alert_catcher(alert: Alert):
        captured_alerts.append(alert)

    app.detection_engine.register_alert_callback(alert_catcher)

    for ev in events:
        app._on_event_received(ev)
        if delay > 0:
            time.sleep(delay)

    # Flush profiling window to trigger ML / baseline evaluation and risk recomputation
    app._flush_profiling_window()
    app.update_device_risk_scores()

    # Unregister local catcher
    if alert_catcher in app.detection_engine.alert_callbacks:
        app.detection_engine.alert_callbacks.remove(alert_catcher)

    # 4. Results & Alerts
    print(f"\n[4] Detection Results:")
    expected_found = any(a.detection_type == meta["expected_alert"] for a in captured_alerts)
    if expected_found:
        print(f"    [SUCCESS] Target detector '{meta['detector']}' triggered '{meta['expected_alert']}'!")
    else:
        print(f"    [WARNING] Expected alert '{meta['expected_alert']}' was not captured directly (checking DB).")

    print(f"\n    Alerts Generated in this Scenario ({len(captured_alerts)} total):")
    for a in captured_alerts:
        print(f"    ------------------------------------------------------------------------")
        print(f"    * Alert ID:    {a.alert_id}")
        print(f"      Type:        {a.detection_type} ({a.severity})")
        print(f"      Source:      {a.source_mac or 'N/A'} ({a.source_ip or 'N/A'})")
        print(f"      Title:       {a.title}")
        print(f"      Evidence:")
        for k, v in a.evidence.items():
            print(f"        - {k}: {v}")

    # 5. Device Risk Impact
    print(f"\n[5] Device Risk Impact & Scoring:")
    # Fetch risk record for the primary source
    src_ip = events[-1].src_ip or events[0].src_ip
    src_mac = events[-1].src_mac or events[0].src_mac
    device = app.db.get_device_by_mac(src_mac) if src_mac else None
    if not device and src_ip:
        device = app.db.get_device_by_ip(src_ip)

    if device:
        risk_record = app.db.get_device_risk_score(device.device_id)
        if risk_record:
            print(f"    Device ID:     {device.device_id} (MAC: {device.mac_address}, IP: {device.current_ip})")
            print(f"    Status:        {device.approval_status}")
            print(f"    Risk Score:    {risk_record['risk_score']:.1f}/100 ({risk_record['severity']})")
            signals = risk_record.get("contributing_signals", [])
            print(f"    Risk Signals:  {len(signals)} signal(s) contributed to this score:")
            for s in signals:
                print(f"      * [{s.get('category')}] {s.get('title')}: +{s.get('score_contribution', 0.0):.1f} pts")

    # 6. Defensive Summary
    print(f"\n[6] Defensive Analysis & Mitigation Guidance:")
    for line in meta["defensive_summary"].split("\n"):
        print(f"    {line}")
    print("=" * 80 + "\n")
    return expected_found


def main() -> None:
    """CLI Entry point for demo_scenarios.py."""
    parser = argparse.ArgumentParser(
        description="Defensive Demonstration Runner - Rogue Device Detection & Behavior Profiling",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--scenario",
        "-s",
        choices=["A", "B", "C", "D", "all"],
        default="all",
        help="Specific scenario to execute (A: Port Scan, B: DoS Burst, C: ARP Spoof, D: Rogue DHCP, all)",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset SQLite database before executing scenarios to ensure clean baseline state",
    )
    parser.add_argument(
        "--report",
        action="store_true",
        help="Print overall security posture report upon completion",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=0.01,
        help="Simulated delay between packets in seconds (0 for instantaneous execution)",
    )

    args = parser.parse_args()
    config = load_config()
    config.sensor.simulation_mode = True

    # Reset DB if requested
    if args.reset:
        print("[*] Resetting database to pristine baseline...")
        cmd_reset_db(config)

    app = NetworkMonitoringApp(config)

    scenarios_to_run = ["A", "B", "C", "D"] if args.scenario.lower() == "all" else [args.scenario.upper()]
    results = {}

    for sc in scenarios_to_run:
        success = run_scenario(sc, app, delay=args.delay)
        results[sc] = success

    print("\n" + "=" * 50)
    print(" DEMONSTRATION SUITE SUMMARY")
    print("=" * 50)
    all_passed = True
    for sc, res in results.items():
        status_str = "PASSED (Alert Generated)" if res else "FAILED"
        print(f"  Scenario {sc} ({SCENARIO_METADATA[sc]['expected_alert']}): {status_str}")
        if not res:
            all_passed = False
    print("=" * 50 + "\n")

    if args.report:
        interface = DashboardDataInterface(config.database.db_file)
        overview = interface.get_system_overview()
        print("OVERVIEW KPI SUMMARY:")
        print(f"  Total Observed Devices:   {overview['total_devices']}")
        print(f"  Approved Devices:         {overview['approved_devices']}")
        print(f"  Unrecognized Devices:     {overview['unrecognized_devices']}")
        print(f"  Total Security Alerts:    {overview['total_alerts']}")
        print(f"  Critical Alerts:          {overview['critical_alerts']}")
        print(f"  High Severity Alerts:     {overview['high_alerts']}")
        print(f"  Max Device Risk Score:    {overview['max_risk_score']:.1f}/100\n")

    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
