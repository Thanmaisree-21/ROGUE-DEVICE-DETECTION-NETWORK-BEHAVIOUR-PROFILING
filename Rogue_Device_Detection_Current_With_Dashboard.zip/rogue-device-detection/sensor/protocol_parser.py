"""
Protocol parsing module using Scapy.
Extracts network metadata (Ethernet, ARP, IP, TCP, UDP, ICMP, DHCP, DNS).
Strictly avoids capturing or retaining raw application payload data.
"""

from datetime import datetime, timezone
import logging
from typing import Optional, Tuple, Any, Dict

from scapy.packet import Packet
from scapy.layers.l2 import Ether, ARP
from scapy.layers.inet import IP, TCP, UDP, ICMP
from scapy.layers.inet6 import IPv6
from scapy.layers.dhcp import DHCP, BOOTP
from scapy.layers.dns import DNS

from models.events import NetworkEvent

logger = logging.getLogger(__name__)


def parse_tcp_flags(tcp_layer: TCP) -> str:
    """Extract human-readable TCP flags from a TCP packet."""
    flags = []
    f = tcp_layer.flags
    if f.S:
        flags.append("SYN")
    if f.A:
        flags.append("ACK")
    if f.F:
        flags.append("FIN")
    if f.R:
        flags.append("RST")
    if f.P:
        flags.append("PSH")
    if f.U:
        flags.append("URG")
    return "-".join(flags) if flags else "NONE"


def parse_dhcp_details(dhcp_packet: DHCP) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Extract DHCP message type, requested hostname, and server identifier.
    Returns (msg_type_name, hostname, server_id).
    """
    msg_type_name = None
    hostname = None
    server_id = None

    try:
        for opt in dhcp_packet.options:
            if isinstance(opt, tuple):
                opt_name = opt[0]
                val = opt[1]
                if opt_name == "message-type":
                    types = {
                        1: "DISCOVER",
                        2: "OFFER",
                        3: "REQUEST",
                        4: "DECLINE",
                        5: "ACK",
                        6: "NAK",
                        7: "RELEASE",
                        8: "INFORM",
                    }
                    msg_type_name = types.get(val, str(val).upper())
                elif opt_name == "hostname":
                    if isinstance(val, bytes):
                        hostname = val.decode("utf-8", errors="replace")
                    else:
                        hostname = str(val)
                elif opt_name in ("server_id", "server-id"):
                    server_id = str(val)
    except Exception as e:
        logger.debug("Error parsing DHCP options: %s", e)

    return msg_type_name, hostname, server_id


class ProtocolParser:
    """Stateless parser for extracting metadata from Scapy packets."""

    @staticmethod
    def parse(packet: Packet) -> Optional[NetworkEvent]:
        """
        Parse a Scapy packet into a structured NetworkEvent object.
        Returns None if packet is malformed or unhandled.
        """
        try:
            timestamp = datetime.fromtimestamp(float(packet.time), tz=timezone.utc)
        except Exception:
            timestamp = datetime.now(timezone.utc)

        packet_size = len(packet)
        src_mac: Optional[str] = None
        dst_mac: Optional[str] = None
        src_ip: Optional[str] = None
        dst_ip: Optional[str] = None
        ip_version: Optional[int] = None
        protocol: str = "OTHER"
        src_port: Optional[int] = None
        dst_port: Optional[int] = None
        tcp_flags: Optional[str] = None
        info_parts = []
        is_dns = False
        dhcp_msg_type = None
        dhcp_server_id = None

        # Layer 2: Ethernet
        if packet.haslayer(Ether):
            ether: Ether = packet[Ether]
            src_mac = ether.src.upper() if ether.src else None
            dst_mac = ether.dst.upper() if ether.dst else None

        # Layer 2/3: ARP
        if packet.haslayer(ARP):
            arp: ARP = packet[ARP]
            protocol = "ARP"
            src_ip = arp.psrc
            dst_ip = arp.pdst
            src_mac = arp.hwsrc.upper() if arp.hwsrc else src_mac
            dst_mac = arp.hwdst.upper() if arp.hwdst else dst_mac
            op = "Who-has" if arp.op == 1 else ("Is-at" if arp.op == 2 else f"Op-{arp.op}")
            info_parts.append(f"ARP {op} {dst_ip} Tell {src_ip}")

        # Layer 3: IPv4
        elif packet.haslayer(IP):
            ip: IP = packet[IP]
            ip_version = 4
            src_ip = ip.src
            dst_ip = ip.dst

            # Layer 4: TCP
            if packet.haslayer(TCP):
                tcp: TCP = packet[TCP]
                protocol = "TCP"
                src_port = int(tcp.sport)
                dst_port = int(tcp.dport)
                tcp_flags = parse_tcp_flags(tcp)
                info_parts.append(f"TCP {src_ip}:{src_port} -> {dst_ip}:{dst_port} [{tcp_flags}]")

            # Layer 4: UDP
            elif packet.haslayer(UDP):
                udp: UDP = packet[UDP]
                protocol = "UDP"
                src_port = int(udp.sport)
                dst_port = int(udp.dport)

                # Check for DNS
                if src_port == 53 or dst_port == 53 or packet.haslayer(DNS):
                    is_dns = True
                    info_parts.append(f"DNS {'Query' if dst_port == 53 else 'Response'}")

                # Check for DHCP / BOOTP
                if packet.haslayer(DHCP):
                    protocol = "DHCP"
                    dhcp_msg_type, hostname, srv_id = parse_dhcp_details(packet[DHCP])
                    dhcp_server_id = srv_id or src_ip
                    desc = f"DHCP {dhcp_msg_type}" if dhcp_msg_type else "DHCP"
                    info_parts.append(desc)
                    if hostname:
                        info_parts.append(f"Host={hostname}")
                    if srv_id:
                        info_parts.append(f"ServerID={srv_id}")
                elif packet.haslayer(BOOTP):
                    protocol = "DHCP"
                    info_parts.append("BOOTP Message")
                else:
                    info_parts.append(f"UDP {src_ip}:{src_port} -> {dst_ip}:{dst_port}")

            # Layer 4: ICMP
            elif packet.haslayer(ICMP):
                icmp: ICMP = packet[ICMP]
                protocol = "ICMP"
                icmp_types = {0: "Echo Reply", 8: "Echo Request", 3: "Destination Unreachable"}
                t_desc = icmp_types.get(icmp.type, f"Type {icmp.type}")
                info_parts.append(f"ICMP {t_desc}")

            else:
                protocol = f"IP-Proto-{ip.proto}"
                info_parts.append(f"Proto {ip.proto} {src_ip} -> {dst_ip}")

        # Layer 3: IPv6
        elif packet.haslayer(IPv6):
            ip6: IPv6 = packet[IPv6]
            ip_version = 6
            src_ip = ip6.src
            dst_ip = ip6.dst
            protocol = "IPv6"
            info_parts.append(f"IPv6 {src_ip} -> {dst_ip}")

        info = " | ".join(info_parts) if info_parts else None

        return NetworkEvent(
            timestamp=timestamp,
            src_mac=src_mac,
            dst_mac=dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
            ip_version=ip_version,
            protocol=protocol,
            src_port=src_port,
            dst_port=dst_port,
            packet_size=packet_size,
            tcp_flags=tcp_flags,
            info=info,
            raw_summary=packet.summary() if hasattr(packet, "summary") else None,
            is_synthetic=False,
            dhcp_message_type=dhcp_msg_type,
            dhcp_server_id=dhcp_server_id,
            is_dns=is_dns,
        )
