"""
Packet Sensor module using Scapy.
Captures or simulates network frames, extracts metadata into a bounded rolling buffer,
and dispatches events to registered listeners while separating capture from detection.
"""

from collections import deque
import json
import logging
import threading
import time
from typing import Callable, List, Optional, Deque, Dict, Any

from scapy.all import AsyncSniffer, Packet

from config import SensorConfig
from models.events import NetworkEvent
from sensor.protocol_parser import ProtocolParser

logger = logging.getLogger(__name__)


class PacketCapturePermissionError(RuntimeError):
    """Raised when raw packet capture fails due to missing Npcap/WinPcap or insufficient permissions."""
    pass


class PacketSensor:
    """
    Network packet sensor with live and simulated capture support.
    Maintains a bounded event buffer and dispatches parsed events to callbacks.
    """

    def __init__(self, config: Optional[SensorConfig] = None):
        self.config = config or SensorConfig()
        self.buffer: Deque[NetworkEvent] = deque(maxlen=self.config.buffer_size)
        self.callbacks: List[Callable[[NetworkEvent], None]] = []
        
        self._is_running = False
        self._stop_event = threading.Event()
        self._sniffer: Optional[AsyncSniffer] = None
        self._worker_thread: Optional[threading.Thread] = None

        self.stats: Dict[str, int] = {
            "total_packets_seen": 0,
            "packets_parsed": 0,
            "parse_errors": 0,
        }

    def register_callback(self, callback: Callable[[NetworkEvent], None]) -> None:
        """Register an event listener callback function."""
        if callback not in self.callbacks:
            self.callbacks.append(callback)

    def unregister_callback(self, callback: Callable[[NetworkEvent], None]) -> None:
        """Remove a previously registered listener callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)

    @property
    def is_running(self) -> bool:
        """Return True if sensor is currently capturing or simulating."""
        return self._is_running

    def start(self) -> None:
        """Start the sensor in either live capture mode or simulation mode."""
        if self._is_running:
            logger.warning("PacketSensor is already running.")
            return

        self._is_running = True
        self._stop_event.clear()

        if self.config.simulation_mode:
            logger.info("Starting PacketSensor in SIMULATION mode.")
            self._worker_thread = threading.Thread(
                target=self._run_simulation,
                name="Sensor-Simulation-Thread",
                daemon=True,
            )
            self._worker_thread.start()
        else:
            logger.info(
                "Starting PacketSensor in LIVE mode (Interface: %s, Filter: %s)",
                self.config.interface or "DEFAULT",
                self.config.bpf_filter,
            )
            try:
                self._sniffer = AsyncSniffer(
                    iface=self.config.interface,
                    filter=self.config.bpf_filter,
                    prn=self._on_packet_captured,
                    store=False,
                )
                self._sniffer.start()
            except Exception as e:
                self._is_running = False
                err_msg = str(e)
                logger.error(
                    "Failed to start live packet capture (check Npcap/Admin permissions): %s",
                    err_msg,
                    exc_info=True,
                )
                raise PacketCapturePermissionError(
                    f"Unable to start live packet capture on interface '{self.config.interface or 'DEFAULT'}': {err_msg}"
                ) from e

    def stop(self) -> None:
        """Gracefully stop packet capture and simulation worker."""
        if not self._is_running:
            return

        logger.info("Stopping PacketSensor...")
        self._is_running = False
        self._stop_event.set()

        if self._sniffer and self._sniffer.running:
            try:
                self._sniffer.stop()
            except Exception as e:
                logger.debug("Exception stopping sniffer: %s", e)
            self._sniffer = None

        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=2.0)
            self._worker_thread = None

        logger.info("PacketSensor stopped.")

    def _on_packet_captured(self, packet: Packet) -> None:
        """Internal callback invoked for each packet captured by Scapy."""
        self.stats["total_packets_seen"] += 1
        try:
            event = ProtocolParser.parse(packet)
            if event:
                self.stats["packets_parsed"] += 1
                self._dispatch_event(event)
        except Exception as e:
            self.stats["parse_errors"] += 1
            logger.debug("Packet parsing failure: %s", e)

    def _dispatch_event(self, event: NetworkEvent) -> None:
        """Append event to circular buffer and invoke registered callbacks."""
        self.buffer.append(event)
        for cb in self.callbacks:
            try:
                cb(event)
            except Exception as e:
                logger.exception("Error in sensor event callback %s: %s", cb, e)

    def _run_simulation(self) -> None:
        """Replay simulated events from JSON fixture file."""
        events_file = self.config.sample_events_file
        if not events_file.exists():
            logger.error("Simulation file not found: %s", events_file)
            self._is_running = False
            return

        try:
            with open(events_file, "r", encoding="utf-8") as f:
                raw_events = json.load(f)
        except Exception as e:
            logger.error("Failed to read simulation events: %s", e)
            self._is_running = False
            return

        logger.info("Loaded %d events for simulation playback.", len(raw_events))

        for raw in raw_events:
            if self._stop_event.is_set():
                break

            self.stats["total_packets_seen"] += 1
            try:
                event = NetworkEvent.from_dict(raw)
                self.stats["packets_parsed"] += 1
                self._dispatch_event(event)
            except Exception as e:
                self.stats["parse_errors"] += 1
                logger.error("Failed to parse simulated event: %s", e)

            # Controlled inter-packet delay
            if self.config.simulation_packet_delay > 0:
                time.sleep(self.config.simulation_packet_delay)

        logger.info("Simulation playback complete.")
        self._is_running = False

    def feed_event(self, event: NetworkEvent) -> None:
        """Programmatically feed an event directly into the sensor (useful for unit tests)."""
        self.stats["total_packets_seen"] += 1
        self.stats["packets_parsed"] += 1
        self._dispatch_event(event)

    def get_buffered_events(self, limit: Optional[int] = None) -> List[NetworkEvent]:
        """Return buffered events as a list, most recent first or chronological."""
        evs = list(self.buffer)
        if limit:
            evs = evs[-limit:]
        return evs

    @staticmethod
    def list_interfaces() -> List[Dict[str, str]]:
        """
        List available local network interfaces with descriptions, IP, and MAC addresses.
        Provides friendly interface identification for command line and configuration.
        """
        interfaces = []
        try:
            from scapy.all import conf
            seen_names = set()
            for iface in conf.ifaces.values():
                name = getattr(iface, "name", "")
                if not name or name in seen_names:
                    continue
                seen_names.add(name)
                interfaces.append({
                    "name": name,
                    "description": str(getattr(iface, "description", "") or "N/A"),
                    "ip": str(getattr(iface, "ip", "") or "N/A"),
                    "mac": str(getattr(iface, "mac", "") or "N/A"),
                })
        except Exception as e:
            logger.debug("Failed to enumerate network interfaces: %s", e)
        return interfaces

