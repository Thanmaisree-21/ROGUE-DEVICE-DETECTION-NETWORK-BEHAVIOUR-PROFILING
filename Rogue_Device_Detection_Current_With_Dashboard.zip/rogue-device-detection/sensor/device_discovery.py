"""
Device discovery and inventory management module.
Correlates MAC and IP addresses, tracks first-seen/last-seen timestamps,
maintains IP reallocation history, and reconciles against the approved inventory.
"""

from datetime import datetime, timezone
import logging
import re
from typing import Optional, Dict, List, Set, Tuple

from models.device import Device, DeviceIPObservation, ApprovedAsset, DeviceStatus
from models.events import NetworkEvent
from database.db import DatabaseManager

logger = logging.getLogger(__name__)

# Sample well-known OUI prefixes for demonstration and vendor enrichment
WELL_KNOWN_OUIS: Dict[str, str] = {
    "00:1A:2B": "Cisco Systems",
    "00:50:56": "VMware Virtual Host",
    "00:0C:29": "VMware Virtual Host",
    "70:B3:D5": "IEEE Registered Node / HP",
    "3C:22:FB": "Apple Inc.",
    "B8:27:EB": "Raspberry Pi Foundation",
    "DC:A6:32": "Raspberry Pi Foundation",
    "E4:5F:01": "Raspberry Pi Foundation",
    "F0:18:98": "Apple Inc.",
    "00:15:5D": "Microsoft Corporation",
}


def normalize_mac(mac: Optional[str]) -> Optional[str]:
    """Normalize MAC address to uppercase colon-separated format."""
    if not mac:
        return None
    cleaned = re.sub(r"[^0-9A-Fa-f]", "", mac).upper()
    if len(cleaned) != 12:
        return mac.upper()
    return ":".join(cleaned[i:i+2] for i in range(0, 12, 2))


def lookup_vendor(mac: Optional[str]) -> Optional[str]:
    """Enrich MAC address with vendor name via OUI prefix lookup."""
    norm = normalize_mac(mac)
    if not norm or len(norm) < 8:
        return None
    prefix = norm[:8]
    return WELL_KNOWN_OUIS.get(prefix)


class DeviceDiscoveryManager:
    """
    Maintains network device inventory in memory with database backing.
    Handles device onboarding, dynamic IP address changes, and asset verification.
    """

    def __init__(self, db: DatabaseManager):
        self.db = db
        # In-memory caches for high-throughput lookup
        self._devices_by_mac: Dict[str, Device] = {}
        self._devices_by_id: Dict[str, Device] = {}
        # Active IP to MAC mapping for rapid conflict detection
        self._ip_to_mac_map: Dict[str, str] = {}
        # Approved MAC cache
        self._approved_macs: Set[str] = set()
        
        self._load_approved_cache()
        self._load_existing_devices()

    def _load_approved_cache(self) -> None:
        """Preload approved assets into an in-memory set."""
        assets = self.db.get_all_approved_assets()
        self._approved_macs = {a.mac_address.upper() for a in assets}
        logger.info("Loaded %d approved assets into cache", len(self._approved_macs))

    def _load_existing_devices(self) -> None:
        """Load known devices from database into cache."""
        devices = self.db.get_all_devices()
        for d in devices:
            self._devices_by_id[d.device_id] = d
            if d.mac_address:
                norm_mac = normalize_mac(d.mac_address)
                if norm_mac:
                    self._devices_by_mac[norm_mac] = d
            if d.current_ip:
                self._ip_to_mac_map[d.current_ip] = d.mac_address or d.device_id
        logger.info("Loaded %d existing devices from database", len(devices))

    def refresh_approved_cache(self) -> None:
        """Reload approved assets from the database."""
        self._load_approved_cache()
        # Re-evaluate approval status for all cached devices
        for d in self._devices_by_id.values():
            if d.mac_address:
                is_appr = normalize_mac(d.mac_address) in self._approved_macs
                if d.is_approved != is_appr:
                    d.is_approved = is_appr
                    d.approval_status = DeviceStatus.APPROVED.value if is_appr else DeviceStatus.UNRECOGNIZED.value
                    self.db.upsert_device(d)

    def process_event(self, event: NetworkEvent) -> Tuple[Optional[Device], bool, Optional[str]]:
        """
        Ingest a network event and update device state.
        
        Returns:
            Tuple[Optional[Device], is_new_device, ip_conflict_detail]
        """
        src_mac = normalize_mac(event.src_mac)
        src_ip = event.src_ip

        # Ignore broadcast / multicast source addresses (invalid host sources)
        if src_mac and src_mac in ("FF:FF:FF:FF:FF:FF", "00:00:00:00:00:00"):
            return None, False, None
        if src_ip and (src_ip.startswith("224.") or src_ip == "255.255.255.255"):
            return None, False, None

        if not src_mac and not src_ip:
            return None, False, None

        # Determine primary device identifier
        device_id = f"mac_{src_mac}" if src_mac else f"ip_{src_ip}"
        device: Optional[Device] = None
        is_new = False
        conflict_msg: Optional[str] = None

        # Look up existing device by MAC
        if src_mac and src_mac in self._devices_by_mac:
            device = self._devices_by_mac[src_mac]
        elif device_id in self._devices_by_id:
            device = self._devices_by_id[device_id]

        now_ts = event.timestamp

        # Case 1: Brand new device observed
        if device is None:
            is_new = True
            is_approved = (src_mac in self._approved_macs) if src_mac else False
            approval_status = DeviceStatus.APPROVED.value if is_approved else DeviceStatus.UNRECOGNIZED.value
            vendor = lookup_vendor(src_mac)

            device = Device(
                device_id=device_id,
                mac_address=src_mac,
                current_ip=src_ip,
                first_seen=now_ts,
                last_seen=now_ts,
                is_approved=is_approved,
                approval_status=approval_status,
                vendor=vendor,
                hostname=None,
                total_packets=1,
                total_bytes=event.packet_size,
                ip_history=[src_ip] if src_ip else [],
            )

            # Extract hostname from DHCP if available
            if event.protocol == "DHCP" and event.info and "Host=" in event.info:
                try:
                    hname = event.info.split("Host=")[1].split()[0]
                    device.hostname = hname
                except Exception:
                    pass

            self._devices_by_id[device_id] = device
            if src_mac:
                self._devices_by_mac[src_mac] = device

            # Persist to database
            self.db.upsert_device(device)
            if src_ip:
                self.db.record_ip_observation(DeviceIPObservation(
                    device_id=device_id,
                    ip_address=src_ip,
                    observed_at=now_ts,
                    source=event.protocol,
                ))

            logger.info(
                "Discovered NEW device: ID=%s, MAC=%s, IP=%s, Status=%s",
                device_id, src_mac, src_ip, approval_status
            )

        # Case 2: Existing device updated
        else:
            device.last_seen = now_ts
            device.total_packets += 1
            device.total_bytes += event.packet_size

            # Handle IP address changes / dynamic IP updates
            if src_ip and src_ip != "0.0.0.0":
                if device.current_ip != src_ip:
                    old_ip = device.current_ip
                    device.current_ip = src_ip
                    if src_ip not in device.ip_history:
                        device.ip_history.append(src_ip)

                    self.db.record_ip_observation(DeviceIPObservation(
                        device_id=device.device_id,
                        ip_address=src_ip,
                        observed_at=now_ts,
                        source=event.protocol,
                    ))
                    logger.info(
                        "IP address update for device %s (MAC: %s): %s -> %s",
                        device.device_id, device.mac_address, old_ip, src_ip
                    )

            # Extract hostname from DHCP if newly available
            if event.protocol == "DHCP" and event.info and "Host=" in event.info and not device.hostname:
                try:
                    hname = event.info.split("Host=")[1].split()[0]
                    device.hostname = hname
                except Exception:
                    pass

            # Persist updated last seen and counters periodically or on event
            self.db.upsert_device(device)

        # Check for IP conflicts / potential spoofing (same IP claimed by multiple MACs)
        if src_ip and src_mac and src_ip != "0.0.0.0":
            prev_mac = self._ip_to_mac_map.get(src_ip)
            if prev_mac and prev_mac != src_mac:
                conflict_msg = (
                    f"IP collision / possible ARP spoof: IP {src_ip} previously held by MAC "
                    f"{prev_mac}, now claimed by MAC {src_mac}"
                )
                logger.warning(conflict_msg)
            self._ip_to_mac_map[src_ip] = src_mac

        return device, is_new, conflict_msg

    def get_device(self, identifier: str) -> Optional[Device]:
        """Fetch device by ID or MAC."""
        norm = normalize_mac(identifier)
        if norm and norm in self._devices_by_mac:
            return self._devices_by_mac[norm]
        return self._devices_by_id.get(identifier)

    def get_all_devices(self) -> List[Device]:
        """Return list of all currently tracked devices."""
        return list(self._devices_by_id.values())
